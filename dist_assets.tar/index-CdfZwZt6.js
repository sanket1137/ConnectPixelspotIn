const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/not-found-Cgl9k9Hs.js","assets/vendor-ui-DWr-E0-F.js","assets/vendor-react--0RGCJ5T.js","assets/card-D4bMDYln.js","assets/circle-alert-Z6Qk6lPu.js","assets/vendor-query-D6OOLHvs.js","assets/vendor-charts-lX635fKD.js","assets/vendor-maps-COvPg4R3.js","assets/Login-BQvHb_pA.js","assets/label-CkXEAbZC.js","assets/tabs-B7csaNa4.js","assets/dialog-BCK5zeik.js","assets/mail-DRvIIyKw.js","assets/megaphone-BKsqaOKz.js","assets/building-2-B5jtVQ5G.js","assets/AdminDashboard-BABIFLtf.js","assets/skeleton-C60E36-c.js","assets/GuidedTour-UPnbmz_h.js","assets/trending-down-C4GRedRn.js","assets/ManageUsers-COF5fvSg.js","assets/select-JfWinr4X.js","assets/check-CV9KZuCb.js","assets/search-irqYF2Xo.js","assets/ManageScreens-Cs2AADy_.js","assets/textarea-D-6O_Brr.js","assets/ScreenTagsPanel-BvRbwBmO.js","assets/loader-circle-D_qSfK20.js","assets/zap-nHJ7E6Tr.js","assets/plus-vuRiU3GH.js","assets/eye-Bq4MHnwu.js","assets/chevron-right-YzeQ_RGt.js","assets/AddScreenForOwner-C9jYSHln.js","assets/ScreenForm-CRQtRLRN.js","assets/form-NYCkEb8V.js","assets/checkbox-CVhRGwqS.js","assets/switch-CSjhnMFM.js","assets/constants-BRCkSmJQ.js","assets/upload-Oj6aYRGd.js","assets/ManageBookings-5NLxQ-Lt.js","assets/user-zPObBriO.js","assets/phone-CXD1VgcY.js","assets/building-wtNVhBOm.js","assets/circle-check-big-BaMZCMYt.js","assets/square-pen-DVdCbR8K.js","assets/Analytics-Buh-Cqu1.js","assets/clock-DCm6-41c.js","assets/AIConversations-CMyZ6BZJ.js","assets/hash-BiCCG7Wy.js","assets/target-CTHeROkP.js","assets/globe-Bs5tSRi5.js","assets/en-US-CXXYYhpC.js","assets/AISecurityDashboard-DIJYyZuu.js","assets/triangle-alert-D02vyXFz.js","assets/format-Cn6ElKJ8.js","assets/Settings-CwWdsNXH.js","assets/OwnerDashboard-5ZBHvA1X.js","assets/ScreensList-UdjFN9Bl.js","assets/alert-Bwi_HPu5.js","assets/trash-2-C_i4MppG.js","assets/AddScreen-BocnxIXx.js","assets/arrow-left-XHSdSgeJ.js","assets/EditScreen-Dcdlghel.js","assets/BookingRequests-BmhW9xi5.js","assets/camera-DVIflA4t.js","assets/AdvertiserDashboard-CRA0M7Ht.js","assets/play-BRls8Ks6.js","assets/DiscoverScreens-C760cOai.js","assets/map-BYyjV5TG.js","assets/CampaignsList-i6bZVM_2.js","assets/pen-slWhagG9.js","assets/CampaignDetails-964eioxq.js","assets/circle-x-DAhOEJSg.js","assets/shield-check-CWWVvwAn.js","assets/CreateCampaign-wb-ZZDYs.js","assets/progress-BIHflts6.js","assets/slider-DD1nnM9m.js","assets/radio-group-BbKLpxL7.js","assets/arrow-right-bwgjSmFA.js","assets/QuickCampaignFromCart-UXgnVyHd.js","assets/BookingManagement-CntjCwng.js","assets/AICampaignAdvisor-CPJ2O48K.js","assets/send-olU-AOg6.js","assets/ComingSoon-UsUwgRfW.js","assets/OwnerEarnings-DqN3lV4z.js","assets/AdvertiserPayments-Cn1h4-TB.js","assets/AdminPayments-B0Chvo8t.js","assets/ProfileCompletion-Cjn8dfp6.js","assets/EmailVerification-Ba0_Usx6.js","assets/Profile-BEN3VmUT.js","assets/PublicHome-CvSCYJRd.js","assets/PasswordReset-BW0GNazf.js","assets/PrivacyPolicy-BRWxf3TT.js","assets/TermsOfService-C-oh-4ke.js","assets/RefundPolicy-BKuzztUv.js","assets/ContactUs-NBUQJwy3.js","assets/AboutUs-8jrsgjmt.js"])))=>i.map(i=>d[i]);
import{H as Fi,f as xr,u as se,j as a,U as Vi,h as H,X as rs,g as ns,m as Oe,N as Q,i as L,Y as zi,Z as ss,M as os,_ as $i,$ as is,a0 as Bi,a1 as Hi,a2 as Wi,Q as Ir,O as as,c as cs,d as qi,e as ls,D as ds,a as Ki,b as Gi,P as Yi,a3 as us,a4 as hs,a5 as Ji,a6 as Xi,a7 as Qi,a8 as Zi,a9 as ea,aa as ta,ab as ra,ac as na,ad as sa,K as oa,q as ia,J as aa}from"./vendor-ui-DWr-E0-F.js";import{a as fs,r as u,c as ca}from"./vendor-react--0RGCJ5T.js";import{Q as la,b as da,u as ps,a as et,c as ua}from"./vendor-query-D6OOLHvs.js";import{g as ms}from"./vendor-charts-lX635fKD.js";import{b as ha}from"./vendor-maps-COvPg4R3.js";(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const s of document.querySelectorAll('link[rel="modulepreload"]'))n(s);new MutationObserver(s=>{for(const o of s)if(o.type==="childList")for(const i of o.addedNodes)i.tagName==="LINK"&&i.rel==="modulepreload"&&n(i)}).observe(document,{childList:!0,subtree:!0});function r(s){const o={};return s.integrity&&(o.integrity=s.integrity),s.referrerPolicy&&(o.referrerPolicy=s.referrerPolicy),s.crossOrigin==="use-credentials"?o.credentials="include":s.crossOrigin==="anonymous"?o.credentials="omit":o.credentials="same-origin",o}function n(s){if(s.ep)return;s.ep=!0;const o=r(s);fetch(s.href,o)}})();var gs,tn=fs;gs=tn.createRoot,tn.hydrateRoot;const fa="modulepreload",pa=function(t){return"/"+t},rn={},S=function(e,r,n){let s=Promise.resolve();if(r&&r.length>0){document.getElementsByTagName("link");const i=document.querySelector("meta[property=csp-nonce]"),c=(i==null?void 0:i.nonce)||(i==null?void 0:i.getAttribute("nonce"));s=Promise.allSettled(r.map(l=>{if(l=pa(l),l in rn)return;rn[l]=!0;const d=l.endsWith(".css"),f=d?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${l}"]${f}`))return;const p=document.createElement("link");if(p.rel=d?"stylesheet":fa,d||(p.as="script"),p.crossOrigin="",p.href=l,c&&p.setAttribute("nonce",c),document.head.appendChild(p),d)return new Promise((h,m)=>{p.addEventListener("load",h),p.addEventListener("error",()=>m(new Error(`Unable to preload CSS for ${l}`)))})}))}function o(i){const c=new Event("vite:preloadError",{cancelable:!0});if(c.payload=i,window.dispatchEvent(c),!c.defaultPrevented)throw i}return s.then(i=>{for(const c of i||[])c.status==="rejected"&&o(c.reason);return e().catch(o)})};function ma(t,e){if(t instanceof RegExp)return{keys:!1,pattern:t};var r,n,s,o,i=[],c="",l=t.split("/");for(l[0]||l.shift();s=l.shift();)r=s[0],r==="*"?(i.push(r),c+=s[1]==="?"?"(?:/(.*))?":"/(.*)"):r===":"?(n=s.indexOf("?",1),o=s.indexOf(".",1),i.push(s.substring(1,~n?n:~o?o:s.length)),c+=~n&&!~o?"(?:/([^/]+?))?":"/([^/]+?)",~o&&(c+=(~n?"?":"")+"\\"+s.substring(o))):c+="/"+s;return{keys:i,pattern:new RegExp("^"+c+(e?"(?=$|/)":"/?$"),"i")}}var bs={exports:{}},ys={};/**
 * @license React
 * use-sync-external-store-shim.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var ze=u;function ga(t,e){return t===e&&(t!==0||1/t===1/e)||t!==t&&e!==e}var ba=typeof Object.is=="function"?Object.is:ga,ya=ze.useState,va=ze.useEffect,wa=ze.useLayoutEffect,_a=ze.useDebugValue;function Ea(t,e){var r=e(),n=ya({inst:{value:r,getSnapshot:e}}),s=n[0].inst,o=n[1];return wa(function(){s.value=r,s.getSnapshot=e,Gt(s)&&o({inst:s})},[t,r,e]),va(function(){return Gt(s)&&o({inst:s}),t(function(){Gt(s)&&o({inst:s})})},[t]),_a(r),r}function Gt(t){var e=t.getSnapshot;t=t.value;try{var r=e();return!ba(t,r)}catch{return!0}}function xa(t,e){return e()}var Ia=typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"?xa:Ea;ys.useSyncExternalStore=ze.useSyncExternalStore!==void 0?ze.useSyncExternalStore:Ia;bs.exports=ys;var Sa=bs.exports;const Ta=ca.useInsertionEffect,Ca=typeof window<"u"&&typeof window.document<"u"&&typeof window.document.createElement<"u",Pa=Ca?u.useLayoutEffect:u.useEffect,Ra=Ta||Pa,vs=t=>{const e=u.useRef([t,(...r)=>e[0](...r)]).current;return Ra(()=>{e[0]=t}),e[1]},Aa="popstate",Sr="pushState",Tr="replaceState",ka="hashchange",nn=[Aa,Sr,Tr,ka],Na=t=>{for(const e of nn)addEventListener(e,t);return()=>{for(const e of nn)removeEventListener(e,t)}},ws=(t,e)=>Sa.useSyncExternalStore(Na,t,e),Oa=()=>location.search,Da=({ssrSearch:t=""}={})=>ws(Oa,()=>t),sn=()=>location.pathname,La=({ssrPath:t}={})=>ws(sn,t?()=>t:sn),Ma=(t,{replace:e=!1,state:r=null}={})=>history[e?Tr:Sr](r,"",t),ja=(t={})=>[La(t),Ma],on=Symbol.for("wouter_v3");if(typeof history<"u"&&typeof window[on]>"u"){for(const t of[Sr,Tr]){const e=history[t];history[t]=function(){const r=e.apply(this,arguments),n=new Event(t);return n.arguments=arguments,dispatchEvent(n),r}}Object.defineProperty(window,on,{value:!0})}const Ua=(t,e)=>e.toLowerCase().indexOf(t.toLowerCase())?"~"+e:e.slice(t.length)||"/",_s=(t="")=>t==="/"?"":t,Fa=(t,e)=>t[0]==="~"?t.slice(1):_s(e)+t,Va=(t="",e)=>Ua(an(_s(t)),an(e)),an=t=>{try{return decodeURI(t)}catch{return t}},Es={hook:ja,searchHook:Da,parser:ma,base:"",ssrPath:void 0,ssrSearch:void 0,hrefs:t=>t},xs=u.createContext(Es),qe=()=>u.useContext(xs),Is={},Ss=u.createContext(Is),za=()=>u.useContext(Ss),jt=t=>{const[e,r]=t.hook(t);return[Va(t.base,e),vs((n,s)=>r(Fa(n,t.base),s))]},ct=()=>jt(qe()),Cr=(t,e,r,n)=>{const{pattern:s,keys:o}=e instanceof RegExp?{keys:!1,pattern:e}:t(e||"*",n),i=s.exec(r)||[],[c,...l]=i;return c!==void 0?[!0,(()=>{const d=o!==!1?Object.fromEntries(o.map((p,h)=>[p,l[h]])):i.groups;let f={...l};return d&&Object.assign(f,d),f})(),...n?[c]:[]]:[!1,null]},ym=t=>Cr(qe().parser,t,ct()[0]),$a=({children:t,...e})=>{var f,p;const r=qe(),n=e.hook?Es:r;let s=n;const[o,i]=((f=e.ssrPath)==null?void 0:f.split("?"))??[];i&&(e.ssrSearch=i,e.ssrPath=o),e.hrefs=e.hrefs??((p=e.hook)==null?void 0:p.hrefs);let c=u.useRef({}),l=c.current,d=l;for(let h in n){const m=h==="base"?n[h]+(e[h]||""):e[h]||n[h];l===d&&m!==d[h]&&(c.current=d={...d}),d[h]=m,m!==n[h]&&(s=d)}return u.createElement(xs.Provider,{value:s,children:t})},cn=({children:t,component:e},r)=>e?u.createElement(e,{params:r}):typeof t=="function"?t(r):t,Ba=t=>{let e=u.useRef(Is),r=e.current;for(const n in t)t[n]!==r[n]&&(r=t);return Object.keys(t).length===0&&(r=t),e.current=r},E=({path:t,nest:e,match:r,...n})=>{const s=qe(),[o]=jt(s),[i,c,l]=r??Cr(s.parser,t,o,e),d=Ba({...za(),...c});if(!i)return null;const f=l?u.createElement($a,{base:l},cn(n,d)):cn(n,d);return u.createElement(Ss.Provider,{value:d,children:f})},vm=u.forwardRef((t,e)=>{const r=qe(),[n,s]=jt(r),{to:o="",href:i=o,onClick:c,asChild:l,children:d,className:f,replace:p,state:h,...m}=t,y=vs(g=>{g.ctrlKey||g.metaKey||g.altKey||g.shiftKey||g.button!==0||(c==null||c(g),g.defaultPrevented||(g.preventDefault(),s(i,t)))}),b=r.hrefs(i[0]==="~"?i.slice(1):r.base+i,r);return l&&u.isValidElement(d)?u.cloneElement(d,{onClick:y,href:b}):u.createElement("a",{...m,onClick:y,href:b,className:f!=null&&f.call?f(n===i):f,children:d,ref:e})}),Ts=t=>Array.isArray(t)?t.flatMap(e=>Ts(e&&e.type===u.Fragment?e.props.children:e)):[t],Ha=({children:t,location:e})=>{const r=qe(),[n]=jt(r);for(const s of Ts(t)){let o=0;if(u.isValidElement(s)&&(o=Cr(r.parser,s.props.path,e||n,s.props.nest))[0])return u.cloneElement(s,{match:o})}return null},Wa=()=>{};var ln={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Cs=function(t){const e=[];let r=0;for(let n=0;n<t.length;n++){let s=t.charCodeAt(n);s<128?e[r++]=s:s<2048?(e[r++]=s>>6|192,e[r++]=s&63|128):(s&64512)===55296&&n+1<t.length&&(t.charCodeAt(n+1)&64512)===56320?(s=65536+((s&1023)<<10)+(t.charCodeAt(++n)&1023),e[r++]=s>>18|240,e[r++]=s>>12&63|128,e[r++]=s>>6&63|128,e[r++]=s&63|128):(e[r++]=s>>12|224,e[r++]=s>>6&63|128,e[r++]=s&63|128)}return e},qa=function(t){const e=[];let r=0,n=0;for(;r<t.length;){const s=t[r++];if(s<128)e[n++]=String.fromCharCode(s);else if(s>191&&s<224){const o=t[r++];e[n++]=String.fromCharCode((s&31)<<6|o&63)}else if(s>239&&s<365){const o=t[r++],i=t[r++],c=t[r++],l=((s&7)<<18|(o&63)<<12|(i&63)<<6|c&63)-65536;e[n++]=String.fromCharCode(55296+(l>>10)),e[n++]=String.fromCharCode(56320+(l&1023))}else{const o=t[r++],i=t[r++];e[n++]=String.fromCharCode((s&15)<<12|(o&63)<<6|i&63)}}return e.join("")},Ps={byteToCharMap_:null,charToByteMap_:null,byteToCharMapWebSafe_:null,charToByteMapWebSafe_:null,ENCODED_VALS_BASE:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",get ENCODED_VALS(){return this.ENCODED_VALS_BASE+"+/="},get ENCODED_VALS_WEBSAFE(){return this.ENCODED_VALS_BASE+"-_."},HAS_NATIVE_SUPPORT:typeof atob=="function",encodeByteArray(t,e){if(!Array.isArray(t))throw Error("encodeByteArray takes an array as a parameter");this.init_();const r=e?this.byteToCharMapWebSafe_:this.byteToCharMap_,n=[];for(let s=0;s<t.length;s+=3){const o=t[s],i=s+1<t.length,c=i?t[s+1]:0,l=s+2<t.length,d=l?t[s+2]:0,f=o>>2,p=(o&3)<<4|c>>4;let h=(c&15)<<2|d>>6,m=d&63;l||(m=64,i||(h=64)),n.push(r[f],r[p],r[h],r[m])}return n.join("")},encodeString(t,e){return this.HAS_NATIVE_SUPPORT&&!e?btoa(t):this.encodeByteArray(Cs(t),e)},decodeString(t,e){return this.HAS_NATIVE_SUPPORT&&!e?atob(t):qa(this.decodeStringToByteArray(t,e))},decodeStringToByteArray(t,e){this.init_();const r=e?this.charToByteMapWebSafe_:this.charToByteMap_,n=[];for(let s=0;s<t.length;){const o=r[t.charAt(s++)],c=s<t.length?r[t.charAt(s)]:0;++s;const d=s<t.length?r[t.charAt(s)]:64;++s;const p=s<t.length?r[t.charAt(s)]:64;if(++s,o==null||c==null||d==null||p==null)throw new Ka;const h=o<<2|c>>4;if(n.push(h),d!==64){const m=c<<4&240|d>>2;if(n.push(m),p!==64){const y=d<<6&192|p;n.push(y)}}}return n},init_(){if(!this.byteToCharMap_){this.byteToCharMap_={},this.charToByteMap_={},this.byteToCharMapWebSafe_={},this.charToByteMapWebSafe_={};for(let t=0;t<this.ENCODED_VALS.length;t++)this.byteToCharMap_[t]=this.ENCODED_VALS.charAt(t),this.charToByteMap_[this.byteToCharMap_[t]]=t,this.byteToCharMapWebSafe_[t]=this.ENCODED_VALS_WEBSAFE.charAt(t),this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[t]]=t,t>=this.ENCODED_VALS_BASE.length&&(this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(t)]=t,this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(t)]=t)}}};class Ka extends Error{constructor(){super(...arguments),this.name="DecodeBase64StringError"}}const Ga=function(t){const e=Cs(t);return Ps.encodeByteArray(e,!0)},Rs=function(t){return Ga(t).replace(/\./g,"")},As=function(t){try{return Ps.decodeString(t,!0)}catch(e){console.error("base64Decode failed: ",e)}return null};/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ya(){if(typeof self<"u")return self;if(typeof window<"u")return window;if(typeof global<"u")return global;throw new Error("Unable to locate global object.")}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ja=()=>Ya().__FIREBASE_DEFAULTS__,Xa=()=>{if(typeof process>"u"||typeof ln>"u")return;const t=ln.__FIREBASE_DEFAULTS__;if(t)return JSON.parse(t)},Qa=()=>{if(typeof document>"u")return;let t;try{t=document.cookie.match(/__FIREBASE_DEFAULTS__=([^;]+)/)}catch{return}const e=t&&As(t[1]);return e&&JSON.parse(e)},Pr=()=>{try{return Wa()||Ja()||Xa()||Qa()}catch(t){console.info(`Unable to get __FIREBASE_DEFAULTS__ due to: ${t}`);return}},Za=t=>{var e,r;return(r=(e=Pr())==null?void 0:e.emulatorHosts)==null?void 0:r[t]},ks=()=>{var t;return(t=Pr())==null?void 0:t.config},Ns=t=>{var e;return(e=Pr())==null?void 0:e[`_${t}`]};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ec{constructor(){this.reject=()=>{},this.resolve=()=>{},this.promise=new Promise((e,r)=>{this.resolve=e,this.reject=r})}wrapCallback(e){return(r,n)=>{r?this.reject(r):this.resolve(n),typeof e=="function"&&(this.promise.catch(()=>{}),e.length===1?e(r):e(r,n))}}}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ut(t){try{return(t.startsWith("http://")||t.startsWith("https://")?new URL(t).hostname:t).endsWith(".cloudworkstations.dev")}catch{return!1}}async function tc(t){return(await fetch(t,{credentials:"include"})).ok}const tt={};function rc(){const t={prod:[],emulator:[]};for(const e of Object.keys(tt))tt[e]?t.emulator.push(e):t.prod.push(e);return t}function nc(t){let e=document.getElementById(t),r=!1;return e||(e=document.createElement("div"),e.setAttribute("id",t),r=!0),{created:r,element:e}}let dn=!1;function sc(t,e){if(typeof window>"u"||typeof document>"u"||!Ut(window.location.host)||tt[t]===e||tt[t]||dn)return;tt[t]=e;function r(h){return`__firebase__banner__${h}`}const n="__firebase__banner",o=rc().prod.length>0;function i(){const h=document.getElementById(n);h&&h.remove()}function c(h){h.style.display="flex",h.style.background="#7faaf0",h.style.position="fixed",h.style.bottom="5px",h.style.left="5px",h.style.padding=".5em",h.style.borderRadius="5px",h.style.alignItems="center"}function l(h,m){h.setAttribute("width","24"),h.setAttribute("id",m),h.setAttribute("height","24"),h.setAttribute("viewBox","0 0 24 24"),h.setAttribute("fill","none"),h.style.marginLeft="-6px"}function d(){const h=document.createElement("span");return h.style.cursor="pointer",h.style.marginLeft="16px",h.style.fontSize="24px",h.innerHTML=" &times;",h.onclick=()=>{dn=!0,i()},h}function f(h,m){h.setAttribute("id",m),h.innerText="Learn more",h.href="https://firebase.google.com/docs/studio/preview-apps#preview-backend",h.setAttribute("target","__blank"),h.style.paddingLeft="5px",h.style.textDecoration="underline"}function p(){const h=nc(n),m=r("text"),y=document.getElementById(m)||document.createElement("span"),b=r("learnmore"),g=document.getElementById(b)||document.createElement("a"),v=r("preprendIcon"),w=document.getElementById(v)||document.createElementNS("http://www.w3.org/2000/svg","svg");if(h.created){const C=h.element;c(C),f(g,b);const T=d();l(w,v),C.append(w,y,g,T),document.body.appendChild(C)}o?(y.innerText="Preview backend disconnected.",w.innerHTML=`<g clip-path="url(#clip0_6013_33858)">
<path d="M4.8 17.6L12 5.6L19.2 17.6H4.8ZM6.91667 16.4H17.0833L12 7.93333L6.91667 16.4ZM12 15.6C12.1667 15.6 12.3056 15.5444 12.4167 15.4333C12.5389 15.3111 12.6 15.1667 12.6 15C12.6 14.8333 12.5389 14.6944 12.4167 14.5833C12.3056 14.4611 12.1667 14.4 12 14.4C11.8333 14.4 11.6889 14.4611 11.5667 14.5833C11.4556 14.6944 11.4 14.8333 11.4 15C11.4 15.1667 11.4556 15.3111 11.5667 15.4333C11.6889 15.5444 11.8333 15.6 12 15.6ZM11.4 13.6H12.6V10.4H11.4V13.6Z" fill="#212121"/>
</g>
<defs>
<clipPath id="clip0_6013_33858">
<rect width="24" height="24" fill="white"/>
</clipPath>
</defs>`):(w.innerHTML=`<g clip-path="url(#clip0_6083_34804)">
<path d="M11.4 15.2H12.6V11.2H11.4V15.2ZM12 10C12.1667 10 12.3056 9.94444 12.4167 9.83333C12.5389 9.71111 12.6 9.56667 12.6 9.4C12.6 9.23333 12.5389 9.09444 12.4167 8.98333C12.3056 8.86111 12.1667 8.8 12 8.8C11.8333 8.8 11.6889 8.86111 11.5667 8.98333C11.4556 9.09444 11.4 9.23333 11.4 9.4C11.4 9.56667 11.4556 9.71111 11.5667 9.83333C11.6889 9.94444 11.8333 10 12 10ZM12 18.4C11.1222 18.4 10.2944 18.2333 9.51667 17.9C8.73889 17.5667 8.05556 17.1111 7.46667 16.5333C6.88889 15.9444 6.43333 15.2611 6.1 14.4833C5.76667 13.7056 5.6 12.8778 5.6 12C5.6 11.1111 5.76667 10.2833 6.1 9.51667C6.43333 8.73889 6.88889 8.06111 7.46667 7.48333C8.05556 6.89444 8.73889 6.43333 9.51667 6.1C10.2944 5.76667 11.1222 5.6 12 5.6C12.8889 5.6 13.7167 5.76667 14.4833 6.1C15.2611 6.43333 15.9389 6.89444 16.5167 7.48333C17.1056 8.06111 17.5667 8.73889 17.9 9.51667C18.2333 10.2833 18.4 11.1111 18.4 12C18.4 12.8778 18.2333 13.7056 17.9 14.4833C17.5667 15.2611 17.1056 15.9444 16.5167 16.5333C15.9389 17.1111 15.2611 17.5667 14.4833 17.9C13.7167 18.2333 12.8889 18.4 12 18.4ZM12 17.2C13.4444 17.2 14.6722 16.6944 15.6833 15.6833C16.6944 14.6722 17.2 13.4444 17.2 12C17.2 10.5556 16.6944 9.32778 15.6833 8.31667C14.6722 7.30555 13.4444 6.8 12 6.8C10.5556 6.8 9.32778 7.30555 8.31667 8.31667C7.30556 9.32778 6.8 10.5556 6.8 12C6.8 13.4444 7.30556 14.6722 8.31667 15.6833C9.32778 16.6944 10.5556 17.2 12 17.2Z" fill="#212121"/>
</g>
<defs>
<clipPath id="clip0_6083_34804">
<rect width="24" height="24" fill="white"/>
</clipPath>
</defs>`,y.innerText="Preview backend running in this workspace."),y.setAttribute("id",m)}document.readyState==="loading"?window.addEventListener("DOMContentLoaded",p):p()}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function B(){return typeof navigator<"u"&&typeof navigator.userAgent=="string"?navigator.userAgent:""}function oc(){return typeof window<"u"&&!!(window.cordova||window.phonegap||window.PhoneGap)&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i.test(B())}function ic(){return typeof navigator<"u"&&navigator.userAgent==="Cloudflare-Workers"}function ac(){const t=typeof chrome=="object"?chrome.runtime:typeof browser=="object"?browser.runtime:void 0;return typeof t=="object"&&t.id!==void 0}function cc(){return typeof navigator=="object"&&navigator.product==="ReactNative"}function lc(){const t=B();return t.indexOf("MSIE ")>=0||t.indexOf("Trident/")>=0}function dc(){try{return typeof indexedDB=="object"}catch{return!1}}function uc(){return new Promise((t,e)=>{try{let r=!0;const n="validate-browser-context-for-indexeddb-analytics-module",s=self.indexedDB.open(n);s.onsuccess=()=>{s.result.close(),r||self.indexedDB.deleteDatabase(n),t(!0)},s.onupgradeneeded=()=>{r=!1},s.onerror=()=>{var o;e(((o=s.error)==null?void 0:o.message)||"")}}catch(r){e(r)}})}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const hc="FirebaseError";class Ce extends Error{constructor(e,r,n){super(r),this.code=e,this.customData=n,this.name=hc,Object.setPrototypeOf(this,Ce.prototype),Error.captureStackTrace&&Error.captureStackTrace(this,lt.prototype.create)}}class lt{constructor(e,r,n){this.service=e,this.serviceName=r,this.errors=n}create(e,...r){const n=r[0]||{},s=`${this.service}/${e}`,o=this.errors[e],i=o?fc(o,n):"Error",c=`${this.serviceName}: ${i} (${s}).`;return new Ce(s,c,n)}}function fc(t,e){return t.replace(pc,(r,n)=>{const s=e[n];return s!=null?String(s):`<${n}?>`})}const pc=/\{\$([^}]+)}/g;function mc(t){for(const e in t)if(Object.prototype.hasOwnProperty.call(t,e))return!1;return!0}function $e(t,e){if(t===e)return!0;const r=Object.keys(t),n=Object.keys(e);for(const s of r){if(!n.includes(s))return!1;const o=t[s],i=e[s];if(un(o)&&un(i)){if(!$e(o,i))return!1}else if(o!==i)return!1}for(const s of n)if(!r.includes(s))return!1;return!0}function un(t){return t!==null&&typeof t=="object"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function dt(t){const e=[];for(const[r,n]of Object.entries(t))Array.isArray(n)?n.forEach(s=>{e.push(encodeURIComponent(r)+"="+encodeURIComponent(s))}):e.push(encodeURIComponent(r)+"="+encodeURIComponent(n));return e.length?"&"+e.join("&"):""}function Qe(t){const e={};return t.replace(/^\?/,"").split("&").forEach(n=>{if(n){const[s,o]=n.split("=");e[decodeURIComponent(s)]=decodeURIComponent(o)}}),e}function Ze(t){const e=t.indexOf("?");if(!e)return"";const r=t.indexOf("#",e);return t.substring(e,r>0?r:void 0)}function gc(t,e){const r=new bc(t,e);return r.subscribe.bind(r)}class bc{constructor(e,r){this.observers=[],this.unsubscribes=[],this.observerCount=0,this.task=Promise.resolve(),this.finalized=!1,this.onNoObservers=r,this.task.then(()=>{e(this)}).catch(n=>{this.error(n)})}next(e){this.forEachObserver(r=>{r.next(e)})}error(e){this.forEachObserver(r=>{r.error(e)}),this.close(e)}complete(){this.forEachObserver(e=>{e.complete()}),this.close()}subscribe(e,r,n){let s;if(e===void 0&&r===void 0&&n===void 0)throw new Error("Missing Observer.");yc(e,["next","error","complete"])?s=e:s={next:e,error:r,complete:n},s.next===void 0&&(s.next=Yt),s.error===void 0&&(s.error=Yt),s.complete===void 0&&(s.complete=Yt);const o=this.unsubscribeOne.bind(this,this.observers.length);return this.finalized&&this.task.then(()=>{try{this.finalError?s.error(this.finalError):s.complete()}catch{}}),this.observers.push(s),o}unsubscribeOne(e){this.observers===void 0||this.observers[e]===void 0||(delete this.observers[e],this.observerCount-=1,this.observerCount===0&&this.onNoObservers!==void 0&&this.onNoObservers(this))}forEachObserver(e){if(!this.finalized)for(let r=0;r<this.observers.length;r++)this.sendOne(r,e)}sendOne(e,r){this.task.then(()=>{if(this.observers!==void 0&&this.observers[e]!==void 0)try{r(this.observers[e])}catch(n){typeof console<"u"&&console.error&&console.error(n)}})}close(e){this.finalized||(this.finalized=!0,e!==void 0&&(this.finalError=e),this.task.then(()=>{this.observers=void 0,this.onNoObservers=void 0}))}}function yc(t,e){if(typeof t!="object"||t===null)return!1;for(const r of e)if(r in t&&typeof t[r]=="function")return!0;return!1}function Yt(){}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Y(t){return t&&t._delegate?t._delegate:t}class Be{constructor(e,r,n){this.name=e,this.instanceFactory=r,this.type=n,this.multipleInstances=!1,this.serviceProps={},this.instantiationMode="LAZY",this.onInstanceCreated=null}setInstantiationMode(e){return this.instantiationMode=e,this}setMultipleInstances(e){return this.multipleInstances=e,this}setServiceProps(e){return this.serviceProps=e,this}setInstanceCreatedCallback(e){return this.onInstanceCreated=e,this}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ae="[DEFAULT]";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let vc=class{constructor(e,r){this.name=e,this.container=r,this.component=null,this.instances=new Map,this.instancesDeferred=new Map,this.instancesOptions=new Map,this.onInitCallbacks=new Map}get(e){const r=this.normalizeInstanceIdentifier(e);if(!this.instancesDeferred.has(r)){const n=new ec;if(this.instancesDeferred.set(r,n),this.isInitialized(r)||this.shouldAutoInitialize())try{const s=this.getOrInitializeService({instanceIdentifier:r});s&&n.resolve(s)}catch{}}return this.instancesDeferred.get(r).promise}getImmediate(e){const r=this.normalizeInstanceIdentifier(e==null?void 0:e.identifier),n=(e==null?void 0:e.optional)??!1;if(this.isInitialized(r)||this.shouldAutoInitialize())try{return this.getOrInitializeService({instanceIdentifier:r})}catch(s){if(n)return null;throw s}else{if(n)return null;throw Error(`Service ${this.name} is not available`)}}getComponent(){return this.component}setComponent(e){if(e.name!==this.name)throw Error(`Mismatching Component ${e.name} for Provider ${this.name}.`);if(this.component)throw Error(`Component for ${this.name} has already been provided`);if(this.component=e,!!this.shouldAutoInitialize()){if(_c(e))try{this.getOrInitializeService({instanceIdentifier:Ae})}catch{}for(const[r,n]of this.instancesDeferred.entries()){const s=this.normalizeInstanceIdentifier(r);try{const o=this.getOrInitializeService({instanceIdentifier:s});n.resolve(o)}catch{}}}}clearInstance(e=Ae){this.instancesDeferred.delete(e),this.instancesOptions.delete(e),this.instances.delete(e)}async delete(){const e=Array.from(this.instances.values());await Promise.all([...e.filter(r=>"INTERNAL"in r).map(r=>r.INTERNAL.delete()),...e.filter(r=>"_delete"in r).map(r=>r._delete())])}isComponentSet(){return this.component!=null}isInitialized(e=Ae){return this.instances.has(e)}getOptions(e=Ae){return this.instancesOptions.get(e)||{}}initialize(e={}){const{options:r={}}=e,n=this.normalizeInstanceIdentifier(e.instanceIdentifier);if(this.isInitialized(n))throw Error(`${this.name}(${n}) has already been initialized`);if(!this.isComponentSet())throw Error(`Component ${this.name} has not been registered yet`);const s=this.getOrInitializeService({instanceIdentifier:n,options:r});for(const[o,i]of this.instancesDeferred.entries()){const c=this.normalizeInstanceIdentifier(o);n===c&&i.resolve(s)}return s}onInit(e,r){const n=this.normalizeInstanceIdentifier(r),s=this.onInitCallbacks.get(n)??new Set;s.add(e),this.onInitCallbacks.set(n,s);const o=this.instances.get(n);return o&&e(o,n),()=>{s.delete(e)}}invokeOnInitCallbacks(e,r){const n=this.onInitCallbacks.get(r);if(n)for(const s of n)try{s(e,r)}catch{}}getOrInitializeService({instanceIdentifier:e,options:r={}}){let n=this.instances.get(e);if(!n&&this.component&&(n=this.component.instanceFactory(this.container,{instanceIdentifier:wc(e),options:r}),this.instances.set(e,n),this.instancesOptions.set(e,r),this.invokeOnInitCallbacks(n,e),this.component.onInstanceCreated))try{this.component.onInstanceCreated(this.container,e,n)}catch{}return n||null}normalizeInstanceIdentifier(e=Ae){return this.component?this.component.multipleInstances?e:Ae:e}shouldAutoInitialize(){return!!this.component&&this.component.instantiationMode!=="EXPLICIT"}};function wc(t){return t===Ae?void 0:t}function _c(t){return t.instantiationMode==="EAGER"}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ec{constructor(e){this.name=e,this.providers=new Map}addComponent(e){const r=this.getProvider(e.name);if(r.isComponentSet())throw new Error(`Component ${e.name} has already been registered with ${this.name}`);r.setComponent(e)}addOrOverwriteComponent(e){this.getProvider(e.name).isComponentSet()&&this.providers.delete(e.name),this.addComponent(e)}getProvider(e){if(this.providers.has(e))return this.providers.get(e);const r=new vc(e,this);return this.providers.set(e,r),r}getProviders(){return Array.from(this.providers.values())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var O;(function(t){t[t.DEBUG=0]="DEBUG",t[t.VERBOSE=1]="VERBOSE",t[t.INFO=2]="INFO",t[t.WARN=3]="WARN",t[t.ERROR=4]="ERROR",t[t.SILENT=5]="SILENT"})(O||(O={}));const xc={debug:O.DEBUG,verbose:O.VERBOSE,info:O.INFO,warn:O.WARN,error:O.ERROR,silent:O.SILENT},Ic=O.INFO,Sc={[O.DEBUG]:"log",[O.VERBOSE]:"log",[O.INFO]:"info",[O.WARN]:"warn",[O.ERROR]:"error"},Tc=(t,e,...r)=>{if(e<t.logLevel)return;const n=new Date().toISOString(),s=Sc[e];if(s)console[s](`[${n}]  ${t.name}:`,...r);else throw new Error(`Attempted to log a message with an invalid logType (value: ${e})`)};class Os{constructor(e){this.name=e,this._logLevel=Ic,this._logHandler=Tc,this._userLogHandler=null}get logLevel(){return this._logLevel}set logLevel(e){if(!(e in O))throw new TypeError(`Invalid value "${e}" assigned to \`logLevel\``);this._logLevel=e}setLogLevel(e){this._logLevel=typeof e=="string"?xc[e]:e}get logHandler(){return this._logHandler}set logHandler(e){if(typeof e!="function")throw new TypeError("Value assigned to `logHandler` must be a function");this._logHandler=e}get userLogHandler(){return this._userLogHandler}set userLogHandler(e){this._userLogHandler=e}debug(...e){this._userLogHandler&&this._userLogHandler(this,O.DEBUG,...e),this._logHandler(this,O.DEBUG,...e)}log(...e){this._userLogHandler&&this._userLogHandler(this,O.VERBOSE,...e),this._logHandler(this,O.VERBOSE,...e)}info(...e){this._userLogHandler&&this._userLogHandler(this,O.INFO,...e),this._logHandler(this,O.INFO,...e)}warn(...e){this._userLogHandler&&this._userLogHandler(this,O.WARN,...e),this._logHandler(this,O.WARN,...e)}error(...e){this._userLogHandler&&this._userLogHandler(this,O.ERROR,...e),this._logHandler(this,O.ERROR,...e)}}const Cc=(t,e)=>e.some(r=>t instanceof r);let hn,fn;function Pc(){return hn||(hn=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction])}function Rc(){return fn||(fn=[IDBCursor.prototype.advance,IDBCursor.prototype.continue,IDBCursor.prototype.continuePrimaryKey])}const Ds=new WeakMap,dr=new WeakMap,Ls=new WeakMap,Jt=new WeakMap,Rr=new WeakMap;function Ac(t){const e=new Promise((r,n)=>{const s=()=>{t.removeEventListener("success",o),t.removeEventListener("error",i)},o=()=>{r(xe(t.result)),s()},i=()=>{n(t.error),s()};t.addEventListener("success",o),t.addEventListener("error",i)});return e.then(r=>{r instanceof IDBCursor&&Ds.set(r,t)}).catch(()=>{}),Rr.set(e,t),e}function kc(t){if(dr.has(t))return;const e=new Promise((r,n)=>{const s=()=>{t.removeEventListener("complete",o),t.removeEventListener("error",i),t.removeEventListener("abort",i)},o=()=>{r(),s()},i=()=>{n(t.error||new DOMException("AbortError","AbortError")),s()};t.addEventListener("complete",o),t.addEventListener("error",i),t.addEventListener("abort",i)});dr.set(t,e)}let ur={get(t,e,r){if(t instanceof IDBTransaction){if(e==="done")return dr.get(t);if(e==="objectStoreNames")return t.objectStoreNames||Ls.get(t);if(e==="store")return r.objectStoreNames[1]?void 0:r.objectStore(r.objectStoreNames[0])}return xe(t[e])},set(t,e,r){return t[e]=r,!0},has(t,e){return t instanceof IDBTransaction&&(e==="done"||e==="store")?!0:e in t}};function Nc(t){ur=t(ur)}function Oc(t){return t===IDBDatabase.prototype.transaction&&!("objectStoreNames"in IDBTransaction.prototype)?function(e,...r){const n=t.call(Xt(this),e,...r);return Ls.set(n,e.sort?e.sort():[e]),xe(n)}:Rc().includes(t)?function(...e){return t.apply(Xt(this),e),xe(Ds.get(this))}:function(...e){return xe(t.apply(Xt(this),e))}}function Dc(t){return typeof t=="function"?Oc(t):(t instanceof IDBTransaction&&kc(t),Cc(t,Pc())?new Proxy(t,ur):t)}function xe(t){if(t instanceof IDBRequest)return Ac(t);if(Jt.has(t))return Jt.get(t);const e=Dc(t);return e!==t&&(Jt.set(t,e),Rr.set(e,t)),e}const Xt=t=>Rr.get(t);function Lc(t,e,{blocked:r,upgrade:n,blocking:s,terminated:o}={}){const i=indexedDB.open(t,e),c=xe(i);return n&&i.addEventListener("upgradeneeded",l=>{n(xe(i.result),l.oldVersion,l.newVersion,xe(i.transaction),l)}),r&&i.addEventListener("blocked",l=>r(l.oldVersion,l.newVersion,l)),c.then(l=>{o&&l.addEventListener("close",()=>o()),s&&l.addEventListener("versionchange",d=>s(d.oldVersion,d.newVersion,d))}).catch(()=>{}),c}const Mc=["get","getKey","getAll","getAllKeys","count"],jc=["put","add","delete","clear"],Qt=new Map;function pn(t,e){if(!(t instanceof IDBDatabase&&!(e in t)&&typeof e=="string"))return;if(Qt.get(e))return Qt.get(e);const r=e.replace(/FromIndex$/,""),n=e!==r,s=jc.includes(r);if(!(r in(n?IDBIndex:IDBObjectStore).prototype)||!(s||Mc.includes(r)))return;const o=async function(i,...c){const l=this.transaction(i,s?"readwrite":"readonly");let d=l.store;return n&&(d=d.index(c.shift())),(await Promise.all([d[r](...c),s&&l.done]))[0]};return Qt.set(e,o),o}Nc(t=>({...t,get:(e,r,n)=>pn(e,r)||t.get(e,r,n),has:(e,r)=>!!pn(e,r)||t.has(e,r)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Uc{constructor(e){this.container=e}getPlatformInfoString(){return this.container.getProviders().map(r=>{if(Fc(r)){const n=r.getImmediate();return`${n.library}/${n.version}`}else return null}).filter(r=>r).join(" ")}}function Fc(t){const e=t.getComponent();return(e==null?void 0:e.type)==="VERSION"}const hr="@firebase/app",mn="0.14.3";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const he=new Os("@firebase/app"),Vc="@firebase/app-compat",zc="@firebase/analytics-compat",$c="@firebase/analytics",Bc="@firebase/app-check-compat",Hc="@firebase/app-check",Wc="@firebase/auth",qc="@firebase/auth-compat",Kc="@firebase/database",Gc="@firebase/data-connect",Yc="@firebase/database-compat",Jc="@firebase/functions",Xc="@firebase/functions-compat",Qc="@firebase/installations",Zc="@firebase/installations-compat",el="@firebase/messaging",tl="@firebase/messaging-compat",rl="@firebase/performance",nl="@firebase/performance-compat",sl="@firebase/remote-config",ol="@firebase/remote-config-compat",il="@firebase/storage",al="@firebase/storage-compat",cl="@firebase/firestore",ll="@firebase/ai",dl="@firebase/firestore-compat",ul="firebase",hl="12.3.0";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const fr="[DEFAULT]",fl={[hr]:"fire-core",[Vc]:"fire-core-compat",[$c]:"fire-analytics",[zc]:"fire-analytics-compat",[Hc]:"fire-app-check",[Bc]:"fire-app-check-compat",[Wc]:"fire-auth",[qc]:"fire-auth-compat",[Kc]:"fire-rtdb",[Gc]:"fire-data-connect",[Yc]:"fire-rtdb-compat",[Jc]:"fire-fn",[Xc]:"fire-fn-compat",[Qc]:"fire-iid",[Zc]:"fire-iid-compat",[el]:"fire-fcm",[tl]:"fire-fcm-compat",[rl]:"fire-perf",[nl]:"fire-perf-compat",[sl]:"fire-rc",[ol]:"fire-rc-compat",[il]:"fire-gcs",[al]:"fire-gcs-compat",[cl]:"fire-fst",[dl]:"fire-fst-compat",[ll]:"fire-vertex","fire-js":"fire-js",[ul]:"fire-js-all"};/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ct=new Map,pl=new Map,pr=new Map;function gn(t,e){try{t.container.addComponent(e)}catch(r){he.debug(`Component ${e.name} failed to register with FirebaseApp ${t.name}`,r)}}function st(t){const e=t.name;if(pr.has(e))return he.debug(`There were multiple attempts to register component ${e}.`),!1;pr.set(e,t);for(const r of Ct.values())gn(r,t);for(const r of pl.values())gn(r,t);return!0}function Ms(t,e){const r=t.container.getProvider("heartbeat").getImmediate({optional:!0});return r&&r.triggerHeartbeat(),t.container.getProvider(e)}function K(t){return t==null?!1:t.settings!==void 0}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ml={"no-app":"No Firebase App '{$appName}' has been created - call initializeApp() first","bad-app-name":"Illegal App name: '{$appName}'","duplicate-app":"Firebase App named '{$appName}' already exists with different options or config","app-deleted":"Firebase App named '{$appName}' already deleted","server-app-deleted":"Firebase Server App has been deleted","no-options":"Need to provide options, when not being deployed to hosting via source.","invalid-app-argument":"firebase.{$appName}() takes either no argument or a Firebase App instance.","invalid-log-argument":"First argument to `onLog` must be null or a function.","idb-open":"Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.","idb-get":"Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.","idb-set":"Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.","idb-delete":"Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}.","finalization-registry-not-supported":"FirebaseServerApp deleteOnDeref field defined but the JS runtime does not support FinalizationRegistry.","invalid-server-app-environment":"FirebaseServerApp is not for use in browser environments."},Ie=new lt("app","Firebase",ml);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class gl{constructor(e,r,n){this._isDeleted=!1,this._options={...e},this._config={...r},this._name=r.name,this._automaticDataCollectionEnabled=r.automaticDataCollectionEnabled,this._container=n,this.container.addComponent(new Be("app",()=>this,"PUBLIC"))}get automaticDataCollectionEnabled(){return this.checkDestroyed(),this._automaticDataCollectionEnabled}set automaticDataCollectionEnabled(e){this.checkDestroyed(),this._automaticDataCollectionEnabled=e}get name(){return this.checkDestroyed(),this._name}get options(){return this.checkDestroyed(),this._options}get config(){return this.checkDestroyed(),this._config}get container(){return this._container}get isDeleted(){return this._isDeleted}set isDeleted(e){this._isDeleted=e}checkDestroyed(){if(this.isDeleted)throw Ie.create("app-deleted",{appName:this._name})}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ut=hl;function js(t,e={}){let r=t;typeof e!="object"&&(e={name:e});const n={name:fr,automaticDataCollectionEnabled:!0,...e},s=n.name;if(typeof s!="string"||!s)throw Ie.create("bad-app-name",{appName:String(s)});if(r||(r=ks()),!r)throw Ie.create("no-options");const o=Ct.get(s);if(o){if($e(r,o.options)&&$e(n,o.config))return o;throw Ie.create("duplicate-app",{appName:s})}const i=new Ec(s);for(const l of pr.values())i.addComponent(l);const c=new gl(r,n,i);return Ct.set(s,c),c}function bl(t=fr){const e=Ct.get(t);if(!e&&t===fr&&ks())return js();if(!e)throw Ie.create("no-app",{appName:t});return e}function Me(t,e,r){let n=fl[t]??t;r&&(n+=`-${r}`);const s=n.match(/\s|\//),o=e.match(/\s|\//);if(s||o){const i=[`Unable to register library "${n}" with version "${e}":`];s&&i.push(`library name "${n}" contains illegal characters (whitespace or "/")`),s&&o&&i.push("and"),o&&i.push(`version name "${e}" contains illegal characters (whitespace or "/")`),he.warn(i.join(" "));return}st(new Be(`${n}-version`,()=>({library:n,version:e}),"VERSION"))}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const yl="firebase-heartbeat-database",vl=1,ot="firebase-heartbeat-store";let Zt=null;function Us(){return Zt||(Zt=Lc(yl,vl,{upgrade:(t,e)=>{switch(e){case 0:try{t.createObjectStore(ot)}catch(r){console.warn(r)}}}}).catch(t=>{throw Ie.create("idb-open",{originalErrorMessage:t.message})})),Zt}async function wl(t){try{const r=(await Us()).transaction(ot),n=await r.objectStore(ot).get(Fs(t));return await r.done,n}catch(e){if(e instanceof Ce)he.warn(e.message);else{const r=Ie.create("idb-get",{originalErrorMessage:e==null?void 0:e.message});he.warn(r.message)}}}async function bn(t,e){try{const n=(await Us()).transaction(ot,"readwrite");await n.objectStore(ot).put(e,Fs(t)),await n.done}catch(r){if(r instanceof Ce)he.warn(r.message);else{const n=Ie.create("idb-set",{originalErrorMessage:r==null?void 0:r.message});he.warn(n.message)}}}function Fs(t){return`${t.name}!${t.options.appId}`}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const _l=1024,El=30;class xl{constructor(e){this.container=e,this._heartbeatsCache=null;const r=this.container.getProvider("app").getImmediate();this._storage=new Sl(r),this._heartbeatsCachePromise=this._storage.read().then(n=>(this._heartbeatsCache=n,n))}async triggerHeartbeat(){var e,r;try{const s=this.container.getProvider("platform-logger").getImmediate().getPlatformInfoString(),o=yn();if(((e=this._heartbeatsCache)==null?void 0:e.heartbeats)==null&&(this._heartbeatsCache=await this._heartbeatsCachePromise,((r=this._heartbeatsCache)==null?void 0:r.heartbeats)==null)||this._heartbeatsCache.lastSentHeartbeatDate===o||this._heartbeatsCache.heartbeats.some(i=>i.date===o))return;if(this._heartbeatsCache.heartbeats.push({date:o,agent:s}),this._heartbeatsCache.heartbeats.length>El){const i=Tl(this._heartbeatsCache.heartbeats);this._heartbeatsCache.heartbeats.splice(i,1)}return this._storage.overwrite(this._heartbeatsCache)}catch(n){he.warn(n)}}async getHeartbeatsHeader(){var e;try{if(this._heartbeatsCache===null&&await this._heartbeatsCachePromise,((e=this._heartbeatsCache)==null?void 0:e.heartbeats)==null||this._heartbeatsCache.heartbeats.length===0)return"";const r=yn(),{heartbeatsToSend:n,unsentEntries:s}=Il(this._heartbeatsCache.heartbeats),o=Rs(JSON.stringify({version:2,heartbeats:n}));return this._heartbeatsCache.lastSentHeartbeatDate=r,s.length>0?(this._heartbeatsCache.heartbeats=s,await this._storage.overwrite(this._heartbeatsCache)):(this._heartbeatsCache.heartbeats=[],this._storage.overwrite(this._heartbeatsCache)),o}catch(r){return he.warn(r),""}}}function yn(){return new Date().toISOString().substring(0,10)}function Il(t,e=_l){const r=[];let n=t.slice();for(const s of t){const o=r.find(i=>i.agent===s.agent);if(o){if(o.dates.push(s.date),vn(r)>e){o.dates.pop();break}}else if(r.push({agent:s.agent,dates:[s.date]}),vn(r)>e){r.pop();break}n=n.slice(1)}return{heartbeatsToSend:r,unsentEntries:n}}class Sl{constructor(e){this.app=e,this._canUseIndexedDBPromise=this.runIndexedDBEnvironmentCheck()}async runIndexedDBEnvironmentCheck(){return dc()?uc().then(()=>!0).catch(()=>!1):!1}async read(){if(await this._canUseIndexedDBPromise){const r=await wl(this.app);return r!=null&&r.heartbeats?r:{heartbeats:[]}}else return{heartbeats:[]}}async overwrite(e){if(await this._canUseIndexedDBPromise){const n=await this.read();return bn(this.app,{lastSentHeartbeatDate:e.lastSentHeartbeatDate??n.lastSentHeartbeatDate,heartbeats:e.heartbeats})}else return}async add(e){if(await this._canUseIndexedDBPromise){const n=await this.read();return bn(this.app,{lastSentHeartbeatDate:e.lastSentHeartbeatDate??n.lastSentHeartbeatDate,heartbeats:[...n.heartbeats,...e.heartbeats]})}else return}}function vn(t){return Rs(JSON.stringify({version:2,heartbeats:t})).length}function Tl(t){if(t.length===0)return-1;let e=0,r=t[0].date;for(let n=1;n<t.length;n++)t[n].date<r&&(r=t[n].date,e=n);return e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Cl(t){st(new Be("platform-logger",e=>new Uc(e),"PRIVATE")),st(new Be("heartbeat",e=>new xl(e),"PRIVATE")),Me(hr,mn,t),Me(hr,mn,"esm2020"),Me("fire-js","")}Cl("");var Pl="firebase",Rl="12.3.0";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */Me(Pl,Rl,"app");function Vs(){return{"dependent-sdk-initialized-before-auth":"Another Firebase SDK was initialized and is trying to use Auth before Auth is initialized. Please be sure to call `initializeAuth` or `getAuth` before starting any other Firebase SDK."}}const Al=Vs,zs=new lt("auth","Firebase",Vs());/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Pt=new Os("@firebase/auth");function kl(t,...e){Pt.logLevel<=O.WARN&&Pt.warn(`Auth (${ut}): ${t}`,...e)}function _t(t,...e){Pt.logLevel<=O.ERROR&&Pt.error(`Auth (${ut}): ${t}`,...e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function G(t,...e){throw Ar(t,...e)}function te(t,...e){return Ar(t,...e)}function $s(t,e,r){const n={...Al(),[e]:r};return new lt("auth","Firebase",n).create(e,{appName:t.name})}function re(t){return $s(t,"operation-not-supported-in-this-environment","Operations that alter the current user are not supported in conjunction with FirebaseServerApp")}function Ar(t,...e){if(typeof t!="string"){const r=e[0],n=[...e.slice(1)];return n[0]&&(n[0].appName=t.name),t._errorFactory.create(r,...n)}return zs.create(t,...e)}function _(t,e,...r){if(!t)throw Ar(e,...r)}function de(t){const e="INTERNAL ASSERTION FAILED: "+t;throw _t(e),new Error(e)}function fe(t,e){t||de(e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function mr(){var t;return typeof self<"u"&&((t=self.location)==null?void 0:t.href)||""}function Nl(){return wn()==="http:"||wn()==="https:"}function wn(){var t;return typeof self<"u"&&((t=self.location)==null?void 0:t.protocol)||null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ol(){return typeof navigator<"u"&&navigator&&"onLine"in navigator&&typeof navigator.onLine=="boolean"&&(Nl()||ac()||"connection"in navigator)?navigator.onLine:!0}function Dl(){if(typeof navigator>"u")return null;const t=navigator;return t.languages&&t.languages[0]||t.language||null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ht{constructor(e,r){this.shortDelay=e,this.longDelay=r,fe(r>e,"Short delay should be less than long delay!"),this.isMobile=oc()||cc()}get(){return Ol()?this.isMobile?this.longDelay:this.shortDelay:Math.min(5e3,this.shortDelay)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function kr(t,e){fe(t.emulator,"Emulator should always be set here");const{url:r}=t.emulator;return e?`${r}${e.startsWith("/")?e.slice(1):e}`:r}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Bs{static initialize(e,r,n){this.fetchImpl=e,r&&(this.headersImpl=r),n&&(this.responseImpl=n)}static fetch(){if(this.fetchImpl)return this.fetchImpl;if(typeof self<"u"&&"fetch"in self)return self.fetch;if(typeof globalThis<"u"&&globalThis.fetch)return globalThis.fetch;if(typeof fetch<"u")return fetch;de("Could not find fetch implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static headers(){if(this.headersImpl)return this.headersImpl;if(typeof self<"u"&&"Headers"in self)return self.Headers;if(typeof globalThis<"u"&&globalThis.Headers)return globalThis.Headers;if(typeof Headers<"u")return Headers;de("Could not find Headers implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static response(){if(this.responseImpl)return this.responseImpl;if(typeof self<"u"&&"Response"in self)return self.Response;if(typeof globalThis<"u"&&globalThis.Response)return globalThis.Response;if(typeof Response<"u")return Response;de("Could not find Response implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ll={CREDENTIAL_MISMATCH:"custom-token-mismatch",MISSING_CUSTOM_TOKEN:"internal-error",INVALID_IDENTIFIER:"invalid-email",MISSING_CONTINUE_URI:"internal-error",INVALID_PASSWORD:"wrong-password",MISSING_PASSWORD:"missing-password",INVALID_LOGIN_CREDENTIALS:"invalid-credential",EMAIL_EXISTS:"email-already-in-use",PASSWORD_LOGIN_DISABLED:"operation-not-allowed",INVALID_IDP_RESPONSE:"invalid-credential",INVALID_PENDING_TOKEN:"invalid-credential",FEDERATED_USER_ID_ALREADY_LINKED:"credential-already-in-use",MISSING_REQ_TYPE:"internal-error",EMAIL_NOT_FOUND:"user-not-found",RESET_PASSWORD_EXCEED_LIMIT:"too-many-requests",EXPIRED_OOB_CODE:"expired-action-code",INVALID_OOB_CODE:"invalid-action-code",MISSING_OOB_CODE:"internal-error",CREDENTIAL_TOO_OLD_LOGIN_AGAIN:"requires-recent-login",INVALID_ID_TOKEN:"invalid-user-token",TOKEN_EXPIRED:"user-token-expired",USER_NOT_FOUND:"user-token-expired",TOO_MANY_ATTEMPTS_TRY_LATER:"too-many-requests",PASSWORD_DOES_NOT_MEET_REQUIREMENTS:"password-does-not-meet-requirements",INVALID_CODE:"invalid-verification-code",INVALID_SESSION_INFO:"invalid-verification-id",INVALID_TEMPORARY_PROOF:"invalid-credential",MISSING_SESSION_INFO:"missing-verification-id",SESSION_EXPIRED:"code-expired",MISSING_ANDROID_PACKAGE_NAME:"missing-android-pkg-name",UNAUTHORIZED_DOMAIN:"unauthorized-continue-uri",INVALID_OAUTH_CLIENT_ID:"invalid-oauth-client-id",ADMIN_ONLY_OPERATION:"admin-restricted-operation",INVALID_MFA_PENDING_CREDENTIAL:"invalid-multi-factor-session",MFA_ENROLLMENT_NOT_FOUND:"multi-factor-info-not-found",MISSING_MFA_ENROLLMENT_ID:"missing-multi-factor-info",MISSING_MFA_PENDING_CREDENTIAL:"missing-multi-factor-session",SECOND_FACTOR_EXISTS:"second-factor-already-in-use",SECOND_FACTOR_LIMIT_EXCEEDED:"maximum-second-factor-count-exceeded",BLOCKING_FUNCTION_ERROR_RESPONSE:"internal-error",RECAPTCHA_NOT_ENABLED:"recaptcha-not-enabled",MISSING_RECAPTCHA_TOKEN:"missing-recaptcha-token",INVALID_RECAPTCHA_TOKEN:"invalid-recaptcha-token",INVALID_RECAPTCHA_ACTION:"invalid-recaptcha-action",MISSING_CLIENT_TYPE:"missing-client-type",MISSING_RECAPTCHA_VERSION:"missing-recaptcha-version",INVALID_RECAPTCHA_VERSION:"invalid-recaptcha-version",INVALID_REQ_TYPE:"invalid-req-type"};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ml=["/v1/accounts:signInWithCustomToken","/v1/accounts:signInWithEmailLink","/v1/accounts:signInWithIdp","/v1/accounts:signInWithPassword","/v1/accounts:signInWithPhoneNumber","/v1/token"],jl=new ht(3e4,6e4);function oe(t,e){return t.tenantId&&!e.tenantId?{...e,tenantId:t.tenantId}:e}async function pe(t,e,r,n,s={}){return Hs(t,s,async()=>{let o={},i={};n&&(e==="GET"?i=n:o={body:JSON.stringify(n)});const c=dt({key:t.config.apiKey,...i}).slice(1),l=await t._getAdditionalHeaders();l["Content-Type"]="application/json",t.languageCode&&(l["X-Firebase-Locale"]=t.languageCode);const d={method:e,headers:l,...o};return ic()||(d.referrerPolicy="no-referrer"),t.emulatorConfig&&Ut(t.emulatorConfig.host)&&(d.credentials="include"),Bs.fetch()(await Ws(t,t.config.apiHost,r,c),d)})}async function Hs(t,e,r){t._canInitEmulator=!1;const n={...Ll,...e};try{const s=new Fl(t),o=await Promise.race([r(),s.promise]);s.clearNetworkTimeout();const i=await o.json();if("needConfirmation"in i)throw vt(t,"account-exists-with-different-credential",i);if(o.ok&&!("errorMessage"in i))return i;{const c=o.ok?i.errorMessage:i.error.message,[l,d]=c.split(" : ");if(l==="FEDERATED_USER_ID_ALREADY_LINKED")throw vt(t,"credential-already-in-use",i);if(l==="EMAIL_EXISTS")throw vt(t,"email-already-in-use",i);if(l==="USER_DISABLED")throw vt(t,"user-disabled",i);const f=n[l]||l.toLowerCase().replace(/[_\s]+/g,"-");if(d)throw $s(t,f,d);G(t,f)}}catch(s){if(s instanceof Ce)throw s;G(t,"network-request-failed",{message:String(s)})}}async function Ke(t,e,r,n,s={}){const o=await pe(t,e,r,n,s);return"mfaPendingCredential"in o&&G(t,"multi-factor-auth-required",{_serverResponse:o}),o}async function Ws(t,e,r,n){const s=`${e}${r}?${n}`,o=t,i=o.config.emulator?kr(t.config,s):`${t.config.apiScheme}://${s}`;return Ml.includes(r)&&(await o._persistenceManagerAvailable,o._getPersistenceType()==="COOKIE")?o._getPersistence()._getFinalTarget(i).toString():i}function Ul(t){switch(t){case"ENFORCE":return"ENFORCE";case"AUDIT":return"AUDIT";case"OFF":return"OFF";default:return"ENFORCEMENT_STATE_UNSPECIFIED"}}class Fl{clearNetworkTimeout(){clearTimeout(this.timer)}constructor(e){this.auth=e,this.timer=null,this.promise=new Promise((r,n)=>{this.timer=setTimeout(()=>n(te(this.auth,"network-request-failed")),jl.get())})}}function vt(t,e,r){const n={appName:t.name};r.email&&(n.email=r.email),r.phoneNumber&&(n.phoneNumber=r.phoneNumber);const s=te(t,e,n);return s.customData._tokenResponse=r,s}function _n(t){return t!==void 0&&t.enterprise!==void 0}class Vl{constructor(e){if(this.siteKey="",this.recaptchaEnforcementState=[],e.recaptchaKey===void 0)throw new Error("recaptchaKey undefined");this.siteKey=e.recaptchaKey.split("/")[3],this.recaptchaEnforcementState=e.recaptchaEnforcementState}getProviderEnforcementState(e){if(!this.recaptchaEnforcementState||this.recaptchaEnforcementState.length===0)return null;for(const r of this.recaptchaEnforcementState)if(r.provider&&r.provider===e)return Ul(r.enforcementState);return null}isProviderEnabled(e){return this.getProviderEnforcementState(e)==="ENFORCE"||this.getProviderEnforcementState(e)==="AUDIT"}isAnyProviderEnabled(){return this.isProviderEnabled("EMAIL_PASSWORD_PROVIDER")||this.isProviderEnabled("PHONE_PROVIDER")}}async function zl(t,e){return pe(t,"GET","/v2/recaptchaConfig",oe(t,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function $l(t,e){return pe(t,"POST","/v1/accounts:delete",e)}async function Rt(t,e){return pe(t,"POST","/v1/accounts:lookup",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function rt(t){if(t)try{const e=new Date(Number(t));if(!isNaN(e.getTime()))return e.toUTCString()}catch{}}async function Bl(t,e=!1){const r=Y(t),n=await r.getIdToken(e),s=Nr(n);_(s&&s.exp&&s.auth_time&&s.iat,r.auth,"internal-error");const o=typeof s.firebase=="object"?s.firebase:void 0,i=o==null?void 0:o.sign_in_provider;return{claims:s,token:n,authTime:rt(er(s.auth_time)),issuedAtTime:rt(er(s.iat)),expirationTime:rt(er(s.exp)),signInProvider:i||null,signInSecondFactor:(o==null?void 0:o.sign_in_second_factor)||null}}function er(t){return Number(t)*1e3}function Nr(t){const[e,r,n]=t.split(".");if(e===void 0||r===void 0||n===void 0)return _t("JWT malformed, contained fewer than 3 sections"),null;try{const s=As(r);return s?JSON.parse(s):(_t("Failed to decode base64 JWT payload"),null)}catch(s){return _t("Caught error parsing JWT payload as JSON",s==null?void 0:s.toString()),null}}function En(t){const e=Nr(t);return _(e,"internal-error"),_(typeof e.exp<"u","internal-error"),_(typeof e.iat<"u","internal-error"),Number(e.exp)-Number(e.iat)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function it(t,e,r=!1){if(r)return e;try{return await e}catch(n){throw n instanceof Ce&&Hl(n)&&t.auth.currentUser===t&&await t.auth.signOut(),n}}function Hl({code:t}){return t==="auth/user-disabled"||t==="auth/user-token-expired"}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Wl{constructor(e){this.user=e,this.isRunning=!1,this.timerId=null,this.errorBackoff=3e4}_start(){this.isRunning||(this.isRunning=!0,this.schedule())}_stop(){this.isRunning&&(this.isRunning=!1,this.timerId!==null&&clearTimeout(this.timerId))}getInterval(e){if(e){const r=this.errorBackoff;return this.errorBackoff=Math.min(this.errorBackoff*2,96e4),r}else{this.errorBackoff=3e4;const n=(this.user.stsTokenManager.expirationTime??0)-Date.now()-3e5;return Math.max(0,n)}}schedule(e=!1){if(!this.isRunning)return;const r=this.getInterval(e);this.timerId=setTimeout(async()=>{await this.iteration()},r)}async iteration(){try{await this.user.getIdToken(!0)}catch(e){(e==null?void 0:e.code)==="auth/network-request-failed"&&this.schedule(!0);return}this.schedule()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class gr{constructor(e,r){this.createdAt=e,this.lastLoginAt=r,this._initializeTime()}_initializeTime(){this.lastSignInTime=rt(this.lastLoginAt),this.creationTime=rt(this.createdAt)}_copy(e){this.createdAt=e.createdAt,this.lastLoginAt=e.lastLoginAt,this._initializeTime()}toJSON(){return{createdAt:this.createdAt,lastLoginAt:this.lastLoginAt}}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function At(t){var p;const e=t.auth,r=await t.getIdToken(),n=await it(t,Rt(e,{idToken:r}));_(n==null?void 0:n.users.length,e,"internal-error");const s=n.users[0];t._notifyReloadListener(s);const o=(p=s.providerUserInfo)!=null&&p.length?qs(s.providerUserInfo):[],i=Kl(t.providerData,o),c=t.isAnonymous,l=!(t.email&&s.passwordHash)&&!(i!=null&&i.length),d=c?l:!1,f={uid:s.localId,displayName:s.displayName||null,photoURL:s.photoUrl||null,email:s.email||null,emailVerified:s.emailVerified||!1,phoneNumber:s.phoneNumber||null,tenantId:s.tenantId||null,providerData:i,metadata:new gr(s.createdAt,s.lastLoginAt),isAnonymous:d};Object.assign(t,f)}async function ql(t){const e=Y(t);await At(e),await e.auth._persistUserIfCurrent(e),e.auth._notifyListenersIfCurrent(e)}function Kl(t,e){return[...t.filter(n=>!e.some(s=>s.providerId===n.providerId)),...e]}function qs(t){return t.map(({providerId:e,...r})=>({providerId:e,uid:r.rawId||"",displayName:r.displayName||null,email:r.email||null,phoneNumber:r.phoneNumber||null,photoURL:r.photoUrl||null}))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Gl(t,e){const r=await Hs(t,{},async()=>{const n=dt({grant_type:"refresh_token",refresh_token:e}).slice(1),{tokenApiHost:s,apiKey:o}=t.config,i=await Ws(t,s,"/v1/token",`key=${o}`),c=await t._getAdditionalHeaders();c["Content-Type"]="application/x-www-form-urlencoded";const l={method:"POST",headers:c,body:n};return t.emulatorConfig&&Ut(t.emulatorConfig.host)&&(l.credentials="include"),Bs.fetch()(i,l)});return{accessToken:r.access_token,expiresIn:r.expires_in,refreshToken:r.refresh_token}}async function Yl(t,e){return pe(t,"POST","/v2/accounts:revokeToken",oe(t,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class je{constructor(){this.refreshToken=null,this.accessToken=null,this.expirationTime=null}get isExpired(){return!this.expirationTime||Date.now()>this.expirationTime-3e4}updateFromServerResponse(e){_(e.idToken,"internal-error"),_(typeof e.idToken<"u","internal-error"),_(typeof e.refreshToken<"u","internal-error");const r="expiresIn"in e&&typeof e.expiresIn<"u"?Number(e.expiresIn):En(e.idToken);this.updateTokensAndExpiration(e.idToken,e.refreshToken,r)}updateFromIdToken(e){_(e.length!==0,"internal-error");const r=En(e);this.updateTokensAndExpiration(e,null,r)}async getToken(e,r=!1){return!r&&this.accessToken&&!this.isExpired?this.accessToken:(_(this.refreshToken,e,"user-token-expired"),this.refreshToken?(await this.refresh(e,this.refreshToken),this.accessToken):null)}clearRefreshToken(){this.refreshToken=null}async refresh(e,r){const{accessToken:n,refreshToken:s,expiresIn:o}=await Gl(e,r);this.updateTokensAndExpiration(n,s,Number(o))}updateTokensAndExpiration(e,r,n){this.refreshToken=r||null,this.accessToken=e||null,this.expirationTime=Date.now()+n*1e3}static fromJSON(e,r){const{refreshToken:n,accessToken:s,expirationTime:o}=r,i=new je;return n&&(_(typeof n=="string","internal-error",{appName:e}),i.refreshToken=n),s&&(_(typeof s=="string","internal-error",{appName:e}),i.accessToken=s),o&&(_(typeof o=="number","internal-error",{appName:e}),i.expirationTime=o),i}toJSON(){return{refreshToken:this.refreshToken,accessToken:this.accessToken,expirationTime:this.expirationTime}}_assign(e){this.accessToken=e.accessToken,this.refreshToken=e.refreshToken,this.expirationTime=e.expirationTime}_clone(){return Object.assign(new je,this.toJSON())}_performRefresh(){return de("not implemented")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function be(t,e){_(typeof t=="string"||typeof t>"u","internal-error",{appName:e})}class Z{constructor({uid:e,auth:r,stsTokenManager:n,...s}){this.providerId="firebase",this.proactiveRefresh=new Wl(this),this.reloadUserInfo=null,this.reloadListener=null,this.uid=e,this.auth=r,this.stsTokenManager=n,this.accessToken=n.accessToken,this.displayName=s.displayName||null,this.email=s.email||null,this.emailVerified=s.emailVerified||!1,this.phoneNumber=s.phoneNumber||null,this.photoURL=s.photoURL||null,this.isAnonymous=s.isAnonymous||!1,this.tenantId=s.tenantId||null,this.providerData=s.providerData?[...s.providerData]:[],this.metadata=new gr(s.createdAt||void 0,s.lastLoginAt||void 0)}async getIdToken(e){const r=await it(this,this.stsTokenManager.getToken(this.auth,e));return _(r,this.auth,"internal-error"),this.accessToken!==r&&(this.accessToken=r,await this.auth._persistUserIfCurrent(this),this.auth._notifyListenersIfCurrent(this)),r}getIdTokenResult(e){return Bl(this,e)}reload(){return ql(this)}_assign(e){this!==e&&(_(this.uid===e.uid,this.auth,"internal-error"),this.displayName=e.displayName,this.photoURL=e.photoURL,this.email=e.email,this.emailVerified=e.emailVerified,this.phoneNumber=e.phoneNumber,this.isAnonymous=e.isAnonymous,this.tenantId=e.tenantId,this.providerData=e.providerData.map(r=>({...r})),this.metadata._copy(e.metadata),this.stsTokenManager._assign(e.stsTokenManager))}_clone(e){const r=new Z({...this,auth:e,stsTokenManager:this.stsTokenManager._clone()});return r.metadata._copy(this.metadata),r}_onReload(e){_(!this.reloadListener,this.auth,"internal-error"),this.reloadListener=e,this.reloadUserInfo&&(this._notifyReloadListener(this.reloadUserInfo),this.reloadUserInfo=null)}_notifyReloadListener(e){this.reloadListener?this.reloadListener(e):this.reloadUserInfo=e}_startProactiveRefresh(){this.proactiveRefresh._start()}_stopProactiveRefresh(){this.proactiveRefresh._stop()}async _updateTokensIfNecessary(e,r=!1){let n=!1;e.idToken&&e.idToken!==this.stsTokenManager.accessToken&&(this.stsTokenManager.updateFromServerResponse(e),n=!0),r&&await At(this),await this.auth._persistUserIfCurrent(this),n&&this.auth._notifyListenersIfCurrent(this)}async delete(){if(K(this.auth.app))return Promise.reject(re(this.auth));const e=await this.getIdToken();return await it(this,$l(this.auth,{idToken:e})),this.stsTokenManager.clearRefreshToken(),this.auth.signOut()}toJSON(){return{uid:this.uid,email:this.email||void 0,emailVerified:this.emailVerified,displayName:this.displayName||void 0,isAnonymous:this.isAnonymous,photoURL:this.photoURL||void 0,phoneNumber:this.phoneNumber||void 0,tenantId:this.tenantId||void 0,providerData:this.providerData.map(e=>({...e})),stsTokenManager:this.stsTokenManager.toJSON(),_redirectEventId:this._redirectEventId,...this.metadata.toJSON(),apiKey:this.auth.config.apiKey,appName:this.auth.name}}get refreshToken(){return this.stsTokenManager.refreshToken||""}static _fromJSON(e,r){const n=r.displayName??void 0,s=r.email??void 0,o=r.phoneNumber??void 0,i=r.photoURL??void 0,c=r.tenantId??void 0,l=r._redirectEventId??void 0,d=r.createdAt??void 0,f=r.lastLoginAt??void 0,{uid:p,emailVerified:h,isAnonymous:m,providerData:y,stsTokenManager:b}=r;_(p&&b,e,"internal-error");const g=je.fromJSON(this.name,b);_(typeof p=="string",e,"internal-error"),be(n,e.name),be(s,e.name),_(typeof h=="boolean",e,"internal-error"),_(typeof m=="boolean",e,"internal-error"),be(o,e.name),be(i,e.name),be(c,e.name),be(l,e.name),be(d,e.name),be(f,e.name);const v=new Z({uid:p,auth:e,email:s,emailVerified:h,displayName:n,isAnonymous:m,photoURL:i,phoneNumber:o,tenantId:c,stsTokenManager:g,createdAt:d,lastLoginAt:f});return y&&Array.isArray(y)&&(v.providerData=y.map(w=>({...w}))),l&&(v._redirectEventId=l),v}static async _fromIdTokenResponse(e,r,n=!1){const s=new je;s.updateFromServerResponse(r);const o=new Z({uid:r.localId,auth:e,stsTokenManager:s,isAnonymous:n});return await At(o),o}static async _fromGetAccountInfoResponse(e,r,n){const s=r.users[0];_(s.localId!==void 0,"internal-error");const o=s.providerUserInfo!==void 0?qs(s.providerUserInfo):[],i=!(s.email&&s.passwordHash)&&!(o!=null&&o.length),c=new je;c.updateFromIdToken(n);const l=new Z({uid:s.localId,auth:e,stsTokenManager:c,isAnonymous:i}),d={uid:s.localId,displayName:s.displayName||null,photoURL:s.photoUrl||null,email:s.email||null,emailVerified:s.emailVerified||!1,phoneNumber:s.phoneNumber||null,tenantId:s.tenantId||null,providerData:o,metadata:new gr(s.createdAt,s.lastLoginAt),isAnonymous:!(s.email&&s.passwordHash)&&!(o!=null&&o.length)};return Object.assign(l,d),l}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const xn=new Map;function ue(t){fe(t instanceof Function,"Expected a class definition");let e=xn.get(t);return e?(fe(e instanceof t,"Instance stored in cache mismatched with class"),e):(e=new t,xn.set(t,e),e)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ks{constructor(){this.type="NONE",this.storage={}}async _isAvailable(){return!0}async _set(e,r){this.storage[e]=r}async _get(e){const r=this.storage[e];return r===void 0?null:r}async _remove(e){delete this.storage[e]}_addListener(e,r){}_removeListener(e,r){}}Ks.type="NONE";const In=Ks;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Et(t,e,r){return`firebase:${t}:${e}:${r}`}class Ue{constructor(e,r,n){this.persistence=e,this.auth=r,this.userKey=n;const{config:s,name:o}=this.auth;this.fullUserKey=Et(this.userKey,s.apiKey,o),this.fullPersistenceKey=Et("persistence",s.apiKey,o),this.boundEventHandler=r._onStorageEvent.bind(r),this.persistence._addListener(this.fullUserKey,this.boundEventHandler)}setCurrentUser(e){return this.persistence._set(this.fullUserKey,e.toJSON())}async getCurrentUser(){const e=await this.persistence._get(this.fullUserKey);if(!e)return null;if(typeof e=="string"){const r=await Rt(this.auth,{idToken:e}).catch(()=>{});return r?Z._fromGetAccountInfoResponse(this.auth,r,e):null}return Z._fromJSON(this.auth,e)}removeCurrentUser(){return this.persistence._remove(this.fullUserKey)}savePersistenceForRedirect(){return this.persistence._set(this.fullPersistenceKey,this.persistence.type)}async setPersistence(e){if(this.persistence===e)return;const r=await this.getCurrentUser();if(await this.removeCurrentUser(),this.persistence=e,r)return this.setCurrentUser(r)}delete(){this.persistence._removeListener(this.fullUserKey,this.boundEventHandler)}static async create(e,r,n="authUser"){if(!r.length)return new Ue(ue(In),e,n);const s=(await Promise.all(r.map(async d=>{if(await d._isAvailable())return d}))).filter(d=>d);let o=s[0]||ue(In);const i=Et(n,e.config.apiKey,e.name);let c=null;for(const d of r)try{const f=await d._get(i);if(f){let p;if(typeof f=="string"){const h=await Rt(e,{idToken:f}).catch(()=>{});if(!h)break;p=await Z._fromGetAccountInfoResponse(e,h,f)}else p=Z._fromJSON(e,f);d!==o&&(c=p),o=d;break}}catch{}const l=s.filter(d=>d._shouldAllowMigration);return!o._shouldAllowMigration||!l.length?new Ue(o,e,n):(o=l[0],c&&await o._set(i,c.toJSON()),await Promise.all(r.map(async d=>{if(d!==o)try{await d._remove(i)}catch{}})),new Ue(o,e,n))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Sn(t){const e=t.toLowerCase();if(e.includes("opera/")||e.includes("opr/")||e.includes("opios/"))return"Opera";if(Xs(e))return"IEMobile";if(e.includes("msie")||e.includes("trident/"))return"IE";if(e.includes("edge/"))return"Edge";if(Gs(e))return"Firefox";if(e.includes("silk/"))return"Silk";if(Zs(e))return"Blackberry";if(eo(e))return"Webos";if(Ys(e))return"Safari";if((e.includes("chrome/")||Js(e))&&!e.includes("edge/"))return"Chrome";if(Qs(e))return"Android";{const r=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,n=t.match(r);if((n==null?void 0:n.length)===2)return n[1]}return"Other"}function Gs(t=B()){return/firefox\//i.test(t)}function Ys(t=B()){const e=t.toLowerCase();return e.includes("safari/")&&!e.includes("chrome/")&&!e.includes("crios/")&&!e.includes("android")}function Js(t=B()){return/crios\//i.test(t)}function Xs(t=B()){return/iemobile/i.test(t)}function Qs(t=B()){return/android/i.test(t)}function Zs(t=B()){return/blackberry/i.test(t)}function eo(t=B()){return/webos/i.test(t)}function Or(t=B()){return/iphone|ipad|ipod/i.test(t)||/macintosh/i.test(t)&&/mobile/i.test(t)}function Jl(t=B()){var e;return Or(t)&&!!((e=window.navigator)!=null&&e.standalone)}function Xl(){return lc()&&document.documentMode===10}function to(t=B()){return Or(t)||Qs(t)||eo(t)||Zs(t)||/windows phone/i.test(t)||Xs(t)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ro(t,e=[]){let r;switch(t){case"Browser":r=Sn(B());break;case"Worker":r=`${Sn(B())}-${t}`;break;default:r=t}const n=e.length?e.join(","):"FirebaseCore-web";return`${r}/JsCore/${ut}/${n}`}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ql{constructor(e){this.auth=e,this.queue=[]}pushCallback(e,r){const n=o=>new Promise((i,c)=>{try{const l=e(o);i(l)}catch(l){c(l)}});n.onAbort=r,this.queue.push(n);const s=this.queue.length-1;return()=>{this.queue[s]=()=>Promise.resolve()}}async runMiddleware(e){if(this.auth.currentUser===e)return;const r=[];try{for(const n of this.queue)await n(e),n.onAbort&&r.push(n.onAbort)}catch(n){r.reverse();for(const s of r)try{s()}catch{}throw this.auth._errorFactory.create("login-blocked",{originalMessage:n==null?void 0:n.message})}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Zl(t,e={}){return pe(t,"GET","/v2/passwordPolicy",oe(t,e))}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ed=6;class td{constructor(e){var n;const r=e.customStrengthOptions;this.customStrengthOptions={},this.customStrengthOptions.minPasswordLength=r.minPasswordLength??ed,r.maxPasswordLength&&(this.customStrengthOptions.maxPasswordLength=r.maxPasswordLength),r.containsLowercaseCharacter!==void 0&&(this.customStrengthOptions.containsLowercaseLetter=r.containsLowercaseCharacter),r.containsUppercaseCharacter!==void 0&&(this.customStrengthOptions.containsUppercaseLetter=r.containsUppercaseCharacter),r.containsNumericCharacter!==void 0&&(this.customStrengthOptions.containsNumericCharacter=r.containsNumericCharacter),r.containsNonAlphanumericCharacter!==void 0&&(this.customStrengthOptions.containsNonAlphanumericCharacter=r.containsNonAlphanumericCharacter),this.enforcementState=e.enforcementState,this.enforcementState==="ENFORCEMENT_STATE_UNSPECIFIED"&&(this.enforcementState="OFF"),this.allowedNonAlphanumericCharacters=((n=e.allowedNonAlphanumericCharacters)==null?void 0:n.join(""))??"",this.forceUpgradeOnSignin=e.forceUpgradeOnSignin??!1,this.schemaVersion=e.schemaVersion}validatePassword(e){const r={isValid:!0,passwordPolicy:this};return this.validatePasswordLengthOptions(e,r),this.validatePasswordCharacterOptions(e,r),r.isValid&&(r.isValid=r.meetsMinPasswordLength??!0),r.isValid&&(r.isValid=r.meetsMaxPasswordLength??!0),r.isValid&&(r.isValid=r.containsLowercaseLetter??!0),r.isValid&&(r.isValid=r.containsUppercaseLetter??!0),r.isValid&&(r.isValid=r.containsNumericCharacter??!0),r.isValid&&(r.isValid=r.containsNonAlphanumericCharacter??!0),r}validatePasswordLengthOptions(e,r){const n=this.customStrengthOptions.minPasswordLength,s=this.customStrengthOptions.maxPasswordLength;n&&(r.meetsMinPasswordLength=e.length>=n),s&&(r.meetsMaxPasswordLength=e.length<=s)}validatePasswordCharacterOptions(e,r){this.updatePasswordCharacterOptionsStatuses(r,!1,!1,!1,!1);let n;for(let s=0;s<e.length;s++)n=e.charAt(s),this.updatePasswordCharacterOptionsStatuses(r,n>="a"&&n<="z",n>="A"&&n<="Z",n>="0"&&n<="9",this.allowedNonAlphanumericCharacters.includes(n))}updatePasswordCharacterOptionsStatuses(e,r,n,s,o){this.customStrengthOptions.containsLowercaseLetter&&(e.containsLowercaseLetter||(e.containsLowercaseLetter=r)),this.customStrengthOptions.containsUppercaseLetter&&(e.containsUppercaseLetter||(e.containsUppercaseLetter=n)),this.customStrengthOptions.containsNumericCharacter&&(e.containsNumericCharacter||(e.containsNumericCharacter=s)),this.customStrengthOptions.containsNonAlphanumericCharacter&&(e.containsNonAlphanumericCharacter||(e.containsNonAlphanumericCharacter=o))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class rd{constructor(e,r,n,s){this.app=e,this.heartbeatServiceProvider=r,this.appCheckServiceProvider=n,this.config=s,this.currentUser=null,this.emulatorConfig=null,this.operations=Promise.resolve(),this.authStateSubscription=new Tn(this),this.idTokenSubscription=new Tn(this),this.beforeStateQueue=new Ql(this),this.redirectUser=null,this.isProactiveRefreshEnabled=!1,this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION=1,this._canInitEmulator=!0,this._isInitialized=!1,this._deleted=!1,this._initializationPromise=null,this._popupRedirectResolver=null,this._errorFactory=zs,this._agentRecaptchaConfig=null,this._tenantRecaptchaConfigs={},this._projectPasswordPolicy=null,this._tenantPasswordPolicies={},this._resolvePersistenceManagerAvailable=void 0,this.lastNotifiedUid=void 0,this.languageCode=null,this.tenantId=null,this.settings={appVerificationDisabledForTesting:!1},this.frameworks=[],this.name=e.name,this.clientVersion=s.sdkClientVersion,this._persistenceManagerAvailable=new Promise(o=>this._resolvePersistenceManagerAvailable=o)}_initializeWithPersistence(e,r){return r&&(this._popupRedirectResolver=ue(r)),this._initializationPromise=this.queue(async()=>{var n,s,o;if(!this._deleted&&(this.persistenceManager=await Ue.create(this,e),(n=this._resolvePersistenceManagerAvailable)==null||n.call(this),!this._deleted)){if((s=this._popupRedirectResolver)!=null&&s._shouldInitProactively)try{await this._popupRedirectResolver._initialize(this)}catch{}await this.initializeCurrentUser(r),this.lastNotifiedUid=((o=this.currentUser)==null?void 0:o.uid)||null,!this._deleted&&(this._isInitialized=!0)}}),this._initializationPromise}async _onStorageEvent(){if(this._deleted)return;const e=await this.assertedPersistence.getCurrentUser();if(!(!this.currentUser&&!e)){if(this.currentUser&&e&&this.currentUser.uid===e.uid){this._currentUser._assign(e),await this.currentUser.getIdToken();return}await this._updateCurrentUser(e,!0)}}async initializeCurrentUserFromIdToken(e){try{const r=await Rt(this,{idToken:e}),n=await Z._fromGetAccountInfoResponse(this,r,e);await this.directlySetCurrentUser(n)}catch(r){console.warn("FirebaseServerApp could not login user with provided authIdToken: ",r),await this.directlySetCurrentUser(null)}}async initializeCurrentUser(e){var o;if(K(this.app)){const i=this.app.settings.authIdToken;return i?new Promise(c=>{setTimeout(()=>this.initializeCurrentUserFromIdToken(i).then(c,c))}):this.directlySetCurrentUser(null)}const r=await this.assertedPersistence.getCurrentUser();let n=r,s=!1;if(e&&this.config.authDomain){await this.getOrInitRedirectPersistenceManager();const i=(o=this.redirectUser)==null?void 0:o._redirectEventId,c=n==null?void 0:n._redirectEventId,l=await this.tryRedirectSignIn(e);(!i||i===c)&&(l!=null&&l.user)&&(n=l.user,s=!0)}if(!n)return this.directlySetCurrentUser(null);if(!n._redirectEventId){if(s)try{await this.beforeStateQueue.runMiddleware(n)}catch(i){n=r,this._popupRedirectResolver._overrideRedirectResult(this,()=>Promise.reject(i))}return n?this.reloadAndSetCurrentUserOrClear(n):this.directlySetCurrentUser(null)}return _(this._popupRedirectResolver,this,"argument-error"),await this.getOrInitRedirectPersistenceManager(),this.redirectUser&&this.redirectUser._redirectEventId===n._redirectEventId?this.directlySetCurrentUser(n):this.reloadAndSetCurrentUserOrClear(n)}async tryRedirectSignIn(e){let r=null;try{r=await this._popupRedirectResolver._completeRedirectFn(this,e,!0)}catch{await this._setRedirectUser(null)}return r}async reloadAndSetCurrentUserOrClear(e){try{await At(e)}catch(r){if((r==null?void 0:r.code)!=="auth/network-request-failed")return this.directlySetCurrentUser(null)}return this.directlySetCurrentUser(e)}useDeviceLanguage(){this.languageCode=Dl()}async _delete(){this._deleted=!0}async updateCurrentUser(e){if(K(this.app))return Promise.reject(re(this));const r=e?Y(e):null;return r&&_(r.auth.config.apiKey===this.config.apiKey,this,"invalid-user-token"),this._updateCurrentUser(r&&r._clone(this))}async _updateCurrentUser(e,r=!1){if(!this._deleted)return e&&_(this.tenantId===e.tenantId,this,"tenant-id-mismatch"),r||await this.beforeStateQueue.runMiddleware(e),this.queue(async()=>{await this.directlySetCurrentUser(e),this.notifyAuthListeners()})}async signOut(){return K(this.app)?Promise.reject(re(this)):(await this.beforeStateQueue.runMiddleware(null),(this.redirectPersistenceManager||this._popupRedirectResolver)&&await this._setRedirectUser(null),this._updateCurrentUser(null,!0))}setPersistence(e){return K(this.app)?Promise.reject(re(this)):this.queue(async()=>{await this.assertedPersistence.setPersistence(ue(e))})}_getRecaptchaConfig(){return this.tenantId==null?this._agentRecaptchaConfig:this._tenantRecaptchaConfigs[this.tenantId]}async validatePassword(e){this._getPasswordPolicyInternal()||await this._updatePasswordPolicy();const r=this._getPasswordPolicyInternal();return r.schemaVersion!==this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION?Promise.reject(this._errorFactory.create("unsupported-password-policy-schema-version",{})):r.validatePassword(e)}_getPasswordPolicyInternal(){return this.tenantId===null?this._projectPasswordPolicy:this._tenantPasswordPolicies[this.tenantId]}async _updatePasswordPolicy(){const e=await Zl(this),r=new td(e);this.tenantId===null?this._projectPasswordPolicy=r:this._tenantPasswordPolicies[this.tenantId]=r}_getPersistenceType(){return this.assertedPersistence.persistence.type}_getPersistence(){return this.assertedPersistence.persistence}_updateErrorMap(e){this._errorFactory=new lt("auth","Firebase",e())}onAuthStateChanged(e,r,n){return this.registerStateListener(this.authStateSubscription,e,r,n)}beforeAuthStateChanged(e,r){return this.beforeStateQueue.pushCallback(e,r)}onIdTokenChanged(e,r,n){return this.registerStateListener(this.idTokenSubscription,e,r,n)}authStateReady(){return new Promise((e,r)=>{if(this.currentUser)e();else{const n=this.onAuthStateChanged(()=>{n(),e()},r)}})}async revokeAccessToken(e){if(this.currentUser){const r=await this.currentUser.getIdToken(),n={providerId:"apple.com",tokenType:"ACCESS_TOKEN",token:e,idToken:r};this.tenantId!=null&&(n.tenantId=this.tenantId),await Yl(this,n)}}toJSON(){var e;return{apiKey:this.config.apiKey,authDomain:this.config.authDomain,appName:this.name,currentUser:(e=this._currentUser)==null?void 0:e.toJSON()}}async _setRedirectUser(e,r){const n=await this.getOrInitRedirectPersistenceManager(r);return e===null?n.removeCurrentUser():n.setCurrentUser(e)}async getOrInitRedirectPersistenceManager(e){if(!this.redirectPersistenceManager){const r=e&&ue(e)||this._popupRedirectResolver;_(r,this,"argument-error"),this.redirectPersistenceManager=await Ue.create(this,[ue(r._redirectPersistence)],"redirectUser"),this.redirectUser=await this.redirectPersistenceManager.getCurrentUser()}return this.redirectPersistenceManager}async _redirectUserForId(e){var r,n;return this._isInitialized&&await this.queue(async()=>{}),((r=this._currentUser)==null?void 0:r._redirectEventId)===e?this._currentUser:((n=this.redirectUser)==null?void 0:n._redirectEventId)===e?this.redirectUser:null}async _persistUserIfCurrent(e){if(e===this.currentUser)return this.queue(async()=>this.directlySetCurrentUser(e))}_notifyListenersIfCurrent(e){e===this.currentUser&&this.notifyAuthListeners()}_key(){return`${this.config.authDomain}:${this.config.apiKey}:${this.name}`}_startProactiveRefresh(){this.isProactiveRefreshEnabled=!0,this.currentUser&&this._currentUser._startProactiveRefresh()}_stopProactiveRefresh(){this.isProactiveRefreshEnabled=!1,this.currentUser&&this._currentUser._stopProactiveRefresh()}get _currentUser(){return this.currentUser}notifyAuthListeners(){var r;if(!this._isInitialized)return;this.idTokenSubscription.next(this.currentUser);const e=((r=this.currentUser)==null?void 0:r.uid)??null;this.lastNotifiedUid!==e&&(this.lastNotifiedUid=e,this.authStateSubscription.next(this.currentUser))}registerStateListener(e,r,n,s){if(this._deleted)return()=>{};const o=typeof r=="function"?r:r.next.bind(r);let i=!1;const c=this._isInitialized?Promise.resolve():this._initializationPromise;if(_(c,this,"internal-error"),c.then(()=>{i||o(this.currentUser)}),typeof r=="function"){const l=e.addObserver(r,n,s);return()=>{i=!0,l()}}else{const l=e.addObserver(r);return()=>{i=!0,l()}}}async directlySetCurrentUser(e){this.currentUser&&this.currentUser!==e&&this._currentUser._stopProactiveRefresh(),e&&this.isProactiveRefreshEnabled&&e._startProactiveRefresh(),this.currentUser=e,e?await this.assertedPersistence.setCurrentUser(e):await this.assertedPersistence.removeCurrentUser()}queue(e){return this.operations=this.operations.then(e,e),this.operations}get assertedPersistence(){return _(this.persistenceManager,this,"internal-error"),this.persistenceManager}_logFramework(e){!e||this.frameworks.includes(e)||(this.frameworks.push(e),this.frameworks.sort(),this.clientVersion=ro(this.config.clientPlatform,this._getFrameworks()))}_getFrameworks(){return this.frameworks}async _getAdditionalHeaders(){var s;const e={"X-Client-Version":this.clientVersion};this.app.options.appId&&(e["X-Firebase-gmpid"]=this.app.options.appId);const r=await((s=this.heartbeatServiceProvider.getImmediate({optional:!0}))==null?void 0:s.getHeartbeatsHeader());r&&(e["X-Firebase-Client"]=r);const n=await this._getAppCheckToken();return n&&(e["X-Firebase-AppCheck"]=n),e}async _getAppCheckToken(){var r;if(K(this.app)&&this.app.settings.appCheckToken)return this.app.settings.appCheckToken;const e=await((r=this.appCheckServiceProvider.getImmediate({optional:!0}))==null?void 0:r.getToken());return e!=null&&e.error&&kl(`Error while retrieving App Check token: ${e.error}`),e==null?void 0:e.token}}function me(t){return Y(t)}class Tn{constructor(e){this.auth=e,this.observer=null,this.addObserver=gc(r=>this.observer=r)}get next(){return _(this.observer,this.auth,"internal-error"),this.observer.next.bind(this.observer)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Ft={async loadJS(){throw new Error("Unable to load external scripts")},recaptchaV2Script:"",recaptchaEnterpriseScript:"",gapiScript:""};function nd(t){Ft=t}function no(t){return Ft.loadJS(t)}function sd(){return Ft.recaptchaEnterpriseScript}function od(){return Ft.gapiScript}function id(t){return`__${t}${Math.floor(Math.random()*1e6)}`}class ad{constructor(){this.enterprise=new cd}ready(e){e()}execute(e,r){return Promise.resolve("token")}render(e,r){return""}}class cd{ready(e){e()}execute(e,r){return Promise.resolve("token")}render(e,r){return""}}const ld="recaptcha-enterprise",so="NO_RECAPTCHA";class dd{constructor(e){this.type=ld,this.auth=me(e)}async verify(e="verify",r=!1){async function n(o){if(!r){if(o.tenantId==null&&o._agentRecaptchaConfig!=null)return o._agentRecaptchaConfig.siteKey;if(o.tenantId!=null&&o._tenantRecaptchaConfigs[o.tenantId]!==void 0)return o._tenantRecaptchaConfigs[o.tenantId].siteKey}return new Promise(async(i,c)=>{zl(o,{clientType:"CLIENT_TYPE_WEB",version:"RECAPTCHA_ENTERPRISE"}).then(l=>{if(l.recaptchaKey===void 0)c(new Error("recaptcha Enterprise site key undefined"));else{const d=new Vl(l);return o.tenantId==null?o._agentRecaptchaConfig=d:o._tenantRecaptchaConfigs[o.tenantId]=d,i(d.siteKey)}}).catch(l=>{c(l)})})}function s(o,i,c){const l=window.grecaptcha;_n(l)?l.enterprise.ready(()=>{l.enterprise.execute(o,{action:e}).then(d=>{i(d)}).catch(()=>{i(so)})}):c(Error("No reCAPTCHA enterprise script loaded."))}return this.auth.settings.appVerificationDisabledForTesting?new ad().execute("siteKey",{action:"verify"}):new Promise((o,i)=>{n(this.auth).then(c=>{if(!r&&_n(window.grecaptcha))s(c,o,i);else{if(typeof window>"u"){i(new Error("RecaptchaVerifier is only supported in browser"));return}let l=sd();l.length!==0&&(l+=c),no(l).then(()=>{s(c,o,i)}).catch(d=>{i(d)})}}).catch(c=>{i(c)})})}}async function Cn(t,e,r,n=!1,s=!1){const o=new dd(t);let i;if(s)i=so;else try{i=await o.verify(r)}catch{i=await o.verify(r,!0)}const c={...e};if(r==="mfaSmsEnrollment"||r==="mfaSmsSignIn"){if("phoneEnrollmentInfo"in c){const l=c.phoneEnrollmentInfo.phoneNumber,d=c.phoneEnrollmentInfo.recaptchaToken;Object.assign(c,{phoneEnrollmentInfo:{phoneNumber:l,recaptchaToken:d,captchaResponse:i,clientType:"CLIENT_TYPE_WEB",recaptchaVersion:"RECAPTCHA_ENTERPRISE"}})}else if("phoneSignInInfo"in c){const l=c.phoneSignInInfo.recaptchaToken;Object.assign(c,{phoneSignInInfo:{recaptchaToken:l,captchaResponse:i,clientType:"CLIENT_TYPE_WEB",recaptchaVersion:"RECAPTCHA_ENTERPRISE"}})}return c}return n?Object.assign(c,{captchaResp:i}):Object.assign(c,{captchaResponse:i}),Object.assign(c,{clientType:"CLIENT_TYPE_WEB"}),Object.assign(c,{recaptchaVersion:"RECAPTCHA_ENTERPRISE"}),c}async function br(t,e,r,n,s){var o;if((o=t._getRecaptchaConfig())!=null&&o.isProviderEnabled("EMAIL_PASSWORD_PROVIDER")){const i=await Cn(t,e,r,r==="getOobCode");return n(t,i)}else return n(t,e).catch(async i=>{if(i.code==="auth/missing-recaptcha-token"){console.log(`${r} is protected by reCAPTCHA Enterprise for this project. Automatically triggering the reCAPTCHA flow and restarting the flow.`);const c=await Cn(t,e,r,r==="getOobCode");return n(t,c)}else return Promise.reject(i)})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ud(t,e){const r=Ms(t,"auth");if(r.isInitialized()){const s=r.getImmediate(),o=r.getOptions();if($e(o,e??{}))return s;G(s,"already-initialized")}return r.initialize({options:e})}function hd(t,e){const r=(e==null?void 0:e.persistence)||[],n=(Array.isArray(r)?r:[r]).map(ue);e!=null&&e.errorMap&&t._updateErrorMap(e.errorMap),t._initializeWithPersistence(n,e==null?void 0:e.popupRedirectResolver)}function fd(t,e,r){const n=me(t);_(/^https?:\/\//.test(e),n,"invalid-emulator-scheme");const s=!!(r!=null&&r.disableWarnings),o=oo(e),{host:i,port:c}=pd(e),l=c===null?"":`:${c}`,d={url:`${o}//${i}${l}/`},f=Object.freeze({host:i,port:c,protocol:o.replace(":",""),options:Object.freeze({disableWarnings:s})});if(!n._canInitEmulator){_(n.config.emulator&&n.emulatorConfig,n,"emulator-config-failed"),_($e(d,n.config.emulator)&&$e(f,n.emulatorConfig),n,"emulator-config-failed");return}n.config.emulator=d,n.emulatorConfig=f,n.settings.appVerificationDisabledForTesting=!0,Ut(i)?(tc(`${o}//${i}${l}`),sc("Auth",!0)):md()}function oo(t){const e=t.indexOf(":");return e<0?"":t.substr(0,e+1)}function pd(t){const e=oo(t),r=/(\/\/)?([^?#/]+)/.exec(t.substr(e.length));if(!r)return{host:"",port:null};const n=r[2].split("@").pop()||"",s=/^(\[[^\]]+\])(:|$)/.exec(n);if(s){const o=s[1];return{host:o,port:Pn(n.substr(o.length+1))}}else{const[o,i]=n.split(":");return{host:o,port:Pn(i)}}}function Pn(t){if(!t)return null;const e=Number(t);return isNaN(e)?null:e}function md(){function t(){const e=document.createElement("p"),r=e.style;e.innerText="Running in emulator mode. Do not use with production credentials.",r.position="fixed",r.width="100%",r.backgroundColor="#ffffff",r.border=".1em solid #000000",r.color="#b50000",r.bottom="0px",r.left="0px",r.margin="0px",r.zIndex="10000",r.textAlign="center",e.classList.add("firebase-emulator-warning"),document.body.appendChild(e)}typeof console<"u"&&typeof console.info=="function"&&console.info("WARNING: You are using the Auth Emulator, which is intended for local testing only.  Do not use with production credentials."),typeof window<"u"&&typeof document<"u"&&(document.readyState==="loading"?window.addEventListener("DOMContentLoaded",t):t())}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Dr{constructor(e,r){this.providerId=e,this.signInMethod=r}toJSON(){return de("not implemented")}_getIdTokenResponse(e){return de("not implemented")}_linkToIdToken(e,r){return de("not implemented")}_getReauthenticationResolver(e){return de("not implemented")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function io(t,e){return pe(t,"POST","/v1/accounts:resetPassword",oe(t,e))}async function gd(t,e){return pe(t,"POST","/v1/accounts:signUp",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function bd(t,e){return Ke(t,"POST","/v1/accounts:signInWithPassword",oe(t,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function yd(t,e){return Ke(t,"POST","/v1/accounts:signInWithEmailLink",oe(t,e))}async function vd(t,e){return Ke(t,"POST","/v1/accounts:signInWithEmailLink",oe(t,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class at extends Dr{constructor(e,r,n,s=null){super("password",n),this._email=e,this._password=r,this._tenantId=s}static _fromEmailAndPassword(e,r){return new at(e,r,"password")}static _fromEmailAndCode(e,r,n=null){return new at(e,r,"emailLink",n)}toJSON(){return{email:this._email,password:this._password,signInMethod:this.signInMethod,tenantId:this._tenantId}}static fromJSON(e){const r=typeof e=="string"?JSON.parse(e):e;if(r!=null&&r.email&&(r!=null&&r.password)){if(r.signInMethod==="password")return this._fromEmailAndPassword(r.email,r.password);if(r.signInMethod==="emailLink")return this._fromEmailAndCode(r.email,r.password,r.tenantId)}return null}async _getIdTokenResponse(e){switch(this.signInMethod){case"password":const r={returnSecureToken:!0,email:this._email,password:this._password,clientType:"CLIENT_TYPE_WEB"};return br(e,r,"signInWithPassword",bd);case"emailLink":return yd(e,{email:this._email,oobCode:this._password});default:G(e,"internal-error")}}async _linkToIdToken(e,r){switch(this.signInMethod){case"password":const n={idToken:r,returnSecureToken:!0,email:this._email,password:this._password,clientType:"CLIENT_TYPE_WEB"};return br(e,n,"signUpPassword",gd);case"emailLink":return vd(e,{idToken:r,email:this._email,oobCode:this._password});default:G(e,"internal-error")}}_getReauthenticationResolver(e){return this._getIdTokenResponse(e)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Fe(t,e){return Ke(t,"POST","/v1/accounts:signInWithIdp",oe(t,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const wd="http://localhost";class Ne extends Dr{constructor(){super(...arguments),this.pendingToken=null}static _fromParams(e){const r=new Ne(e.providerId,e.signInMethod);return e.idToken||e.accessToken?(e.idToken&&(r.idToken=e.idToken),e.accessToken&&(r.accessToken=e.accessToken),e.nonce&&!e.pendingToken&&(r.nonce=e.nonce),e.pendingToken&&(r.pendingToken=e.pendingToken)):e.oauthToken&&e.oauthTokenSecret?(r.accessToken=e.oauthToken,r.secret=e.oauthTokenSecret):G("argument-error"),r}toJSON(){return{idToken:this.idToken,accessToken:this.accessToken,secret:this.secret,nonce:this.nonce,pendingToken:this.pendingToken,providerId:this.providerId,signInMethod:this.signInMethod}}static fromJSON(e){const r=typeof e=="string"?JSON.parse(e):e,{providerId:n,signInMethod:s,...o}=r;if(!n||!s)return null;const i=new Ne(n,s);return i.idToken=o.idToken||void 0,i.accessToken=o.accessToken||void 0,i.secret=o.secret,i.nonce=o.nonce,i.pendingToken=o.pendingToken||null,i}_getIdTokenResponse(e){const r=this.buildRequest();return Fe(e,r)}_linkToIdToken(e,r){const n=this.buildRequest();return n.idToken=r,Fe(e,n)}_getReauthenticationResolver(e){const r=this.buildRequest();return r.autoCreate=!1,Fe(e,r)}buildRequest(){const e={requestUri:wd,returnSecureToken:!0};if(this.pendingToken)e.pendingToken=this.pendingToken;else{const r={};this.idToken&&(r.id_token=this.idToken),this.accessToken&&(r.access_token=this.accessToken),this.secret&&(r.oauth_token_secret=this.secret),r.providerId=this.providerId,this.nonce&&!this.pendingToken&&(r.nonce=this.nonce),e.postBody=dt(r)}return e}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function _d(t){switch(t){case"recoverEmail":return"RECOVER_EMAIL";case"resetPassword":return"PASSWORD_RESET";case"signIn":return"EMAIL_SIGNIN";case"verifyEmail":return"VERIFY_EMAIL";case"verifyAndChangeEmail":return"VERIFY_AND_CHANGE_EMAIL";case"revertSecondFactorAddition":return"REVERT_SECOND_FACTOR_ADDITION";default:return null}}function Ed(t){const e=Qe(Ze(t)).link,r=e?Qe(Ze(e)).deep_link_id:null,n=Qe(Ze(t)).deep_link_id;return(n?Qe(Ze(n)).link:null)||n||r||e||t}class Lr{constructor(e){const r=Qe(Ze(e)),n=r.apiKey??null,s=r.oobCode??null,o=_d(r.mode??null);_(n&&s&&o,"argument-error"),this.apiKey=n,this.operation=o,this.code=s,this.continueUrl=r.continueUrl??null,this.languageCode=r.lang??null,this.tenantId=r.tenantId??null}static parseLink(e){const r=Ed(e);try{return new Lr(r)}catch{return null}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ge{constructor(){this.providerId=Ge.PROVIDER_ID}static credential(e,r){return at._fromEmailAndPassword(e,r)}static credentialWithLink(e,r){const n=Lr.parseLink(r);return _(n,"argument-error"),at._fromEmailAndCode(e,n.code,n.tenantId)}}Ge.PROVIDER_ID="password";Ge.EMAIL_PASSWORD_SIGN_IN_METHOD="password";Ge.EMAIL_LINK_SIGN_IN_METHOD="emailLink";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ao{constructor(e){this.providerId=e,this.defaultLanguageCode=null,this.customParameters={}}setDefaultLanguage(e){this.defaultLanguageCode=e}setCustomParameters(e){return this.customParameters=e,this}getCustomParameters(){return this.customParameters}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ft extends ao{constructor(){super(...arguments),this.scopes=[]}addScope(e){return this.scopes.includes(e)||this.scopes.push(e),this}getScopes(){return[...this.scopes]}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class we extends ft{constructor(){super("facebook.com")}static credential(e){return Ne._fromParams({providerId:we.PROVIDER_ID,signInMethod:we.FACEBOOK_SIGN_IN_METHOD,accessToken:e})}static credentialFromResult(e){return we.credentialFromTaggedObject(e)}static credentialFromError(e){return we.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e||!("oauthAccessToken"in e)||!e.oauthAccessToken)return null;try{return we.credential(e.oauthAccessToken)}catch{return null}}}we.FACEBOOK_SIGN_IN_METHOD="facebook.com";we.PROVIDER_ID="facebook.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class le extends ft{constructor(){super("google.com"),this.addScope("profile")}static credential(e,r){return Ne._fromParams({providerId:le.PROVIDER_ID,signInMethod:le.GOOGLE_SIGN_IN_METHOD,idToken:e,accessToken:r})}static credentialFromResult(e){return le.credentialFromTaggedObject(e)}static credentialFromError(e){return le.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e)return null;const{oauthIdToken:r,oauthAccessToken:n}=e;if(!r&&!n)return null;try{return le.credential(r,n)}catch{return null}}}le.GOOGLE_SIGN_IN_METHOD="google.com";le.PROVIDER_ID="google.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _e extends ft{constructor(){super("github.com")}static credential(e){return Ne._fromParams({providerId:_e.PROVIDER_ID,signInMethod:_e.GITHUB_SIGN_IN_METHOD,accessToken:e})}static credentialFromResult(e){return _e.credentialFromTaggedObject(e)}static credentialFromError(e){return _e.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e||!("oauthAccessToken"in e)||!e.oauthAccessToken)return null;try{return _e.credential(e.oauthAccessToken)}catch{return null}}}_e.GITHUB_SIGN_IN_METHOD="github.com";_e.PROVIDER_ID="github.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ee extends ft{constructor(){super("twitter.com")}static credential(e,r){return Ne._fromParams({providerId:Ee.PROVIDER_ID,signInMethod:Ee.TWITTER_SIGN_IN_METHOD,oauthToken:e,oauthTokenSecret:r})}static credentialFromResult(e){return Ee.credentialFromTaggedObject(e)}static credentialFromError(e){return Ee.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e)return null;const{oauthAccessToken:r,oauthTokenSecret:n}=e;if(!r||!n)return null;try{return Ee.credential(r,n)}catch{return null}}}Ee.TWITTER_SIGN_IN_METHOD="twitter.com";Ee.PROVIDER_ID="twitter.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function xd(t,e){return Ke(t,"POST","/v1/accounts:signUp",oe(t,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Se{constructor(e){this.user=e.user,this.providerId=e.providerId,this._tokenResponse=e._tokenResponse,this.operationType=e.operationType}static async _fromIdTokenResponse(e,r,n,s=!1){const o=await Z._fromIdTokenResponse(e,n,s),i=Rn(n);return new Se({user:o,providerId:i,_tokenResponse:n,operationType:r})}static async _forOperation(e,r,n){await e._updateTokensIfNecessary(n,!0);const s=Rn(n);return new Se({user:e,providerId:s,_tokenResponse:n,operationType:r})}}function Rn(t){return t.providerId?t.providerId:"phoneNumber"in t?"phone":null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class kt extends Ce{constructor(e,r,n,s){super(r.code,r.message),this.operationType=n,this.user=s,Object.setPrototypeOf(this,kt.prototype),this.customData={appName:e.name,tenantId:e.tenantId??void 0,_serverResponse:r.customData._serverResponse,operationType:n}}static _fromErrorAndOperation(e,r,n,s){return new kt(e,r,n,s)}}function co(t,e,r,n){return(e==="reauthenticate"?r._getReauthenticationResolver(t):r._getIdTokenResponse(t)).catch(o=>{throw o.code==="auth/multi-factor-auth-required"?kt._fromErrorAndOperation(t,o,e,n):o})}async function Id(t,e,r=!1){const n=await it(t,e._linkToIdToken(t.auth,await t.getIdToken()),r);return Se._forOperation(t,"link",n)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Sd(t,e,r=!1){const{auth:n}=t;if(K(n.app))return Promise.reject(re(n));const s="reauthenticate";try{const o=await it(t,co(n,s,e,t),r);_(o.idToken,n,"internal-error");const i=Nr(o.idToken);_(i,n,"internal-error");const{sub:c}=i;return _(t.uid===c,n,"user-mismatch"),Se._forOperation(t,s,o)}catch(o){throw(o==null?void 0:o.code)==="auth/user-not-found"&&G(n,"user-mismatch"),o}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function lo(t,e,r=!1){if(K(t.app))return Promise.reject(re(t));const n="signIn",s=await co(t,n,e),o=await Se._fromIdTokenResponse(t,n,s);return r||await t._updateCurrentUser(o.user),o}async function Td(t,e){return lo(me(t),e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Cd(t,e){return Ke(t,"POST","/v1/accounts:signInWithCustomToken",oe(t,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function _m(t,e){if(K(t.app))return Promise.reject(re(t));const r=me(t),n=await Cd(r,{token:e,returnSecureToken:!0}),s=await Se._fromIdTokenResponse(r,"signIn",n);return await r._updateCurrentUser(s.user),s}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Mr{constructor(e,r){this.factorId=e,this.uid=r.mfaEnrollmentId,this.enrollmentTime=new Date(r.enrolledAt).toUTCString(),this.displayName=r.displayName}static _fromServerResponse(e,r){return"phoneInfo"in r?jr._fromServerResponse(e,r):"totpInfo"in r?Ur._fromServerResponse(e,r):G(e,"internal-error")}}class jr extends Mr{constructor(e){super("phone",e),this.phoneNumber=e.phoneInfo}static _fromServerResponse(e,r){return new jr(r)}}class Ur extends Mr{constructor(e){super("totp",e)}static _fromServerResponse(e,r){return new Ur(r)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Fr(t){const e=me(t);e._getPasswordPolicyInternal()&&await e._updatePasswordPolicy()}async function Em(t,e,r){await io(Y(t),{oobCode:e,newPassword:r}).catch(async n=>{throw n.code==="auth/password-does-not-meet-requirements"&&Fr(t),n})}async function Pd(t,e){const r=Y(t),n=await io(r,{oobCode:e}),s=n.requestType;switch(_(s,r,"internal-error"),s){case"EMAIL_SIGNIN":break;case"VERIFY_AND_CHANGE_EMAIL":_(n.newEmail,r,"internal-error");break;case"REVERT_SECOND_FACTOR_ADDITION":_(n.mfaInfo,r,"internal-error");default:_(n.email,r,"internal-error")}let o=null;return n.mfaInfo&&(o=Mr._fromServerResponse(me(r),n.mfaInfo)),{data:{email:(n.requestType==="VERIFY_AND_CHANGE_EMAIL"?n.newEmail:n.email)||null,previousEmail:(n.requestType==="VERIFY_AND_CHANGE_EMAIL"?n.email:n.newEmail)||null,multiFactorInfo:o},operation:s}}async function xm(t,e){const{data:r}=await Pd(Y(t),e);return r.email}async function Rd(t,e,r){if(K(t.app))return Promise.reject(re(t));const n=me(t),i=await br(n,{returnSecureToken:!0,email:e,password:r,clientType:"CLIENT_TYPE_WEB"},"signUpPassword",xd).catch(l=>{throw l.code==="auth/password-does-not-meet-requirements"&&Fr(t),l}),c=await Se._fromIdTokenResponse(n,"signIn",i);return await n._updateCurrentUser(c.user),c}function Ad(t,e,r){return K(t.app)?Promise.reject(re(t)):Td(Y(t),Ge.credential(e,r)).catch(async n=>{throw n.code==="auth/password-does-not-meet-requirements"&&Fr(t),n})}function kd(t,e,r,n){return Y(t).onIdTokenChanged(e,r,n)}function Nd(t,e,r){return Y(t).beforeAuthStateChanged(e,r)}function Od(t,e,r,n){return Y(t).onAuthStateChanged(e,r,n)}function Dd(t){return Y(t).signOut()}const Nt="__sak";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class uo{constructor(e,r){this.storageRetriever=e,this.type=r}_isAvailable(){try{return this.storage?(this.storage.setItem(Nt,"1"),this.storage.removeItem(Nt),Promise.resolve(!0)):Promise.resolve(!1)}catch{return Promise.resolve(!1)}}_set(e,r){return this.storage.setItem(e,JSON.stringify(r)),Promise.resolve()}_get(e){const r=this.storage.getItem(e);return Promise.resolve(r?JSON.parse(r):null)}_remove(e){return this.storage.removeItem(e),Promise.resolve()}get storage(){return this.storageRetriever()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ld=1e3,Md=10;class ho extends uo{constructor(){super(()=>window.localStorage,"LOCAL"),this.boundEventHandler=(e,r)=>this.onStorageEvent(e,r),this.listeners={},this.localCache={},this.pollTimer=null,this.fallbackToPolling=to(),this._shouldAllowMigration=!0}forAllChangedKeys(e){for(const r of Object.keys(this.listeners)){const n=this.storage.getItem(r),s=this.localCache[r];n!==s&&e(r,s,n)}}onStorageEvent(e,r=!1){if(!e.key){this.forAllChangedKeys((i,c,l)=>{this.notifyListeners(i,l)});return}const n=e.key;r?this.detachListener():this.stopPolling();const s=()=>{const i=this.storage.getItem(n);!r&&this.localCache[n]===i||this.notifyListeners(n,i)},o=this.storage.getItem(n);Xl()&&o!==e.newValue&&e.newValue!==e.oldValue?setTimeout(s,Md):s()}notifyListeners(e,r){this.localCache[e]=r;const n=this.listeners[e];if(n)for(const s of Array.from(n))s(r&&JSON.parse(r))}startPolling(){this.stopPolling(),this.pollTimer=setInterval(()=>{this.forAllChangedKeys((e,r,n)=>{this.onStorageEvent(new StorageEvent("storage",{key:e,oldValue:r,newValue:n}),!0)})},Ld)}stopPolling(){this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}attachListener(){window.addEventListener("storage",this.boundEventHandler)}detachListener(){window.removeEventListener("storage",this.boundEventHandler)}_addListener(e,r){Object.keys(this.listeners).length===0&&(this.fallbackToPolling?this.startPolling():this.attachListener()),this.listeners[e]||(this.listeners[e]=new Set,this.localCache[e]=this.storage.getItem(e)),this.listeners[e].add(r)}_removeListener(e,r){this.listeners[e]&&(this.listeners[e].delete(r),this.listeners[e].size===0&&delete this.listeners[e]),Object.keys(this.listeners).length===0&&(this.detachListener(),this.stopPolling())}async _set(e,r){await super._set(e,r),this.localCache[e]=JSON.stringify(r)}async _get(e){const r=await super._get(e);return this.localCache[e]=JSON.stringify(r),r}async _remove(e){await super._remove(e),delete this.localCache[e]}}ho.type="LOCAL";const jd=ho;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fo extends uo{constructor(){super(()=>window.sessionStorage,"SESSION")}_addListener(e,r){}_removeListener(e,r){}}fo.type="SESSION";const po=fo;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ud(t){return Promise.all(t.map(async e=>{try{return{fulfilled:!0,value:await e}}catch(r){return{fulfilled:!1,reason:r}}}))}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Vt{constructor(e){this.eventTarget=e,this.handlersMap={},this.boundEventHandler=this.handleEvent.bind(this)}static _getInstance(e){const r=this.receivers.find(s=>s.isListeningto(e));if(r)return r;const n=new Vt(e);return this.receivers.push(n),n}isListeningto(e){return this.eventTarget===e}async handleEvent(e){const r=e,{eventId:n,eventType:s,data:o}=r.data,i=this.handlersMap[s];if(!(i!=null&&i.size))return;r.ports[0].postMessage({status:"ack",eventId:n,eventType:s});const c=Array.from(i).map(async d=>d(r.origin,o)),l=await Ud(c);r.ports[0].postMessage({status:"done",eventId:n,eventType:s,response:l})}_subscribe(e,r){Object.keys(this.handlersMap).length===0&&this.eventTarget.addEventListener("message",this.boundEventHandler),this.handlersMap[e]||(this.handlersMap[e]=new Set),this.handlersMap[e].add(r)}_unsubscribe(e,r){this.handlersMap[e]&&r&&this.handlersMap[e].delete(r),(!r||this.handlersMap[e].size===0)&&delete this.handlersMap[e],Object.keys(this.handlersMap).length===0&&this.eventTarget.removeEventListener("message",this.boundEventHandler)}}Vt.receivers=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Vr(t="",e=10){let r="";for(let n=0;n<e;n++)r+=Math.floor(Math.random()*10);return t+r}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Fd{constructor(e){this.target=e,this.handlers=new Set}removeMessageHandler(e){e.messageChannel&&(e.messageChannel.port1.removeEventListener("message",e.onMessage),e.messageChannel.port1.close()),this.handlers.delete(e)}async _send(e,r,n=50){const s=typeof MessageChannel<"u"?new MessageChannel:null;if(!s)throw new Error("connection_unavailable");let o,i;return new Promise((c,l)=>{const d=Vr("",20);s.port1.start();const f=setTimeout(()=>{l(new Error("unsupported_event"))},n);i={messageChannel:s,onMessage(p){const h=p;if(h.data.eventId===d)switch(h.data.status){case"ack":clearTimeout(f),o=setTimeout(()=>{l(new Error("timeout"))},3e3);break;case"done":clearTimeout(o),c(h.data.response);break;default:clearTimeout(f),clearTimeout(o),l(new Error("invalid_response"));break}}},this.handlers.add(i),s.port1.addEventListener("message",i.onMessage),this.target.postMessage({eventType:e,eventId:d,data:r},[s.port2])}).finally(()=>{i&&this.removeMessageHandler(i)})}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ne(){return window}function Vd(t){ne().location.href=t}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function mo(){return typeof ne().WorkerGlobalScope<"u"&&typeof ne().importScripts=="function"}async function zd(){if(!(navigator!=null&&navigator.serviceWorker))return null;try{return(await navigator.serviceWorker.ready).active}catch{return null}}function $d(){var t;return((t=navigator==null?void 0:navigator.serviceWorker)==null?void 0:t.controller)||null}function Bd(){return mo()?self:null}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const go="firebaseLocalStorageDb",Hd=1,Ot="firebaseLocalStorage",bo="fbase_key";class pt{constructor(e){this.request=e}toPromise(){return new Promise((e,r)=>{this.request.addEventListener("success",()=>{e(this.request.result)}),this.request.addEventListener("error",()=>{r(this.request.error)})})}}function zt(t,e){return t.transaction([Ot],e?"readwrite":"readonly").objectStore(Ot)}function Wd(){const t=indexedDB.deleteDatabase(go);return new pt(t).toPromise()}function yr(){const t=indexedDB.open(go,Hd);return new Promise((e,r)=>{t.addEventListener("error",()=>{r(t.error)}),t.addEventListener("upgradeneeded",()=>{const n=t.result;try{n.createObjectStore(Ot,{keyPath:bo})}catch(s){r(s)}}),t.addEventListener("success",async()=>{const n=t.result;n.objectStoreNames.contains(Ot)?e(n):(n.close(),await Wd(),e(await yr()))})})}async function An(t,e,r){const n=zt(t,!0).put({[bo]:e,value:r});return new pt(n).toPromise()}async function qd(t,e){const r=zt(t,!1).get(e),n=await new pt(r).toPromise();return n===void 0?null:n.value}function kn(t,e){const r=zt(t,!0).delete(e);return new pt(r).toPromise()}const Kd=800,Gd=3;class yo{constructor(){this.type="LOCAL",this._shouldAllowMigration=!0,this.listeners={},this.localCache={},this.pollTimer=null,this.pendingWrites=0,this.receiver=null,this.sender=null,this.serviceWorkerReceiverAvailable=!1,this.activeServiceWorker=null,this._workerInitializationPromise=this.initializeServiceWorkerMessaging().then(()=>{},()=>{})}async _openDb(){return this.db?this.db:(this.db=await yr(),this.db)}async _withRetries(e){let r=0;for(;;)try{const n=await this._openDb();return await e(n)}catch(n){if(r++>Gd)throw n;this.db&&(this.db.close(),this.db=void 0)}}async initializeServiceWorkerMessaging(){return mo()?this.initializeReceiver():this.initializeSender()}async initializeReceiver(){this.receiver=Vt._getInstance(Bd()),this.receiver._subscribe("keyChanged",async(e,r)=>({keyProcessed:(await this._poll()).includes(r.key)})),this.receiver._subscribe("ping",async(e,r)=>["keyChanged"])}async initializeSender(){var r,n;if(this.activeServiceWorker=await zd(),!this.activeServiceWorker)return;this.sender=new Fd(this.activeServiceWorker);const e=await this.sender._send("ping",{},800);e&&(r=e[0])!=null&&r.fulfilled&&(n=e[0])!=null&&n.value.includes("keyChanged")&&(this.serviceWorkerReceiverAvailable=!0)}async notifyServiceWorker(e){if(!(!this.sender||!this.activeServiceWorker||$d()!==this.activeServiceWorker))try{await this.sender._send("keyChanged",{key:e},this.serviceWorkerReceiverAvailable?800:50)}catch{}}async _isAvailable(){try{if(!indexedDB)return!1;const e=await yr();return await An(e,Nt,"1"),await kn(e,Nt),!0}catch{}return!1}async _withPendingWrite(e){this.pendingWrites++;try{await e()}finally{this.pendingWrites--}}async _set(e,r){return this._withPendingWrite(async()=>(await this._withRetries(n=>An(n,e,r)),this.localCache[e]=r,this.notifyServiceWorker(e)))}async _get(e){const r=await this._withRetries(n=>qd(n,e));return this.localCache[e]=r,r}async _remove(e){return this._withPendingWrite(async()=>(await this._withRetries(r=>kn(r,e)),delete this.localCache[e],this.notifyServiceWorker(e)))}async _poll(){const e=await this._withRetries(s=>{const o=zt(s,!1).getAll();return new pt(o).toPromise()});if(!e)return[];if(this.pendingWrites!==0)return[];const r=[],n=new Set;if(e.length!==0)for(const{fbase_key:s,value:o}of e)n.add(s),JSON.stringify(this.localCache[s])!==JSON.stringify(o)&&(this.notifyListeners(s,o),r.push(s));for(const s of Object.keys(this.localCache))this.localCache[s]&&!n.has(s)&&(this.notifyListeners(s,null),r.push(s));return r}notifyListeners(e,r){this.localCache[e]=r;const n=this.listeners[e];if(n)for(const s of Array.from(n))s(r)}startPolling(){this.stopPolling(),this.pollTimer=setInterval(async()=>this._poll(),Kd)}stopPolling(){this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}_addListener(e,r){Object.keys(this.listeners).length===0&&this.startPolling(),this.listeners[e]||(this.listeners[e]=new Set,this._get(e)),this.listeners[e].add(r)}_removeListener(e,r){this.listeners[e]&&(this.listeners[e].delete(r),this.listeners[e].size===0&&delete this.listeners[e]),Object.keys(this.listeners).length===0&&this.stopPolling()}}yo.type="LOCAL";const Yd=yo;new ht(3e4,6e4);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Jd(t,e){return e?ue(e):(_(t._popupRedirectResolver,t,"argument-error"),t._popupRedirectResolver)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class zr extends Dr{constructor(e){super("custom","custom"),this.params=e}_getIdTokenResponse(e){return Fe(e,this._buildIdpRequest())}_linkToIdToken(e,r){return Fe(e,this._buildIdpRequest(r))}_getReauthenticationResolver(e){return Fe(e,this._buildIdpRequest())}_buildIdpRequest(e){const r={requestUri:this.params.requestUri,sessionId:this.params.sessionId,postBody:this.params.postBody,tenantId:this.params.tenantId,pendingToken:this.params.pendingToken,returnSecureToken:!0,returnIdpCredential:!0};return e&&(r.idToken=e),r}}function Xd(t){return lo(t.auth,new zr(t),t.bypassAuthState)}function Qd(t){const{auth:e,user:r}=t;return _(r,e,"internal-error"),Sd(r,new zr(t),t.bypassAuthState)}async function Zd(t){const{auth:e,user:r}=t;return _(r,e,"internal-error"),Id(r,new zr(t),t.bypassAuthState)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class vo{constructor(e,r,n,s,o=!1){this.auth=e,this.resolver=n,this.user=s,this.bypassAuthState=o,this.pendingPromise=null,this.eventManager=null,this.filter=Array.isArray(r)?r:[r]}execute(){return new Promise(async(e,r)=>{this.pendingPromise={resolve:e,reject:r};try{this.eventManager=await this.resolver._initialize(this.auth),await this.onExecution(),this.eventManager.registerConsumer(this)}catch(n){this.reject(n)}})}async onAuthEvent(e){const{urlResponse:r,sessionId:n,postBody:s,tenantId:o,error:i,type:c}=e;if(i){this.reject(i);return}const l={auth:this.auth,requestUri:r,sessionId:n,tenantId:o||void 0,postBody:s||void 0,user:this.user,bypassAuthState:this.bypassAuthState};try{this.resolve(await this.getIdpTask(c)(l))}catch(d){this.reject(d)}}onError(e){this.reject(e)}getIdpTask(e){switch(e){case"signInViaPopup":case"signInViaRedirect":return Xd;case"linkViaPopup":case"linkViaRedirect":return Zd;case"reauthViaPopup":case"reauthViaRedirect":return Qd;default:G(this.auth,"internal-error")}}resolve(e){fe(this.pendingPromise,"Pending promise was never set"),this.pendingPromise.resolve(e),this.unregisterAndCleanUp()}reject(e){fe(this.pendingPromise,"Pending promise was never set"),this.pendingPromise.reject(e),this.unregisterAndCleanUp()}unregisterAndCleanUp(){this.eventManager&&this.eventManager.unregisterConsumer(this),this.pendingPromise=null,this.cleanUp()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const eu=new ht(2e3,1e4);class De extends vo{constructor(e,r,n,s,o){super(e,r,s,o),this.provider=n,this.authWindow=null,this.pollId=null,De.currentPopupAction&&De.currentPopupAction.cancel(),De.currentPopupAction=this}async executeNotNull(){const e=await this.execute();return _(e,this.auth,"internal-error"),e}async onExecution(){fe(this.filter.length===1,"Popup operations only handle one event");const e=Vr();this.authWindow=await this.resolver._openPopup(this.auth,this.provider,this.filter[0],e),this.authWindow.associatedEvent=e,this.resolver._originValidation(this.auth).catch(r=>{this.reject(r)}),this.resolver._isIframeWebStorageSupported(this.auth,r=>{r||this.reject(te(this.auth,"web-storage-unsupported"))}),this.pollUserCancellation()}get eventId(){var e;return((e=this.authWindow)==null?void 0:e.associatedEvent)||null}cancel(){this.reject(te(this.auth,"cancelled-popup-request"))}cleanUp(){this.authWindow&&this.authWindow.close(),this.pollId&&window.clearTimeout(this.pollId),this.authWindow=null,this.pollId=null,De.currentPopupAction=null}pollUserCancellation(){const e=()=>{var r,n;if((n=(r=this.authWindow)==null?void 0:r.window)!=null&&n.closed){this.pollId=window.setTimeout(()=>{this.pollId=null,this.reject(te(this.auth,"popup-closed-by-user"))},8e3);return}this.pollId=window.setTimeout(e,eu.get())};e()}}De.currentPopupAction=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const tu="pendingRedirect",xt=new Map;class ru extends vo{constructor(e,r,n=!1){super(e,["signInViaRedirect","linkViaRedirect","reauthViaRedirect","unknown"],r,void 0,n),this.eventId=null}async execute(){let e=xt.get(this.auth._key());if(!e){try{const n=await nu(this.resolver,this.auth)?await super.execute():null;e=()=>Promise.resolve(n)}catch(r){e=()=>Promise.reject(r)}xt.set(this.auth._key(),e)}return this.bypassAuthState||xt.set(this.auth._key(),()=>Promise.resolve(null)),e()}async onAuthEvent(e){if(e.type==="signInViaRedirect")return super.onAuthEvent(e);if(e.type==="unknown"){this.resolve(null);return}if(e.eventId){const r=await this.auth._redirectUserForId(e.eventId);if(r)return this.user=r,super.onAuthEvent(e);this.resolve(null)}}async onExecution(){}cleanUp(){}}async function nu(t,e){const r=iu(e),n=ou(t);if(!await n._isAvailable())return!1;const s=await n._get(r)==="true";return await n._remove(r),s}function su(t,e){xt.set(t._key(),e)}function ou(t){return ue(t._redirectPersistence)}function iu(t){return Et(tu,t.config.apiKey,t.name)}async function au(t,e,r=!1){if(K(t.app))return Promise.reject(re(t));const n=me(t),s=Jd(n,e),i=await new ru(n,s,r).execute();return i&&!r&&(delete i.user._redirectEventId,await n._persistUserIfCurrent(i.user),await n._setRedirectUser(null,e)),i}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const cu=10*60*1e3;class lu{constructor(e){this.auth=e,this.cachedEventUids=new Set,this.consumers=new Set,this.queuedRedirectEvent=null,this.hasHandledPotentialRedirect=!1,this.lastProcessedEventTime=Date.now()}registerConsumer(e){this.consumers.add(e),this.queuedRedirectEvent&&this.isEventForConsumer(this.queuedRedirectEvent,e)&&(this.sendToConsumer(this.queuedRedirectEvent,e),this.saveEventToCache(this.queuedRedirectEvent),this.queuedRedirectEvent=null)}unregisterConsumer(e){this.consumers.delete(e)}onEvent(e){if(this.hasEventBeenHandled(e))return!1;let r=!1;return this.consumers.forEach(n=>{this.isEventForConsumer(e,n)&&(r=!0,this.sendToConsumer(e,n),this.saveEventToCache(e))}),this.hasHandledPotentialRedirect||!du(e)||(this.hasHandledPotentialRedirect=!0,r||(this.queuedRedirectEvent=e,r=!0)),r}sendToConsumer(e,r){var n;if(e.error&&!wo(e)){const s=((n=e.error.code)==null?void 0:n.split("auth/")[1])||"internal-error";r.onError(te(this.auth,s))}else r.onAuthEvent(e)}isEventForConsumer(e,r){const n=r.eventId===null||!!e.eventId&&e.eventId===r.eventId;return r.filter.includes(e.type)&&n}hasEventBeenHandled(e){return Date.now()-this.lastProcessedEventTime>=cu&&this.cachedEventUids.clear(),this.cachedEventUids.has(Nn(e))}saveEventToCache(e){this.cachedEventUids.add(Nn(e)),this.lastProcessedEventTime=Date.now()}}function Nn(t){return[t.type,t.eventId,t.sessionId,t.tenantId].filter(e=>e).join("-")}function wo({type:t,error:e}){return t==="unknown"&&(e==null?void 0:e.code)==="auth/no-auth-event"}function du(t){switch(t.type){case"signInViaRedirect":case"linkViaRedirect":case"reauthViaRedirect":return!0;case"unknown":return wo(t);default:return!1}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function uu(t,e={}){return pe(t,"GET","/v1/projects",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const hu=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,fu=/^https?/;async function pu(t){if(t.config.emulator)return;const{authorizedDomains:e}=await uu(t);for(const r of e)try{if(mu(r))return}catch{}G(t,"unauthorized-domain")}function mu(t){const e=mr(),{protocol:r,hostname:n}=new URL(e);if(t.startsWith("chrome-extension://")){const i=new URL(t);return i.hostname===""&&n===""?r==="chrome-extension:"&&t.replace("chrome-extension://","")===e.replace("chrome-extension://",""):r==="chrome-extension:"&&i.hostname===n}if(!fu.test(r))return!1;if(hu.test(t))return n===t;const s=t.replace(/\./g,"\\.");return new RegExp("^(.+\\."+s+"|"+s+")$","i").test(n)}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const gu=new ht(3e4,6e4);function On(){const t=ne().___jsl;if(t!=null&&t.H){for(const e of Object.keys(t.H))if(t.H[e].r=t.H[e].r||[],t.H[e].L=t.H[e].L||[],t.H[e].r=[...t.H[e].L],t.CP)for(let r=0;r<t.CP.length;r++)t.CP[r]=null}}function bu(t){return new Promise((e,r)=>{var s,o,i;function n(){On(),gapi.load("gapi.iframes",{callback:()=>{e(gapi.iframes.getContext())},ontimeout:()=>{On(),r(te(t,"network-request-failed"))},timeout:gu.get()})}if((o=(s=ne().gapi)==null?void 0:s.iframes)!=null&&o.Iframe)e(gapi.iframes.getContext());else if((i=ne().gapi)!=null&&i.load)n();else{const c=id("iframefcb");return ne()[c]=()=>{gapi.load?n():r(te(t,"network-request-failed"))},no(`${od()}?onload=${c}`).catch(l=>r(l))}}).catch(e=>{throw It=null,e})}let It=null;function yu(t){return It=It||bu(t),It}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const vu=new ht(5e3,15e3),wu="__/auth/iframe",_u="emulator/auth/iframe",Eu={style:{position:"absolute",top:"-100px",width:"1px",height:"1px"},"aria-hidden":"true",tabindex:"-1"},xu=new Map([["identitytoolkit.googleapis.com","p"],["staging-identitytoolkit.sandbox.googleapis.com","s"],["test-identitytoolkit.sandbox.googleapis.com","t"]]);function Iu(t){const e=t.config;_(e.authDomain,t,"auth-domain-config-required");const r=e.emulator?kr(e,_u):`https://${t.config.authDomain}/${wu}`,n={apiKey:e.apiKey,appName:t.name,v:ut},s=xu.get(t.config.apiHost);s&&(n.eid=s);const o=t._getFrameworks();return o.length&&(n.fw=o.join(",")),`${r}?${dt(n).slice(1)}`}async function Su(t){const e=await yu(t),r=ne().gapi;return _(r,t,"internal-error"),e.open({where:document.body,url:Iu(t),messageHandlersFilter:r.iframes.CROSS_ORIGIN_IFRAMES_FILTER,attributes:Eu,dontclear:!0},n=>new Promise(async(s,o)=>{await n.restyle({setHideOnLeave:!1});const i=te(t,"network-request-failed"),c=ne().setTimeout(()=>{o(i)},vu.get());function l(){ne().clearTimeout(c),s(n)}n.ping(l).then(l,()=>{o(i)})}))}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Tu={location:"yes",resizable:"yes",statusbar:"yes",toolbar:"no"},Cu=500,Pu=600,Ru="_blank",Au="http://localhost";class Dn{constructor(e){this.window=e,this.associatedEvent=null}close(){if(this.window)try{this.window.close()}catch{}}}function ku(t,e,r,n=Cu,s=Pu){const o=Math.max((window.screen.availHeight-s)/2,0).toString(),i=Math.max((window.screen.availWidth-n)/2,0).toString();let c="";const l={...Tu,width:n.toString(),height:s.toString(),top:o,left:i},d=B().toLowerCase();r&&(c=Js(d)?Ru:r),Gs(d)&&(e=e||Au,l.scrollbars="yes");const f=Object.entries(l).reduce((h,[m,y])=>`${h}${m}=${y},`,"");if(Jl(d)&&c!=="_self")return Nu(e||"",c),new Dn(null);const p=window.open(e||"",c,f);_(p,t,"popup-blocked");try{p.focus()}catch{}return new Dn(p)}function Nu(t,e){const r=document.createElement("a");r.href=t,r.target=e;const n=document.createEvent("MouseEvent");n.initMouseEvent("click",!0,!0,window,1,0,0,0,0,!1,!1,!1,!1,1,null),r.dispatchEvent(n)}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ou="__/auth/handler",Du="emulator/auth/handler",Lu=encodeURIComponent("fac");async function Ln(t,e,r,n,s,o){_(t.config.authDomain,t,"auth-domain-config-required"),_(t.config.apiKey,t,"invalid-api-key");const i={apiKey:t.config.apiKey,appName:t.name,authType:r,redirectUrl:n,v:ut,eventId:s};if(e instanceof ao){e.setDefaultLanguage(t.languageCode),i.providerId=e.providerId||"",mc(e.getCustomParameters())||(i.customParameters=JSON.stringify(e.getCustomParameters()));for(const[f,p]of Object.entries({}))i[f]=p}if(e instanceof ft){const f=e.getScopes().filter(p=>p!=="");f.length>0&&(i.scopes=f.join(","))}t.tenantId&&(i.tid=t.tenantId);const c=i;for(const f of Object.keys(c))c[f]===void 0&&delete c[f];const l=await t._getAppCheckToken(),d=l?`#${Lu}=${encodeURIComponent(l)}`:"";return`${Mu(t)}?${dt(c).slice(1)}${d}`}function Mu({config:t}){return t.emulator?kr(t,Du):`https://${t.authDomain}/${Ou}`}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const tr="webStorageSupport";class ju{constructor(){this.eventManagers={},this.iframes={},this.originValidationPromises={},this._redirectPersistence=po,this._completeRedirectFn=au,this._overrideRedirectResult=su}async _openPopup(e,r,n,s){var i;fe((i=this.eventManagers[e._key()])==null?void 0:i.manager,"_initialize() not called before _openPopup()");const o=await Ln(e,r,n,mr(),s);return ku(e,o,Vr())}async _openRedirect(e,r,n,s){await this._originValidation(e);const o=await Ln(e,r,n,mr(),s);return Vd(o),new Promise(()=>{})}_initialize(e){const r=e._key();if(this.eventManagers[r]){const{manager:s,promise:o}=this.eventManagers[r];return s?Promise.resolve(s):(fe(o,"If manager is not set, promise should be"),o)}const n=this.initAndGetManager(e);return this.eventManagers[r]={promise:n},n.catch(()=>{delete this.eventManagers[r]}),n}async initAndGetManager(e){const r=await Su(e),n=new lu(e);return r.register("authEvent",s=>(_(s==null?void 0:s.authEvent,e,"invalid-auth-event"),{status:n.onEvent(s.authEvent)?"ACK":"ERROR"}),gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER),this.eventManagers[e._key()]={manager:n},this.iframes[e._key()]=r,n}_isIframeWebStorageSupported(e,r){this.iframes[e._key()].send(tr,{type:tr},s=>{var i;const o=(i=s==null?void 0:s[0])==null?void 0:i[tr];o!==void 0&&r(!!o),G(e,"internal-error")},gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER)}_originValidation(e){const r=e._key();return this.originValidationPromises[r]||(this.originValidationPromises[r]=pu(e)),this.originValidationPromises[r]}get _shouldInitProactively(){return to()||Ys()||Or()}}const Uu=ju;var Mn="@firebase/auth",jn="1.11.0";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Fu{constructor(e){this.auth=e,this.internalListeners=new Map}getUid(){var e;return this.assertAuthConfigured(),((e=this.auth.currentUser)==null?void 0:e.uid)||null}async getToken(e){return this.assertAuthConfigured(),await this.auth._initializationPromise,this.auth.currentUser?{accessToken:await this.auth.currentUser.getIdToken(e)}:null}addAuthTokenListener(e){if(this.assertAuthConfigured(),this.internalListeners.has(e))return;const r=this.auth.onIdTokenChanged(n=>{e((n==null?void 0:n.stsTokenManager.accessToken)||null)});this.internalListeners.set(e,r),this.updateProactiveRefresh()}removeAuthTokenListener(e){this.assertAuthConfigured();const r=this.internalListeners.get(e);r&&(this.internalListeners.delete(e),r(),this.updateProactiveRefresh())}assertAuthConfigured(){_(this.auth._initializationPromise,"dependent-sdk-initialized-before-auth")}updateProactiveRefresh(){this.internalListeners.size>0?this.auth._startProactiveRefresh():this.auth._stopProactiveRefresh()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Vu(t){switch(t){case"Node":return"node";case"ReactNative":return"rn";case"Worker":return"webworker";case"Cordova":return"cordova";case"WebExtension":return"web-extension";default:return}}function zu(t){st(new Be("auth",(e,{options:r})=>{const n=e.getProvider("app").getImmediate(),s=e.getProvider("heartbeat"),o=e.getProvider("app-check-internal"),{apiKey:i,authDomain:c}=n.options;_(i&&!i.includes(":"),"invalid-api-key",{appName:n.name});const l={apiKey:i,authDomain:c,clientPlatform:t,apiHost:"identitytoolkit.googleapis.com",tokenApiHost:"securetoken.googleapis.com",apiScheme:"https",sdkClientVersion:ro(t)},d=new rd(n,s,o,l);return hd(d,r),d},"PUBLIC").setInstantiationMode("EXPLICIT").setInstanceCreatedCallback((e,r,n)=>{e.getProvider("auth-internal").initialize()})),st(new Be("auth-internal",e=>{const r=me(e.getProvider("auth").getImmediate());return(n=>new Fu(n))(r)},"PRIVATE").setInstantiationMode("EXPLICIT")),Me(Mn,jn,Vu(t)),Me(Mn,jn,"esm2020")}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const $u=5*60,Bu=Ns("authIdTokenMaxAge")||$u;let Un=null;const Hu=t=>async e=>{const r=e&&await e.getIdTokenResult(),n=r&&(new Date().getTime()-Date.parse(r.issuedAtTime))/1e3;if(n&&n>Bu)return;const s=r==null?void 0:r.token;Un!==s&&(Un=s,await fetch(t,{method:s?"POST":"DELETE",headers:s?{Authorization:`Bearer ${s}`}:{}}))};function Wu(t=bl()){const e=Ms(t,"auth");if(e.isInitialized())return e.getImmediate();const r=ud(t,{popupRedirectResolver:Uu,persistence:[Yd,jd,po]}),n=Ns("authTokenSyncURL");if(n&&typeof isSecureContext=="boolean"&&isSecureContext){const o=new URL(n,location.origin);if(location.origin===o.origin){const i=Hu(o.toString());Nd(r,i,()=>i(r.currentUser)),kd(r,c=>i(c))}}const s=Za("auth");return s&&fd(r,`http://${s}`),r}function qu(){var t;return((t=document.getElementsByTagName("head"))==null?void 0:t[0])??document}nd({loadJS(t){return new Promise((e,r)=>{const n=document.createElement("script");n.setAttribute("src",t),n.onload=e,n.onerror=s=>{const o=te("internal-error");o.customData=s,r(o)},n.type="text/javascript",n.charset="UTF-8",qu().appendChild(n)})},gapiScript:"https://apis.google.com/js/api.js",recaptchaV2Script:"https://www.google.com/recaptcha/api.js",recaptchaEnterpriseScript:"https://www.google.com/recaptcha/enterprise.js?render="});zu("Browser");const Ku={apiKey:"AIzaSyC5SM1bjIyRBroAC9l8lK5y_ngYzGBjERs",authDomain:"pixelspot-f4010.firebaseapp.com",projectId:"pixelspot-f4010",storageBucket:"pixelspot-f4010.appspot.com",appId:"1:528523451859:web:107d343375979461646326"},Gu=js(Ku),Le=Wu(Gu);new le;const Im=Object.freeze(Object.defineProperty({__proto__:null,auth:Le},Symbol.toStringTag,{value:"Module"}));async function _o(t){if(!t.ok){const e=await t.text()||t.statusText;throw new Error(`${t.status}: ${e}`)}}async function Eo(){const t=Le.currentUser;return t?{Authorization:`Bearer ${await t.getIdToken()}`}:{}}async function ke(t,e,r){const n=await Eo(),s=await fetch(e,{method:t,headers:{...r?{"Content-Type":"application/json"}:{},...n},body:r?JSON.stringify(r):void 0,credentials:"include"});return await _o(s),s}const xo=({on401:t})=>async({queryKey:e})=>{const r=await Eo(),n=e[0],s=await fetch(n,{headers:r,credentials:"include"});return t==="returnNull"&&s.status===401?null:(await _o(s),await s.json())},U=new la({defaultOptions:{queries:{queryFn:xo({on401:"throw"}),refetchInterval:!1,refetchOnWindowFocus:!1,staleTime:1/0,retry:!1},mutations:{retry:!1}}}),Yu=1,Ju=1e6;let rr=0;function Xu(){return rr=(rr+1)%Number.MAX_SAFE_INTEGER,rr.toString()}const nr=new Map,Fn=t=>{if(nr.has(t))return;const e=setTimeout(()=>{nr.delete(t),nt({type:"REMOVE_TOAST",toastId:t})},Ju);nr.set(t,e)},Qu=(t,e)=>{switch(e.type){case"ADD_TOAST":return{...t,toasts:[e.toast,...t.toasts].slice(0,Yu)};case"UPDATE_TOAST":return{...t,toasts:t.toasts.map(r=>r.id===e.toast.id?{...r,...e.toast}:r)};case"DISMISS_TOAST":{const{toastId:r}=e;return r?Fn(r):t.toasts.forEach(n=>{Fn(n.id)}),{...t,toasts:t.toasts.map(n=>n.id===r||r===void 0?{...n,open:!1}:n)}}case"REMOVE_TOAST":return e.toastId===void 0?{...t,toasts:[]}:{...t,toasts:t.toasts.filter(r=>r.id!==e.toastId)}}},St=[];let Tt={toasts:[]};function nt(t){Tt=Qu(Tt,t),St.forEach(e=>{e(Tt)})}function Zu({...t}){const e=Xu(),r=s=>nt({type:"UPDATE_TOAST",toast:{...s,id:e}}),n=()=>nt({type:"DISMISS_TOAST",toastId:e});return nt({type:"ADD_TOAST",toast:{...t,id:e,open:!0,onOpenChange:s=>{s||n()}}}),{id:e,dismiss:n,update:r}}function $r(){const[t,e]=u.useState(Tt);return u.useEffect(()=>(St.push(e),()=>{const r=St.indexOf(e);r>-1&&St.splice(r,1)}),[t]),{...t,toast:Zu,dismiss:r=>nt({type:"DISMISS_TOAST",toastId:r})}}var Br="ToastProvider",[Hr,eh,th]=Fi("Toast"),[Io,Sm]=xr("Toast",[th]),[rh,$t]=Io(Br),So=t=>{const{__scopeToast:e,label:r="Notification",duration:n=5e3,swipeDirection:s="right",swipeThreshold:o=50,children:i}=t,[c,l]=u.useState(null),[d,f]=u.useState(0),p=u.useRef(!1),h=u.useRef(!1);return r.trim()||console.error(`Invalid prop \`label\` supplied to \`${Br}\`. Expected non-empty \`string\`.`),a.jsx(Hr.Provider,{scope:e,children:a.jsx(rh,{scope:e,label:r,duration:n,swipeDirection:s,swipeThreshold:o,toastCount:d,viewport:c,onViewportChange:l,onToastAdd:u.useCallback(()=>f(m=>m+1),[]),onToastRemove:u.useCallback(()=>f(m=>m-1),[]),isFocusedToastEscapeKeyDownRef:p,isClosePausedRef:h,children:i})})};So.displayName=Br;var To="ToastViewport",nh=["F8"],vr="toast.viewportPause",wr="toast.viewportResume",Co=u.forwardRef((t,e)=>{const{__scopeToast:r,hotkey:n=nh,label:s="Notifications ({hotkey})",...o}=t,i=$t(To,r),c=eh(r),l=u.useRef(null),d=u.useRef(null),f=u.useRef(null),p=u.useRef(null),h=se(e,p,i.onViewportChange),m=n.join("+").replace(/Key/g,"").replace(/Digit/g,""),y=i.toastCount>0;u.useEffect(()=>{const g=v=>{var C;n.length!==0&&n.every(T=>v[T]||v.code===T)&&((C=p.current)==null||C.focus())};return document.addEventListener("keydown",g),()=>document.removeEventListener("keydown",g)},[n]),u.useEffect(()=>{const g=l.current,v=p.current;if(y&&g&&v){const w=()=>{if(!i.isClosePausedRef.current){const j=new CustomEvent(vr);v.dispatchEvent(j),i.isClosePausedRef.current=!0}},C=()=>{if(i.isClosePausedRef.current){const j=new CustomEvent(wr);v.dispatchEvent(j),i.isClosePausedRef.current=!1}},T=j=>{!g.contains(j.relatedTarget)&&C()},k=()=>{g.contains(document.activeElement)||C()};return g.addEventListener("focusin",w),g.addEventListener("focusout",T),g.addEventListener("pointermove",w),g.addEventListener("pointerleave",k),window.addEventListener("blur",w),window.addEventListener("focus",C),()=>{g.removeEventListener("focusin",w),g.removeEventListener("focusout",T),g.removeEventListener("pointermove",w),g.removeEventListener("pointerleave",k),window.removeEventListener("blur",w),window.removeEventListener("focus",C)}}},[y,i.isClosePausedRef]);const b=u.useCallback(({tabbingDirection:g})=>{const w=c().map(C=>{const T=C.ref.current,k=[T,...gh(T)];return g==="forwards"?k:k.reverse()});return(g==="forwards"?w.reverse():w).flat()},[c]);return u.useEffect(()=>{const g=p.current;if(g){const v=w=>{var k,j,z;const C=w.altKey||w.ctrlKey||w.metaKey;if(w.key==="Tab"&&!C){const W=document.activeElement,A=w.shiftKey;if(w.target===g&&A){(k=d.current)==null||k.focus();return}const P=b({tabbingDirection:A?"backwards":"forwards"}),Re=P.findIndex(I=>I===W);sr(P.slice(Re+1))?w.preventDefault():A?(j=d.current)==null||j.focus():(z=f.current)==null||z.focus()}};return g.addEventListener("keydown",v),()=>g.removeEventListener("keydown",v)}},[c,b]),a.jsxs(Vi,{ref:l,role:"region","aria-label":s.replace("{hotkey}",m),tabIndex:-1,style:{pointerEvents:y?void 0:"none"},children:[y&&a.jsx(_r,{ref:d,onFocusFromOutsideViewport:()=>{const g=b({tabbingDirection:"forwards"});sr(g)}}),a.jsx(Hr.Slot,{scope:r,children:a.jsx(H.ol,{tabIndex:-1,...o,ref:h})}),y&&a.jsx(_r,{ref:f,onFocusFromOutsideViewport:()=>{const g=b({tabbingDirection:"backwards"});sr(g)}})]})});Co.displayName=To;var Po="ToastFocusProxy",_r=u.forwardRef((t,e)=>{const{__scopeToast:r,onFocusFromOutsideViewport:n,...s}=t,o=$t(Po,r);return a.jsx(rs,{"aria-hidden":!0,tabIndex:0,...s,ref:e,style:{position:"fixed"},onFocus:i=>{var d;const c=i.relatedTarget;!((d=o.viewport)!=null&&d.contains(c))&&n()}})});_r.displayName=Po;var Bt="Toast",sh="toast.swipeStart",oh="toast.swipeMove",ih="toast.swipeCancel",ah="toast.swipeEnd",Ro=u.forwardRef((t,e)=>{const{forceMount:r,open:n,defaultOpen:s,onOpenChange:o,...i}=t,[c=!0,l]=ns({prop:n,defaultProp:s,onChange:o});return a.jsx(Oe,{present:r||c,children:a.jsx(dh,{open:c,...i,ref:e,onClose:()=>l(!1),onPause:Q(t.onPause),onResume:Q(t.onResume),onSwipeStart:L(t.onSwipeStart,d=>{d.currentTarget.setAttribute("data-swipe","start")}),onSwipeMove:L(t.onSwipeMove,d=>{const{x:f,y:p}=d.detail.delta;d.currentTarget.setAttribute("data-swipe","move"),d.currentTarget.style.setProperty("--radix-toast-swipe-move-x",`${f}px`),d.currentTarget.style.setProperty("--radix-toast-swipe-move-y",`${p}px`)}),onSwipeCancel:L(t.onSwipeCancel,d=>{d.currentTarget.setAttribute("data-swipe","cancel"),d.currentTarget.style.removeProperty("--radix-toast-swipe-move-x"),d.currentTarget.style.removeProperty("--radix-toast-swipe-move-y"),d.currentTarget.style.removeProperty("--radix-toast-swipe-end-x"),d.currentTarget.style.removeProperty("--radix-toast-swipe-end-y")}),onSwipeEnd:L(t.onSwipeEnd,d=>{const{x:f,y:p}=d.detail.delta;d.currentTarget.setAttribute("data-swipe","end"),d.currentTarget.style.removeProperty("--radix-toast-swipe-move-x"),d.currentTarget.style.removeProperty("--radix-toast-swipe-move-y"),d.currentTarget.style.setProperty("--radix-toast-swipe-end-x",`${f}px`),d.currentTarget.style.setProperty("--radix-toast-swipe-end-y",`${p}px`),l(!1)})})})});Ro.displayName=Bt;var[ch,lh]=Io(Bt,{onClose(){}}),dh=u.forwardRef((t,e)=>{const{__scopeToast:r,type:n="foreground",duration:s,open:o,onClose:i,onEscapeKeyDown:c,onPause:l,onResume:d,onSwipeStart:f,onSwipeMove:p,onSwipeCancel:h,onSwipeEnd:m,...y}=t,b=$t(Bt,r),[g,v]=u.useState(null),w=se(e,I=>v(I)),C=u.useRef(null),T=u.useRef(null),k=s||b.duration,j=u.useRef(0),z=u.useRef(k),W=u.useRef(0),{onToastAdd:A,onToastRemove:F}=b,V=Q(()=>{var $;(g==null?void 0:g.contains(document.activeElement))&&(($=b.viewport)==null||$.focus()),i()}),P=u.useCallback(I=>{!I||I===1/0||(window.clearTimeout(W.current),j.current=new Date().getTime(),W.current=window.setTimeout(V,I))},[V]);u.useEffect(()=>{const I=b.viewport;if(I){const $=()=>{P(z.current),d==null||d()},q=()=>{const ge=new Date().getTime()-j.current;z.current=z.current-ge,window.clearTimeout(W.current),l==null||l()};return I.addEventListener(vr,q),I.addEventListener(wr,$),()=>{I.removeEventListener(vr,q),I.removeEventListener(wr,$)}}},[b.viewport,k,l,d,P]),u.useEffect(()=>{o&&!b.isClosePausedRef.current&&P(k)},[o,k,b.isClosePausedRef,P]),u.useEffect(()=>(A(),()=>F()),[A,F]);const Re=u.useMemo(()=>g?Mo(g):null,[g]);return b.viewport?a.jsxs(a.Fragment,{children:[Re&&a.jsx(uh,{__scopeToast:r,role:"status","aria-live":n==="foreground"?"assertive":"polite","aria-atomic":!0,children:Re}),a.jsx(ch,{scope:r,onClose:V,children:fs.createPortal(a.jsx(Hr.ItemSlot,{scope:r,children:a.jsx(zi,{asChild:!0,onEscapeKeyDown:L(c,()=>{b.isFocusedToastEscapeKeyDownRef.current||V(),b.isFocusedToastEscapeKeyDownRef.current=!1}),children:a.jsx(H.li,{role:"status","aria-live":"off","aria-atomic":!0,tabIndex:0,"data-state":o?"open":"closed","data-swipe-direction":b.swipeDirection,...y,ref:w,style:{userSelect:"none",touchAction:"none",...t.style},onKeyDown:L(t.onKeyDown,I=>{I.key==="Escape"&&(c==null||c(I.nativeEvent),I.nativeEvent.defaultPrevented||(b.isFocusedToastEscapeKeyDownRef.current=!0,V()))}),onPointerDown:L(t.onPointerDown,I=>{I.button===0&&(C.current={x:I.clientX,y:I.clientY})}),onPointerMove:L(t.onPointerMove,I=>{if(!C.current)return;const $=I.clientX-C.current.x,q=I.clientY-C.current.y,ge=!!T.current,ae=["left","right"].includes(b.swipeDirection),ee=["left","up"].includes(b.swipeDirection)?Math.min:Math.max,bt=ae?ee(0,$):0,X=ae?0:ee(0,q),Kt=I.pointerType==="touch"?10:2,yt={x:bt,y:X},en={originalEvent:I,delta:yt};ge?(T.current=yt,wt(oh,p,en,{discrete:!1})):Vn(yt,b.swipeDirection,Kt)?(T.current=yt,wt(sh,f,en,{discrete:!1}),I.target.setPointerCapture(I.pointerId)):(Math.abs($)>Kt||Math.abs(q)>Kt)&&(C.current=null)}),onPointerUp:L(t.onPointerUp,I=>{const $=T.current,q=I.target;if(q.hasPointerCapture(I.pointerId)&&q.releasePointerCapture(I.pointerId),T.current=null,C.current=null,$){const ge=I.currentTarget,ae={originalEvent:I,delta:$};Vn($,b.swipeDirection,b.swipeThreshold)?wt(ah,m,ae,{discrete:!0}):wt(ih,h,ae,{discrete:!0}),ge.addEventListener("click",ee=>ee.preventDefault(),{once:!0})}})})})}),b.viewport)})]}):null}),uh=t=>{const{__scopeToast:e,children:r,...n}=t,s=$t(Bt,e),[o,i]=u.useState(!1),[c,l]=u.useState(!1);return ph(()=>i(!0)),u.useEffect(()=>{const d=window.setTimeout(()=>l(!0),1e3);return()=>window.clearTimeout(d)},[]),c?null:a.jsx(ss,{asChild:!0,children:a.jsx(rs,{...n,children:o&&a.jsxs(a.Fragment,{children:[s.label," ",r]})})})},hh="ToastTitle",Ao=u.forwardRef((t,e)=>{const{__scopeToast:r,...n}=t;return a.jsx(H.div,{...n,ref:e})});Ao.displayName=hh;var fh="ToastDescription",ko=u.forwardRef((t,e)=>{const{__scopeToast:r,...n}=t;return a.jsx(H.div,{...n,ref:e})});ko.displayName=fh;var No="ToastAction",Oo=u.forwardRef((t,e)=>{const{altText:r,...n}=t;return r.trim()?a.jsx(Lo,{altText:r,asChild:!0,children:a.jsx(Wr,{...n,ref:e})}):(console.error(`Invalid prop \`altText\` supplied to \`${No}\`. Expected non-empty \`string\`.`),null)});Oo.displayName=No;var Do="ToastClose",Wr=u.forwardRef((t,e)=>{const{__scopeToast:r,...n}=t,s=lh(Do,r);return a.jsx(Lo,{asChild:!0,children:a.jsx(H.button,{type:"button",...n,ref:e,onClick:L(t.onClick,s.onClose)})})});Wr.displayName=Do;var Lo=u.forwardRef((t,e)=>{const{__scopeToast:r,altText:n,...s}=t;return a.jsx(H.div,{"data-radix-toast-announce-exclude":"","data-radix-toast-announce-alt":n||void 0,...s,ref:e})});function Mo(t){const e=[];return Array.from(t.childNodes).forEach(n=>{if(n.nodeType===n.TEXT_NODE&&n.textContent&&e.push(n.textContent),mh(n)){const s=n.ariaHidden||n.hidden||n.style.display==="none",o=n.dataset.radixToastAnnounceExclude==="";if(!s)if(o){const i=n.dataset.radixToastAnnounceAlt;i&&e.push(i)}else e.push(...Mo(n))}}),e}function wt(t,e,r,{discrete:n}){const s=r.originalEvent.currentTarget,o=new CustomEvent(t,{bubbles:!0,cancelable:!0,detail:r});e&&s.addEventListener(t,e,{once:!0}),n?$i(s,o):s.dispatchEvent(o)}var Vn=(t,e,r=0)=>{const n=Math.abs(t.x),s=Math.abs(t.y),o=n>s;return e==="left"||e==="right"?o&&n>r:!o&&s>r};function ph(t=()=>{}){const e=Q(t);os(()=>{let r=0,n=0;return r=window.requestAnimationFrame(()=>n=window.requestAnimationFrame(e)),()=>{window.cancelAnimationFrame(r),window.cancelAnimationFrame(n)}},[e])}function mh(t){return t.nodeType===t.ELEMENT_NODE}function gh(t){const e=[],r=document.createTreeWalker(t,NodeFilter.SHOW_ELEMENT,{acceptNode:n=>{const s=n.tagName==="INPUT"&&n.type==="hidden";return n.disabled||n.hidden||s?NodeFilter.FILTER_SKIP:n.tabIndex>=0?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_SKIP}});for(;r.nextNode();)e.push(r.currentNode);return e}function sr(t){const e=document.activeElement;return t.some(r=>r===e?!0:(r.focus(),document.activeElement!==e))}var bh=So,jo=Co,Uo=Ro,Fo=Ao,Vo=ko,zo=Oo,$o=Wr;const zn=t=>typeof t=="boolean"?`${t}`:t===0?"0":t,$n=ms,mt=(t,e)=>r=>{var n;if((e==null?void 0:e.variants)==null)return $n(t,r==null?void 0:r.class,r==null?void 0:r.className);const{variants:s,defaultVariants:o}=e,i=Object.keys(s).map(d=>{const f=r==null?void 0:r[d],p=o==null?void 0:o[d];if(f===null)return null;const h=zn(f)||zn(p);return s[d][h]}),c=r&&Object.entries(r).reduce((d,f)=>{let[p,h]=f;return h===void 0||(d[p]=h),d},{}),l=e==null||(n=e.compoundVariants)===null||n===void 0?void 0:n.reduce((d,f)=>{let{class:p,className:h,...m}=f;return Object.entries(m).every(y=>{let[b,g]=y;return Array.isArray(g)?g.includes({...o,...c}[b]):{...o,...c}[b]===g})?[...d,p,h]:d},[]);return $n(t,i,l,r==null?void 0:r.class,r==null?void 0:r.className)};/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const yh=t=>t.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),Bo=(...t)=>t.filter((e,r,n)=>!!e&&n.indexOf(e)===r).join(" ");/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var vh={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const wh=u.forwardRef(({color:t="currentColor",size:e=24,strokeWidth:r=2,absoluteStrokeWidth:n,className:s="",children:o,iconNode:i,...c},l)=>u.createElement("svg",{ref:l,...vh,width:e,height:e,stroke:t,strokeWidth:n?Number(r)*24/Number(e):r,className:Bo("lucide",s),...c},[...i.map(([d,f])=>u.createElement(d,f)),...Array.isArray(o)?o:[o]]));/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const M=(t,e)=>{const r=u.forwardRef(({className:n,...s},o)=>u.createElement(wh,{ref:o,iconNode:e,className:Bo(`lucide-${yh(t)}`,n),...s}));return r.displayName=`${t}`,r};/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const _h=M("Bell",[["path",{d:"M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9",key:"1qo2s2"}],["path",{d:"M10.3 21a1.94 1.94 0 0 0 3.4 0",key:"qgo35s"}]]);/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Eh=M("Calendar",[["path",{d:"M8 2v4",key:"1cmpym"}],["path",{d:"M16 2v4",key:"4m81vk"}],["rect",{width:"18",height:"18",x:"3",y:"4",rx:"2",key:"1hopcy"}],["path",{d:"M3 10h18",key:"8toen8"}]]);/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const xh=M("CheckCheck",[["path",{d:"M18 6 7 17l-5-5",key:"116fxf"}],["path",{d:"m22 10-7.5 7.5L13 16",key:"ke71qq"}]]);/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Bn=M("CirclePlus",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M8 12h8",key:"1wcyev"}],["path",{d:"M12 8v8",key:"napkw2"}]]);/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const or=M("CircleUser",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["circle",{cx:"12",cy:"10",r:"3",key:"ilqhr7"}],["path",{d:"M7 20.662V19a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v1.662",key:"154egf"}]]);/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Hn=M("CreditCard",[["rect",{width:"20",height:"14",x:"2",y:"5",rx:"2",key:"ynyp8z"}],["line",{x1:"2",x2:"22",y1:"10",y2:"10",key:"1b3vmo"}]]);/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ih=M("DollarSign",[["line",{x1:"12",x2:"12",y1:"2",y2:"22",key:"7eqyqh"}],["path",{d:"M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6",key:"1b0p4s"}]]);/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Wn=M("FileText",[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"M10 9H8",key:"b1mrlr"}],["path",{d:"M16 13H8",key:"t4e002"}],["path",{d:"M16 17H8",key:"z1uh3a"}]]);/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ir=M("LayoutDashboard",[["rect",{width:"7",height:"9",x:"3",y:"3",rx:"1",key:"10lvy0"}],["rect",{width:"7",height:"5",x:"14",y:"3",rx:"1",key:"16une8"}],["rect",{width:"7",height:"9",x:"14",y:"12",rx:"1",key:"1hutg5"}],["rect",{width:"7",height:"5",x:"3",y:"16",rx:"1",key:"ldoo1y"}]]);/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Sh=M("LogOut",[["path",{d:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",key:"1uf3rs"}],["polyline",{points:"16 17 21 12 16 7",key:"1gabdz"}],["line",{x1:"21",x2:"9",y1:"12",y2:"12",key:"1uyos4"}]]);/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Th=M("MapPin",[["path",{d:"M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0",key:"1r0f0z"}],["circle",{cx:"12",cy:"10",r:"3",key:"ilqhr7"}]]);/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ch=M("Menu",[["line",{x1:"4",x2:"20",y1:"12",y2:"12",key:"1e0a9i"}],["line",{x1:"4",x2:"20",y1:"6",y2:"6",key:"1owob3"}],["line",{x1:"4",x2:"20",y1:"18",y2:"18",key:"yk5zj1"}]]);/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ph=M("MessageSquare",[["path",{d:"M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z",key:"1lielz"}]]);/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const qn=M("Monitor",[["rect",{width:"20",height:"14",x:"2",y:"3",rx:"2",key:"48i651"}],["line",{x1:"8",x2:"16",y1:"21",y2:"21",key:"1svkeh"}],["line",{x1:"12",x2:"12",y1:"17",y2:"21",key:"vw1qmm"}]]);/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Rh=M("PanelLeft",[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",key:"afitv7"}],["path",{d:"M9 3v18",key:"fh3hqa"}]]);/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Dt=M("RefreshCw",[["path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8",key:"v9h5vc"}],["path",{d:"M21 3v5h-5",key:"1q7to0"}],["path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16",key:"3uifl3"}],["path",{d:"M8 16H3v5",key:"1cv678"}]]);/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ah=M("Settings",[["path",{d:"M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z",key:"1qme2f"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]]);/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const kh=M("Shield",[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}]]);/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Nh=M("Sparkles",[["path",{d:"M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z",key:"4pj2yx"}],["path",{d:"M20 3v4",key:"1olli1"}],["path",{d:"M22 5h-4",key:"1gvqau"}],["path",{d:"M4 17v2",key:"vumght"}],["path",{d:"M5 18H3",key:"zchphs"}]]);/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Oh=M("TrendingUp",[["polyline",{points:"22 7 13.5 15.5 8.5 10.5 2 17",key:"126l90"}],["polyline",{points:"16 7 22 7 22 13",key:"kwv8wd"}]]);/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Dh=M("Users",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["path",{d:"M16 3.13a4 4 0 0 1 0 7.75",key:"1da9ce"}]]);/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ho=M("X",[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]]),qr="-",Lh=t=>{const e=jh(t),{conflictingClassGroups:r,conflictingClassGroupModifiers:n}=t;return{getClassGroupId:i=>{const c=i.split(qr);return c[0]===""&&c.length!==1&&c.shift(),Wo(c,e)||Mh(i)},getConflictingClassGroupIds:(i,c)=>{const l=r[i]||[];return c&&n[i]?[...l,...n[i]]:l}}},Wo=(t,e)=>{var i;if(t.length===0)return e.classGroupId;const r=t[0],n=e.nextPart.get(r),s=n?Wo(t.slice(1),n):void 0;if(s)return s;if(e.validators.length===0)return;const o=t.join(qr);return(i=e.validators.find(({validator:c})=>c(o)))==null?void 0:i.classGroupId},Kn=/^\[(.+)\]$/,Mh=t=>{if(Kn.test(t)){const e=Kn.exec(t)[1],r=e==null?void 0:e.substring(0,e.indexOf(":"));if(r)return"arbitrary.."+r}},jh=t=>{const{theme:e,prefix:r}=t,n={nextPart:new Map,validators:[]};return Fh(Object.entries(t.classGroups),r).forEach(([o,i])=>{Er(i,n,o,e)}),n},Er=(t,e,r,n)=>{t.forEach(s=>{if(typeof s=="string"){const o=s===""?e:Gn(e,s);o.classGroupId=r;return}if(typeof s=="function"){if(Uh(s)){Er(s(n),e,r,n);return}e.validators.push({validator:s,classGroupId:r});return}Object.entries(s).forEach(([o,i])=>{Er(i,Gn(e,o),r,n)})})},Gn=(t,e)=>{let r=t;return e.split(qr).forEach(n=>{r.nextPart.has(n)||r.nextPart.set(n,{nextPart:new Map,validators:[]}),r=r.nextPart.get(n)}),r},Uh=t=>t.isThemeGetter,Fh=(t,e)=>e?t.map(([r,n])=>{const s=n.map(o=>typeof o=="string"?e+o:typeof o=="object"?Object.fromEntries(Object.entries(o).map(([i,c])=>[e+i,c])):o);return[r,s]}):t,Vh=t=>{if(t<1)return{get:()=>{},set:()=>{}};let e=0,r=new Map,n=new Map;const s=(o,i)=>{r.set(o,i),e++,e>t&&(e=0,n=r,r=new Map)};return{get(o){let i=r.get(o);if(i!==void 0)return i;if((i=n.get(o))!==void 0)return s(o,i),i},set(o,i){r.has(o)?r.set(o,i):s(o,i)}}},qo="!",zh=t=>{const{separator:e,experimentalParseClassName:r}=t,n=e.length===1,s=e[0],o=e.length,i=c=>{const l=[];let d=0,f=0,p;for(let g=0;g<c.length;g++){let v=c[g];if(d===0){if(v===s&&(n||c.slice(g,g+o)===e)){l.push(c.slice(f,g)),f=g+o;continue}if(v==="/"){p=g;continue}}v==="["?d++:v==="]"&&d--}const h=l.length===0?c:c.substring(f),m=h.startsWith(qo),y=m?h.substring(1):h,b=p&&p>f?p-f:void 0;return{modifiers:l,hasImportantModifier:m,baseClassName:y,maybePostfixModifierPosition:b}};return r?c=>r({className:c,parseClassName:i}):i},$h=t=>{if(t.length<=1)return t;const e=[];let r=[];return t.forEach(n=>{n[0]==="["?(e.push(...r.sort(),n),r=[]):r.push(n)}),e.push(...r.sort()),e},Bh=t=>({cache:Vh(t.cacheSize),parseClassName:zh(t),...Lh(t)}),Hh=/\s+/,Wh=(t,e)=>{const{parseClassName:r,getClassGroupId:n,getConflictingClassGroupIds:s}=e,o=[],i=t.trim().split(Hh);let c="";for(let l=i.length-1;l>=0;l-=1){const d=i[l],{modifiers:f,hasImportantModifier:p,baseClassName:h,maybePostfixModifierPosition:m}=r(d);let y=!!m,b=n(y?h.substring(0,m):h);if(!b){if(!y){c=d+(c.length>0?" "+c:c);continue}if(b=n(h),!b){c=d+(c.length>0?" "+c:c);continue}y=!1}const g=$h(f).join(":"),v=p?g+qo:g,w=v+b;if(o.includes(w))continue;o.push(w);const C=s(b,y);for(let T=0;T<C.length;++T){const k=C[T];o.push(v+k)}c=d+(c.length>0?" "+c:c)}return c};function qh(){let t=0,e,r,n="";for(;t<arguments.length;)(e=arguments[t++])&&(r=Ko(e))&&(n&&(n+=" "),n+=r);return n}const Ko=t=>{if(typeof t=="string")return t;let e,r="";for(let n=0;n<t.length;n++)t[n]&&(e=Ko(t[n]))&&(r&&(r+=" "),r+=e);return r};function Kh(t,...e){let r,n,s,o=i;function i(l){const d=e.reduce((f,p)=>p(f),t());return r=Bh(d),n=r.cache.get,s=r.cache.set,o=c,c(l)}function c(l){const d=n(l);if(d)return d;const f=Wh(l,r);return s(l,f),f}return function(){return o(qh.apply(null,arguments))}}const D=t=>{const e=r=>r[t]||[];return e.isThemeGetter=!0,e},Go=/^\[(?:([a-z-]+):)?(.+)\]$/i,Gh=/^\d+\/\d+$/,Yh=new Set(["px","full","screen"]),Jh=/^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/,Xh=/\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/,Qh=/^(rgba?|hsla?|hwb|(ok)?(lab|lch))\(.+\)$/,Zh=/^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/,ef=/^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/,ce=t=>Ve(t)||Yh.has(t)||Gh.test(t),ye=t=>Ye(t,"length",lf),Ve=t=>!!t&&!Number.isNaN(Number(t)),ar=t=>Ye(t,"number",Ve),Je=t=>!!t&&Number.isInteger(Number(t)),tf=t=>t.endsWith("%")&&Ve(t.slice(0,-1)),x=t=>Go.test(t),ve=t=>Jh.test(t),rf=new Set(["length","size","percentage"]),nf=t=>Ye(t,rf,Yo),sf=t=>Ye(t,"position",Yo),of=new Set(["image","url"]),af=t=>Ye(t,of,uf),cf=t=>Ye(t,"",df),Xe=()=>!0,Ye=(t,e,r)=>{const n=Go.exec(t);return n?n[1]?typeof e=="string"?n[1]===e:e.has(n[1]):r(n[2]):!1},lf=t=>Xh.test(t)&&!Qh.test(t),Yo=()=>!1,df=t=>Zh.test(t),uf=t=>ef.test(t),hf=()=>{const t=D("colors"),e=D("spacing"),r=D("blur"),n=D("brightness"),s=D("borderColor"),o=D("borderRadius"),i=D("borderSpacing"),c=D("borderWidth"),l=D("contrast"),d=D("grayscale"),f=D("hueRotate"),p=D("invert"),h=D("gap"),m=D("gradientColorStops"),y=D("gradientColorStopPositions"),b=D("inset"),g=D("margin"),v=D("opacity"),w=D("padding"),C=D("saturate"),T=D("scale"),k=D("sepia"),j=D("skew"),z=D("space"),W=D("translate"),A=()=>["auto","contain","none"],F=()=>["auto","hidden","clip","visible","scroll"],V=()=>["auto",x,e],P=()=>[x,e],Re=()=>["",ce,ye],I=()=>["auto",Ve,x],$=()=>["bottom","center","left","left-bottom","left-top","right","right-bottom","right-top","top"],q=()=>["solid","dashed","dotted","double","none"],ge=()=>["normal","multiply","screen","overlay","darken","lighten","color-dodge","color-burn","hard-light","soft-light","difference","exclusion","hue","saturation","color","luminosity"],ae=()=>["start","end","center","between","around","evenly","stretch"],ee=()=>["","0",x],bt=()=>["auto","avoid","all","avoid-page","page","left","right","column"],X=()=>[Ve,x];return{cacheSize:500,separator:":",theme:{colors:[Xe],spacing:[ce,ye],blur:["none","",ve,x],brightness:X(),borderColor:[t],borderRadius:["none","","full",ve,x],borderSpacing:P(),borderWidth:Re(),contrast:X(),grayscale:ee(),hueRotate:X(),invert:ee(),gap:P(),gradientColorStops:[t],gradientColorStopPositions:[tf,ye],inset:V(),margin:V(),opacity:X(),padding:P(),saturate:X(),scale:X(),sepia:ee(),skew:X(),space:P(),translate:P()},classGroups:{aspect:[{aspect:["auto","square","video",x]}],container:["container"],columns:[{columns:[ve]}],"break-after":[{"break-after":bt()}],"break-before":[{"break-before":bt()}],"break-inside":[{"break-inside":["auto","avoid","avoid-page","avoid-column"]}],"box-decoration":[{"box-decoration":["slice","clone"]}],box:[{box:["border","content"]}],display:["block","inline-block","inline","flex","inline-flex","table","inline-table","table-caption","table-cell","table-column","table-column-group","table-footer-group","table-header-group","table-row-group","table-row","flow-root","grid","inline-grid","contents","list-item","hidden"],float:[{float:["right","left","none","start","end"]}],clear:[{clear:["left","right","both","none","start","end"]}],isolation:["isolate","isolation-auto"],"object-fit":[{object:["contain","cover","fill","none","scale-down"]}],"object-position":[{object:[...$(),x]}],overflow:[{overflow:F()}],"overflow-x":[{"overflow-x":F()}],"overflow-y":[{"overflow-y":F()}],overscroll:[{overscroll:A()}],"overscroll-x":[{"overscroll-x":A()}],"overscroll-y":[{"overscroll-y":A()}],position:["static","fixed","absolute","relative","sticky"],inset:[{inset:[b]}],"inset-x":[{"inset-x":[b]}],"inset-y":[{"inset-y":[b]}],start:[{start:[b]}],end:[{end:[b]}],top:[{top:[b]}],right:[{right:[b]}],bottom:[{bottom:[b]}],left:[{left:[b]}],visibility:["visible","invisible","collapse"],z:[{z:["auto",Je,x]}],basis:[{basis:V()}],"flex-direction":[{flex:["row","row-reverse","col","col-reverse"]}],"flex-wrap":[{flex:["wrap","wrap-reverse","nowrap"]}],flex:[{flex:["1","auto","initial","none",x]}],grow:[{grow:ee()}],shrink:[{shrink:ee()}],order:[{order:["first","last","none",Je,x]}],"grid-cols":[{"grid-cols":[Xe]}],"col-start-end":[{col:["auto",{span:["full",Je,x]},x]}],"col-start":[{"col-start":I()}],"col-end":[{"col-end":I()}],"grid-rows":[{"grid-rows":[Xe]}],"row-start-end":[{row:["auto",{span:[Je,x]},x]}],"row-start":[{"row-start":I()}],"row-end":[{"row-end":I()}],"grid-flow":[{"grid-flow":["row","col","dense","row-dense","col-dense"]}],"auto-cols":[{"auto-cols":["auto","min","max","fr",x]}],"auto-rows":[{"auto-rows":["auto","min","max","fr",x]}],gap:[{gap:[h]}],"gap-x":[{"gap-x":[h]}],"gap-y":[{"gap-y":[h]}],"justify-content":[{justify:["normal",...ae()]}],"justify-items":[{"justify-items":["start","end","center","stretch"]}],"justify-self":[{"justify-self":["auto","start","end","center","stretch"]}],"align-content":[{content:["normal",...ae(),"baseline"]}],"align-items":[{items:["start","end","center","baseline","stretch"]}],"align-self":[{self:["auto","start","end","center","stretch","baseline"]}],"place-content":[{"place-content":[...ae(),"baseline"]}],"place-items":[{"place-items":["start","end","center","baseline","stretch"]}],"place-self":[{"place-self":["auto","start","end","center","stretch"]}],p:[{p:[w]}],px:[{px:[w]}],py:[{py:[w]}],ps:[{ps:[w]}],pe:[{pe:[w]}],pt:[{pt:[w]}],pr:[{pr:[w]}],pb:[{pb:[w]}],pl:[{pl:[w]}],m:[{m:[g]}],mx:[{mx:[g]}],my:[{my:[g]}],ms:[{ms:[g]}],me:[{me:[g]}],mt:[{mt:[g]}],mr:[{mr:[g]}],mb:[{mb:[g]}],ml:[{ml:[g]}],"space-x":[{"space-x":[z]}],"space-x-reverse":["space-x-reverse"],"space-y":[{"space-y":[z]}],"space-y-reverse":["space-y-reverse"],w:[{w:["auto","min","max","fit","svw","lvw","dvw",x,e]}],"min-w":[{"min-w":[x,e,"min","max","fit"]}],"max-w":[{"max-w":[x,e,"none","full","min","max","fit","prose",{screen:[ve]},ve]}],h:[{h:[x,e,"auto","min","max","fit","svh","lvh","dvh"]}],"min-h":[{"min-h":[x,e,"min","max","fit","svh","lvh","dvh"]}],"max-h":[{"max-h":[x,e,"min","max","fit","svh","lvh","dvh"]}],size:[{size:[x,e,"auto","min","max","fit"]}],"font-size":[{text:["base",ve,ye]}],"font-smoothing":["antialiased","subpixel-antialiased"],"font-style":["italic","not-italic"],"font-weight":[{font:["thin","extralight","light","normal","medium","semibold","bold","extrabold","black",ar]}],"font-family":[{font:[Xe]}],"fvn-normal":["normal-nums"],"fvn-ordinal":["ordinal"],"fvn-slashed-zero":["slashed-zero"],"fvn-figure":["lining-nums","oldstyle-nums"],"fvn-spacing":["proportional-nums","tabular-nums"],"fvn-fraction":["diagonal-fractions","stacked-fractions"],tracking:[{tracking:["tighter","tight","normal","wide","wider","widest",x]}],"line-clamp":[{"line-clamp":["none",Ve,ar]}],leading:[{leading:["none","tight","snug","normal","relaxed","loose",ce,x]}],"list-image":[{"list-image":["none",x]}],"list-style-type":[{list:["none","disc","decimal",x]}],"list-style-position":[{list:["inside","outside"]}],"placeholder-color":[{placeholder:[t]}],"placeholder-opacity":[{"placeholder-opacity":[v]}],"text-alignment":[{text:["left","center","right","justify","start","end"]}],"text-color":[{text:[t]}],"text-opacity":[{"text-opacity":[v]}],"text-decoration":["underline","overline","line-through","no-underline"],"text-decoration-style":[{decoration:[...q(),"wavy"]}],"text-decoration-thickness":[{decoration:["auto","from-font",ce,ye]}],"underline-offset":[{"underline-offset":["auto",ce,x]}],"text-decoration-color":[{decoration:[t]}],"text-transform":["uppercase","lowercase","capitalize","normal-case"],"text-overflow":["truncate","text-ellipsis","text-clip"],"text-wrap":[{text:["wrap","nowrap","balance","pretty"]}],indent:[{indent:P()}],"vertical-align":[{align:["baseline","top","middle","bottom","text-top","text-bottom","sub","super",x]}],whitespace:[{whitespace:["normal","nowrap","pre","pre-line","pre-wrap","break-spaces"]}],break:[{break:["normal","words","all","keep"]}],hyphens:[{hyphens:["none","manual","auto"]}],content:[{content:["none",x]}],"bg-attachment":[{bg:["fixed","local","scroll"]}],"bg-clip":[{"bg-clip":["border","padding","content","text"]}],"bg-opacity":[{"bg-opacity":[v]}],"bg-origin":[{"bg-origin":["border","padding","content"]}],"bg-position":[{bg:[...$(),sf]}],"bg-repeat":[{bg:["no-repeat",{repeat:["","x","y","round","space"]}]}],"bg-size":[{bg:["auto","cover","contain",nf]}],"bg-image":[{bg:["none",{"gradient-to":["t","tr","r","br","b","bl","l","tl"]},af]}],"bg-color":[{bg:[t]}],"gradient-from-pos":[{from:[y]}],"gradient-via-pos":[{via:[y]}],"gradient-to-pos":[{to:[y]}],"gradient-from":[{from:[m]}],"gradient-via":[{via:[m]}],"gradient-to":[{to:[m]}],rounded:[{rounded:[o]}],"rounded-s":[{"rounded-s":[o]}],"rounded-e":[{"rounded-e":[o]}],"rounded-t":[{"rounded-t":[o]}],"rounded-r":[{"rounded-r":[o]}],"rounded-b":[{"rounded-b":[o]}],"rounded-l":[{"rounded-l":[o]}],"rounded-ss":[{"rounded-ss":[o]}],"rounded-se":[{"rounded-se":[o]}],"rounded-ee":[{"rounded-ee":[o]}],"rounded-es":[{"rounded-es":[o]}],"rounded-tl":[{"rounded-tl":[o]}],"rounded-tr":[{"rounded-tr":[o]}],"rounded-br":[{"rounded-br":[o]}],"rounded-bl":[{"rounded-bl":[o]}],"border-w":[{border:[c]}],"border-w-x":[{"border-x":[c]}],"border-w-y":[{"border-y":[c]}],"border-w-s":[{"border-s":[c]}],"border-w-e":[{"border-e":[c]}],"border-w-t":[{"border-t":[c]}],"border-w-r":[{"border-r":[c]}],"border-w-b":[{"border-b":[c]}],"border-w-l":[{"border-l":[c]}],"border-opacity":[{"border-opacity":[v]}],"border-style":[{border:[...q(),"hidden"]}],"divide-x":[{"divide-x":[c]}],"divide-x-reverse":["divide-x-reverse"],"divide-y":[{"divide-y":[c]}],"divide-y-reverse":["divide-y-reverse"],"divide-opacity":[{"divide-opacity":[v]}],"divide-style":[{divide:q()}],"border-color":[{border:[s]}],"border-color-x":[{"border-x":[s]}],"border-color-y":[{"border-y":[s]}],"border-color-s":[{"border-s":[s]}],"border-color-e":[{"border-e":[s]}],"border-color-t":[{"border-t":[s]}],"border-color-r":[{"border-r":[s]}],"border-color-b":[{"border-b":[s]}],"border-color-l":[{"border-l":[s]}],"divide-color":[{divide:[s]}],"outline-style":[{outline:["",...q()]}],"outline-offset":[{"outline-offset":[ce,x]}],"outline-w":[{outline:[ce,ye]}],"outline-color":[{outline:[t]}],"ring-w":[{ring:Re()}],"ring-w-inset":["ring-inset"],"ring-color":[{ring:[t]}],"ring-opacity":[{"ring-opacity":[v]}],"ring-offset-w":[{"ring-offset":[ce,ye]}],"ring-offset-color":[{"ring-offset":[t]}],shadow:[{shadow:["","inner","none",ve,cf]}],"shadow-color":[{shadow:[Xe]}],opacity:[{opacity:[v]}],"mix-blend":[{"mix-blend":[...ge(),"plus-lighter","plus-darker"]}],"bg-blend":[{"bg-blend":ge()}],filter:[{filter:["","none"]}],blur:[{blur:[r]}],brightness:[{brightness:[n]}],contrast:[{contrast:[l]}],"drop-shadow":[{"drop-shadow":["","none",ve,x]}],grayscale:[{grayscale:[d]}],"hue-rotate":[{"hue-rotate":[f]}],invert:[{invert:[p]}],saturate:[{saturate:[C]}],sepia:[{sepia:[k]}],"backdrop-filter":[{"backdrop-filter":["","none"]}],"backdrop-blur":[{"backdrop-blur":[r]}],"backdrop-brightness":[{"backdrop-brightness":[n]}],"backdrop-contrast":[{"backdrop-contrast":[l]}],"backdrop-grayscale":[{"backdrop-grayscale":[d]}],"backdrop-hue-rotate":[{"backdrop-hue-rotate":[f]}],"backdrop-invert":[{"backdrop-invert":[p]}],"backdrop-opacity":[{"backdrop-opacity":[v]}],"backdrop-saturate":[{"backdrop-saturate":[C]}],"backdrop-sepia":[{"backdrop-sepia":[k]}],"border-collapse":[{border:["collapse","separate"]}],"border-spacing":[{"border-spacing":[i]}],"border-spacing-x":[{"border-spacing-x":[i]}],"border-spacing-y":[{"border-spacing-y":[i]}],"table-layout":[{table:["auto","fixed"]}],caption:[{caption:["top","bottom"]}],transition:[{transition:["none","all","","colors","opacity","shadow","transform",x]}],duration:[{duration:X()}],ease:[{ease:["linear","in","out","in-out",x]}],delay:[{delay:X()}],animate:[{animate:["none","spin","ping","pulse","bounce",x]}],transform:[{transform:["","gpu","none"]}],scale:[{scale:[T]}],"scale-x":[{"scale-x":[T]}],"scale-y":[{"scale-y":[T]}],rotate:[{rotate:[Je,x]}],"translate-x":[{"translate-x":[W]}],"translate-y":[{"translate-y":[W]}],"skew-x":[{"skew-x":[j]}],"skew-y":[{"skew-y":[j]}],"transform-origin":[{origin:["center","top","top-right","right","bottom-right","bottom","bottom-left","left","top-left",x]}],accent:[{accent:["auto",t]}],appearance:[{appearance:["none","auto"]}],cursor:[{cursor:["auto","default","pointer","wait","text","move","help","not-allowed","none","context-menu","progress","cell","crosshair","vertical-text","alias","copy","no-drop","grab","grabbing","all-scroll","col-resize","row-resize","n-resize","e-resize","s-resize","w-resize","ne-resize","nw-resize","se-resize","sw-resize","ew-resize","ns-resize","nesw-resize","nwse-resize","zoom-in","zoom-out",x]}],"caret-color":[{caret:[t]}],"pointer-events":[{"pointer-events":["none","auto"]}],resize:[{resize:["none","y","x",""]}],"scroll-behavior":[{scroll:["auto","smooth"]}],"scroll-m":[{"scroll-m":P()}],"scroll-mx":[{"scroll-mx":P()}],"scroll-my":[{"scroll-my":P()}],"scroll-ms":[{"scroll-ms":P()}],"scroll-me":[{"scroll-me":P()}],"scroll-mt":[{"scroll-mt":P()}],"scroll-mr":[{"scroll-mr":P()}],"scroll-mb":[{"scroll-mb":P()}],"scroll-ml":[{"scroll-ml":P()}],"scroll-p":[{"scroll-p":P()}],"scroll-px":[{"scroll-px":P()}],"scroll-py":[{"scroll-py":P()}],"scroll-ps":[{"scroll-ps":P()}],"scroll-pe":[{"scroll-pe":P()}],"scroll-pt":[{"scroll-pt":P()}],"scroll-pr":[{"scroll-pr":P()}],"scroll-pb":[{"scroll-pb":P()}],"scroll-pl":[{"scroll-pl":P()}],"snap-align":[{snap:["start","end","center","align-none"]}],"snap-stop":[{snap:["normal","always"]}],"snap-type":[{snap:["none","x","y","both"]}],"snap-strictness":[{snap:["mandatory","proximity"]}],touch:[{touch:["auto","none","manipulation"]}],"touch-x":[{"touch-pan":["x","left","right"]}],"touch-y":[{"touch-pan":["y","up","down"]}],"touch-pz":["touch-pinch-zoom"],select:[{select:["none","text","all","auto"]}],"will-change":[{"will-change":["auto","scroll","contents","transform",x]}],fill:[{fill:[t,"none"]}],"stroke-w":[{stroke:[ce,ye,ar]}],stroke:[{stroke:[t,"none"]}],sr:["sr-only","not-sr-only"],"forced-color-adjust":[{"forced-color-adjust":["auto","none"]}]},conflictingClassGroups:{overflow:["overflow-x","overflow-y"],overscroll:["overscroll-x","overscroll-y"],inset:["inset-x","inset-y","start","end","top","right","bottom","left"],"inset-x":["right","left"],"inset-y":["top","bottom"],flex:["basis","grow","shrink"],gap:["gap-x","gap-y"],p:["px","py","ps","pe","pt","pr","pb","pl"],px:["pr","pl"],py:["pt","pb"],m:["mx","my","ms","me","mt","mr","mb","ml"],mx:["mr","ml"],my:["mt","mb"],size:["w","h"],"font-size":["leading"],"fvn-normal":["fvn-ordinal","fvn-slashed-zero","fvn-figure","fvn-spacing","fvn-fraction"],"fvn-ordinal":["fvn-normal"],"fvn-slashed-zero":["fvn-normal"],"fvn-figure":["fvn-normal"],"fvn-spacing":["fvn-normal"],"fvn-fraction":["fvn-normal"],"line-clamp":["display","overflow"],rounded:["rounded-s","rounded-e","rounded-t","rounded-r","rounded-b","rounded-l","rounded-ss","rounded-se","rounded-ee","rounded-es","rounded-tl","rounded-tr","rounded-br","rounded-bl"],"rounded-s":["rounded-ss","rounded-es"],"rounded-e":["rounded-se","rounded-ee"],"rounded-t":["rounded-tl","rounded-tr"],"rounded-r":["rounded-tr","rounded-br"],"rounded-b":["rounded-br","rounded-bl"],"rounded-l":["rounded-tl","rounded-bl"],"border-spacing":["border-spacing-x","border-spacing-y"],"border-w":["border-w-s","border-w-e","border-w-t","border-w-r","border-w-b","border-w-l"],"border-w-x":["border-w-r","border-w-l"],"border-w-y":["border-w-t","border-w-b"],"border-color":["border-color-s","border-color-e","border-color-t","border-color-r","border-color-b","border-color-l"],"border-color-x":["border-color-r","border-color-l"],"border-color-y":["border-color-t","border-color-b"],"scroll-m":["scroll-mx","scroll-my","scroll-ms","scroll-me","scroll-mt","scroll-mr","scroll-mb","scroll-ml"],"scroll-mx":["scroll-mr","scroll-ml"],"scroll-my":["scroll-mt","scroll-mb"],"scroll-p":["scroll-px","scroll-py","scroll-ps","scroll-pe","scroll-pt","scroll-pr","scroll-pb","scroll-pl"],"scroll-px":["scroll-pr","scroll-pl"],"scroll-py":["scroll-pt","scroll-pb"],touch:["touch-x","touch-y","touch-pz"],"touch-x":["touch"],"touch-y":["touch"],"touch-pz":["touch"]},conflictingClassGroupModifiers:{"font-size":["leading"]}}},ff=Kh(hf);function R(...t){return ff(ms(t))}const pf=bh,Jo=u.forwardRef(({className:t,...e},r)=>a.jsx(jo,{ref:r,className:R("fixed top-0 z-[100] flex max-h-screen w-full flex-col-reverse p-4 sm:bottom-0 sm:right-0 sm:top-auto sm:flex-col md:max-w-[420px]",t),...e}));Jo.displayName=jo.displayName;const mf=mt("group pointer-events-auto relative flex w-full items-center justify-between space-x-4 overflow-hidden rounded-md border p-6 pr-8 shadow-lg transition-all data-[swipe=cancel]:translate-x-0 data-[swipe=end]:translate-x-[var(--radix-toast-swipe-end-x)] data-[swipe=move]:translate-x-[var(--radix-toast-swipe-move-x)] data-[swipe=move]:transition-none data-[state=open]:animate-in data-[state=closed]:animate-out data-[swipe=end]:animate-out data-[state=closed]:fade-out-80 data-[state=closed]:slide-out-to-right-full data-[state=open]:slide-in-from-top-full data-[state=open]:sm:slide-in-from-bottom-full",{variants:{variant:{default:"border bg-background text-foreground",destructive:"destructive group border-destructive bg-destructive text-destructive-foreground"}},defaultVariants:{variant:"default"}}),Xo=u.forwardRef(({className:t,variant:e,...r},n)=>a.jsx(Uo,{ref:n,className:R(mf({variant:e}),t),...r}));Xo.displayName=Uo.displayName;const gf=u.forwardRef(({className:t,...e},r)=>a.jsx(zo,{ref:r,className:R("inline-flex h-8 shrink-0 items-center justify-center rounded-md border bg-transparent px-3 text-sm font-medium ring-offset-background transition-colors hover:bg-secondary focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 group-[.destructive]:border-muted/40 group-[.destructive]:hover:border-destructive/30 group-[.destructive]:hover:bg-destructive group-[.destructive]:hover:text-destructive-foreground group-[.destructive]:focus:ring-destructive",t),...e}));gf.displayName=zo.displayName;const Qo=u.forwardRef(({className:t,...e},r)=>a.jsx($o,{ref:r,className:R("absolute right-2 top-2 rounded-md p-1 text-foreground/50 opacity-0 transition-opacity hover:text-foreground focus:opacity-100 focus:outline-none focus:ring-2 group-hover:opacity-100 group-[.destructive]:text-red-300 group-[.destructive]:hover:text-red-50 group-[.destructive]:focus:ring-red-400 group-[.destructive]:focus:ring-offset-red-600",t),"toast-close":"",...e,children:a.jsx(Ho,{className:"h-4 w-4"})}));Qo.displayName=$o.displayName;const Zo=u.forwardRef(({className:t,...e},r)=>a.jsx(Fo,{ref:r,className:R("text-sm font-semibold",t),...e}));Zo.displayName=Fo.displayName;const ei=u.forwardRef(({className:t,...e},r)=>a.jsx(Vo,{ref:r,className:R("text-sm opacity-90",t),...e}));ei.displayName=Vo.displayName;function bf(){const{toasts:t}=$r();return a.jsxs(pf,{children:[t.map(function({id:e,title:r,description:n,action:s,...o}){return a.jsxs(Xo,{...o,children:[a.jsxs("div",{className:"grid gap-1",children:[r&&a.jsx(Zo,{children:r}),n&&a.jsx(ei,{children:n})]}),s,a.jsx(Qo,{})]},e)}),a.jsx(Jo,{})]})}const ti=Wi,yf=Bi,vf=Hi,ri=u.forwardRef(({className:t,sideOffset:e=4,...r},n)=>a.jsx(is,{ref:n,sideOffset:e,className:R("z-50 overflow-hidden rounded-md border bg-popover px-3 py-1.5 text-sm text-popover-foreground shadow-md animate-in fade-in-0 zoom-in-95 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=closed]:zoom-out-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-[--radix-tooltip-content-transform-origin]",t),...r}));ri.displayName=is.displayName;const cr=768;function wf(){const[t,e]=u.useState(void 0);return u.useEffect(()=>{const r=window.matchMedia(`(max-width: ${cr-1}px)`),n=()=>{e(window.innerWidth<cr)};return r.addEventListener("change",n),e(window.innerWidth<cr),()=>r.removeEventListener("change",n)},[]),!!t}const _f=mt("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 hover-elevate active-elevate-2",{variants:{variant:{default:"bg-primary text-primary-foreground border border-primary-border",destructive:"bg-destructive text-destructive-foreground border border-destructive-border",outline:" border [border-color:var(--button-outline)]  shadow-xs active:shadow-none ",secondary:"border bg-secondary text-secondary-foreground border border-secondary-border ",ghost:"border border-transparent"},size:{default:"min-h-9 px-4 py-2",sm:"min-h-8 rounded-md px-3 text-xs",lg:"min-h-10 rounded-md px-8",icon:"h-9 w-9"}},defaultVariants:{variant:"default",size:"default"}}),Te=u.forwardRef(({className:t,variant:e,size:r,asChild:n=!1,...s},o)=>{const i=n?Ir:"button";return a.jsx(i,{className:R(_f({variant:e,size:r,className:t})),ref:o,...s})});Te.displayName="Button";const Ef=u.forwardRef(({className:t,type:e,...r},n)=>a.jsx("input",{type:e,className:R("flex h-9 w-full rounded-md border border-input bg-background px-3 py-2 text-base ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 md:text-sm",t),ref:n,...r}));Ef.displayName="Input";var xf="Separator",Yn="horizontal",If=["horizontal","vertical"],ni=u.forwardRef((t,e)=>{const{decorative:r,orientation:n=Yn,...s}=t,o=Sf(n)?n:Yn,c=r?{role:"none"}:{"aria-orientation":o==="vertical"?o:void 0,role:"separator"};return a.jsx(H.div,{"data-orientation":o,...c,...s,ref:e})});ni.displayName=xf;function Sf(t){return If.includes(t)}var si=ni;const Tf=u.forwardRef(({className:t,orientation:e="horizontal",decorative:r=!0,...n},s)=>a.jsx(si,{ref:s,decorative:r,orientation:e,className:R("shrink-0 bg-border",e==="horizontal"?"h-[1px] w-full":"h-full w-[1px]",t),...n}));Tf.displayName=si.displayName;const Cf=Ki,Tm=Gi,Pf=Yi,oi=u.forwardRef(({className:t,...e},r)=>a.jsx(as,{className:R("fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",t),...e,ref:r}));oi.displayName=as.displayName;const Rf=mt("fixed z-50 gap-4 bg-background p-6 shadow-lg transition ease-in-out data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:duration-300 data-[state=open]:duration-500",{variants:{side:{top:"inset-x-0 top-0 border-b data-[state=closed]:slide-out-to-top data-[state=open]:slide-in-from-top",bottom:"inset-x-0 bottom-0 border-t data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom",left:"inset-y-0 left-0 h-full w-3/4 border-r data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left sm:max-w-sm",right:"inset-y-0 right-0 h-full w-3/4  border-l data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right sm:max-w-sm"}},defaultVariants:{side:"right"}}),ii=u.forwardRef(({side:t="right",className:e,children:r,...n},s)=>a.jsxs(Pf,{children:[a.jsx(oi,{}),a.jsxs(cs,{ref:s,className:R(Rf({side:t}),e),...n,children:[r,a.jsxs(qi,{className:"absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-secondary",children:[a.jsx(Ho,{className:"h-4 w-4"}),a.jsx("span",{className:"sr-only",children:"Close"})]})]})]}));ii.displayName=cs.displayName;const ai=({className:t,...e})=>a.jsx("div",{className:R("flex flex-col space-y-2 text-center sm:text-left",t),...e});ai.displayName="SheetHeader";const ci=u.forwardRef(({className:t,...e},r)=>a.jsx(ls,{ref:r,className:R("text-lg font-semibold text-foreground",t),...e}));ci.displayName=ls.displayName;const li=u.forwardRef(({className:t,...e},r)=>a.jsx(ds,{ref:r,className:R("text-sm text-muted-foreground",t),...e}));li.displayName=ds.displayName;const Af="sidebar_state",kf=60*60*24*7,Nf="16rem",Of="18rem",Df="3rem",Lf="b",di=u.createContext(null);function Kr(){const t=u.useContext(di);if(!t)throw new Error("useSidebar must be used within a SidebarProvider.");return t}function Mf({defaultOpen:t=!0,open:e,onOpenChange:r,className:n,style:s,children:o,...i}){const c=wf(),[l,d]=u.useState(!1),[f,p]=u.useState(t),h=e??f,m=u.useCallback(v=>{const w=typeof v=="function"?v(h):v;r?r(w):p(w),document.cookie=`${Af}=${w}; path=/; max-age=${kf}`},[r,h]),y=u.useCallback(()=>c?d(v=>!v):m(v=>!v),[c,m,d]);u.useEffect(()=>{const v=w=>{w.key===Lf&&(w.metaKey||w.ctrlKey)&&(w.preventDefault(),y())};return window.addEventListener("keydown",v),()=>window.removeEventListener("keydown",v)},[y]);const b=h?"expanded":"collapsed",g=u.useMemo(()=>({state:b,open:h,setOpen:m,isMobile:c,openMobile:l,setOpenMobile:d,toggleSidebar:y}),[b,h,m,c,l,d,y]);return a.jsx(di.Provider,{value:g,children:a.jsx(ti,{delayDuration:0,children:a.jsx("div",{"data-slot":"sidebar-wrapper",style:{"--sidebar-width":Nf,"--sidebar-width-icon":Df,...s},className:R("group/sidebar-wrapper has-data-[variant=inset]:bg-sidebar flex min-h-svh w-full",n),...i,children:o})})})}function jf({side:t="left",variant:e="sidebar",collapsible:r="offcanvas",className:n,children:s,...o}){const{isMobile:i,state:c,openMobile:l,setOpenMobile:d}=Kr();return r==="none"?a.jsx("div",{"data-slot":"sidebar",className:R("bg-sidebar text-sidebar-foreground flex h-full w-[var(--sidebar-width)] flex-col",n),...o,children:s}):i?a.jsx(Cf,{open:l,onOpenChange:d,...o,children:a.jsxs(ii,{"data-sidebar":"sidebar","data-slot":"sidebar","data-mobile":"true",className:"bg-sidebar text-sidebar-foreground w-[var(--sidebar-width)] p-0 [&>button]:hidden",style:{"--sidebar-width":Of},side:t,children:[a.jsxs(ai,{className:"sr-only",children:[a.jsx(ci,{children:"Sidebar"}),a.jsx(li,{children:"Displays the mobile sidebar."})]}),a.jsx("div",{className:"flex h-full w-full flex-col",children:s})]})}):a.jsxs("div",{className:"group peer text-sidebar-foreground hidden md:block","data-state":c,"data-collapsible":c==="collapsed"?r:"","data-variant":e,"data-side":t,"data-slot":"sidebar",children:[a.jsx("div",{"data-slot":"sidebar-gap",className:R("relative w-[var(--sidebar-width)] bg-transparent transition-[width] duration-200 ease-linear","group-data-[collapsible=offcanvas]:w-0","group-data-[side=right]:rotate-180",e==="floating"||e==="inset"?"group-data-[collapsible=icon]:w-[calc(var(--sidebar-width-icon)+var(--spacing-4))]":"group-data-[collapsible=icon]:w-[var(--sidebar-width-icon)]")}),a.jsx("div",{"data-slot":"sidebar-container",className:R("fixed inset-y-0 z-10 hidden h-svh w-[var(--sidebar-width)] transition-[left,right,width] duration-200 ease-linear md:flex",t==="left"?"left-0 group-data-[collapsible=offcanvas]:left-[calc(var(--sidebar-width)*-1)]":"right-0 group-data-[collapsible=offcanvas]:right-[calc(var(--sidebar-width)*-1)]",e==="floating"||e==="inset"?"p-2 group-data-[collapsible=icon]:w-[calc(var(--sidebar-width-icon)+var(--spacing-4)+2px)]":"group-data-[collapsible=icon]:w-[var(--sidebar-width-icon)] group-data-[side=left]:border-r group-data-[side=right]:border-l",n),...o,children:a.jsx("div",{"data-sidebar":"sidebar","data-slot":"sidebar-inner",className:"bg-sidebar group-data-[variant=floating]:border-sidebar-border flex h-full w-full flex-col group-data-[variant=floating]:rounded-lg group-data-[variant=floating]:border group-data-[variant=floating]:shadow-sm",children:s})})]})}function Uf({className:t,onClick:e,children:r,...n}){const{toggleSidebar:s}=Kr();return a.jsxs(Te,{"data-sidebar":"trigger","data-slot":"sidebar-trigger",variant:"ghost",size:"icon",className:R("h-7 w-7",t),onClick:o=>{e==null||e(o),s()},...n,children:[r||a.jsx(Rh,{}),a.jsx("span",{className:"sr-only",children:"Toggle Sidebar"})]})}function Ff({className:t,...e}){return a.jsx("div",{"data-slot":"sidebar-header","data-sidebar":"header",className:R("flex flex-col gap-2 p-2",t),...e})}function Vf({className:t,...e}){return a.jsx("div",{"data-slot":"sidebar-footer","data-sidebar":"footer",className:R("flex flex-col gap-2 p-2",t),...e})}function zf({className:t,...e}){return a.jsx("div",{"data-slot":"sidebar-content","data-sidebar":"content",className:R("flex min-h-0 flex-1 flex-col gap-2 overflow-auto group-data-[collapsible=icon]:overflow-hidden",t),...e})}function $f({className:t,...e}){return a.jsx("div",{"data-slot":"sidebar-group","data-sidebar":"group",className:R("relative flex w-full min-w-0 flex-col p-2",t),...e})}function Bf({className:t,asChild:e=!1,...r}){const n=e?Ir:"div";return a.jsx(n,{"data-slot":"sidebar-group-label","data-sidebar":"group-label",className:R("text-sidebar-foreground/70 ring-sidebar-ring flex h-8 shrink-0 items-center rounded-md px-2 text-xs font-medium outline-hidden transition-[margin,opacity] duration-200 ease-linear focus-visible:ring-2 [&>svg]:h-4 [&>svg]:w-4 [&>svg]:shrink-0","group-data-[collapsible=icon]:-mt-8 group-data-[collapsible=icon]:opacity-0",t),...r})}function Hf({className:t,...e}){return a.jsx("div",{"data-slot":"sidebar-group-content","data-sidebar":"group-content",className:R("w-full text-sm",t),...e})}function Wf({className:t,...e}){return a.jsx("ul",{"data-slot":"sidebar-menu","data-sidebar":"menu",className:R("flex w-full min-w-0 flex-col gap-1",t),...e})}function qf({className:t,...e}){return a.jsx("li",{"data-slot":"sidebar-menu-item","data-sidebar":"menu-item",className:R("group/menu-item relative",t),...e})}const Kf=mt("peer/menu-button flex w-full items-center gap-2 overflow-hidden rounded-md p-2 text-left text-sm outline-hidden ring-sidebar-ring transition-[width,height,padding] hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 active:bg-sidebar-accent active:text-sidebar-accent-foreground disabled:pointer-events-none disabled:opacity-50 group-has-data-[sidebar=menu-action]/menu-item:pr-8 aria-disabled:pointer-events-none aria-disabled:opacity-50 data-[active=true]:bg-sidebar-accent data-[active=true]:font-medium data-[active=true]:text-sidebar-accent-foreground data-[state=open]:hover:bg-sidebar-accent data-[state=open]:hover:text-sidebar-accent-foreground group-data-[collapsible=icon]:w-8! group-data-[collapsible=icon]:h-8! group-data-[collapsible=icon]:p-2! [&>span:last-child]:truncate [&>svg]:size-4 [&>svg]:shrink-0",{variants:{variant:{default:"hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",outline:"bg-background shadow-[0_0_0_1px_hsl(var(--sidebar-border))] hover:bg-sidebar-accent hover:text-sidebar-accent-foreground hover:shadow-[0_0_0_1px_hsl(var(--sidebar-accent))]"},size:{default:"h-8 text-sm",sm:"h-7 text-xs",lg:"h-12 text-sm group-data-[collapsible=icon]:p-0!"}},defaultVariants:{variant:"default",size:"default"}});function Gf({asChild:t=!1,isActive:e=!1,variant:r="default",size:n="default",tooltip:s,className:o,...i}){const c=t?Ir:"button",{isMobile:l,state:d}=Kr(),f=a.jsx(c,{"data-slot":"sidebar-menu-button","data-sidebar":"menu-button","data-size":n,"data-active":e,className:R(Kf({variant:r,size:n}),o),...i});return s?(typeof s=="string"&&(s={children:s}),a.jsxs(yf,{children:[a.jsx(vf,{asChild:!0,children:f}),a.jsx(ri,{side:"right",align:"center",hidden:d!=="collapsed"||l,...s})]})):f}const ui=u.createContext(null);function Yf({children:t}){const[e,r]=u.useState(null),[n,s]=u.useState(!0),o=da();u.useEffect(()=>Od(Le,async m=>{console.log("👤 Auth state changed:",m?m.email:"null"),r(m),s(!1),m&&o.invalidateQueries({queryKey:["/api/auth/me"]})}),[o]);const{data:i,isLoading:c}=ps({queryKey:["/api/auth/me"],queryFn:xo({on401:"returnNull"}),enabled:!!e,retry:2,retryDelay:1e3}),l=et({mutationFn:async({email:h,password:m})=>{const y=h.trim().toLowerCase();let b;try{b=await Ad(Le,y,m)}catch(T){const k=(T==null?void 0:T.code)||"";switch(k){case"auth/too-many-requests":throw new Error("Too many failed login attempts. Your account is temporarily locked. Please wait a few minutes or reset your password.");case"auth/wrong-password":case"auth/invalid-credential":case"auth/invalid-login-credentials":throw new Error("Incorrect email or password. Please check and try again.");case"auth/user-not-found":throw new Error("No account found with this email address.");case"auth/user-disabled":throw new Error("This account has been disabled. Please contact support.");case"auth/network-request-failed":throw new Error("Network error. Please check your internet connection.");case"auth/invalid-email":throw new Error("Please enter a valid email address.");default:throw console.error("Firebase auth error:",k,T.message),new Error("Login failed. Please try again.")}}const g=await b.user.getIdToken(),v=await ke("POST","/api/auth/signin",{token:g,email:b.user.email,name:b.user.displayName||b.user.email});if(!(v.headers.get("content-type")||"").includes("application/json"))throw new Error("Server returned an unexpected response. Please clear your browser cache and try again.");return(await v.json()).user},onSuccess:h=>{o.setQueryData(["/api/auth/me"],h)}}),d=et({mutationFn:async({email:h,password:m,name:y,role:b})=>{const g=await Rd(Le,h,m),v=await g.user.getIdToken(),w=await ke("POST","/api/auth/signin",{token:v,email:g.user.email,name:y,role:b});if(!(w.headers.get("content-type")||"").includes("application/json"))throw new Error("Server returned an unexpected response. Please clear your browser cache and try again.");const T=await w.json();try{await ke("POST","/api/auth/send-email-otp",{email:g.user.email})}catch(k){console.error("Failed to send email OTP:",k)}return T.user},onSuccess:h=>{o.setQueryData(["/api/auth/me"],h)}}),f=et({mutationFn:async()=>{await Dd(Le),await ke("POST","/api/auth/signout",{})},onSuccess:()=>{o.clear()}}),p={firebaseUser:e,user:i||null,loading:n||l.isPending||d.isPending||!!e&&c,signInWithEmail:async(h,m)=>{await l.mutateAsync({email:h,password:m})},signUpWithEmail:async(h,m,y,b)=>{await d.mutateAsync({email:h,password:m,name:y,role:b})},resetPassword:async h=>{await ke("POST","/api/auth/request-password-reset",{email:h,origin:window.location.origin})},signOut:async()=>{await f.mutateAsync()},isAdmin:(i==null?void 0:i.role)==="admin",isScreenOwner:(i==null?void 0:i.role)==="screen_owner",isAdvertiser:(i==null?void 0:i.role)==="advertiser"};return a.jsx(ui.Provider,{value:p,children:t})}function Ht(){const t=u.useContext(ui);if(!t)throw new Error("useAuth must be used within AuthProvider");return t}function N({children:t,allowedRoles:e}){const{user:r,loading:n}=Ht(),[,s]=ct();return u.useEffect(()=>{if(!n&&!r&&s("/login"),!n&&r&&!r.emailVerified){s("/verify-email");return}if(!n&&r&&r.emailVerified&&!r.profileCompleted){s("/complete-profile");return}!n&&r&&e&&!e.includes(r.role)&&(r.role==="admin"?s("/admin"):r.role==="screen_owner"?s("/owner"):s("/advertiser"))},[r,n,e,s]),n?a.jsx("div",{className:"flex items-center justify-center min-h-screen bg-background",children:a.jsxs("div",{className:"text-center space-y-4",children:[a.jsx("div",{className:"w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto"}),a.jsx("p",{className:"text-muted-foreground",children:"Loading..."})]})}):!r||e&&!e.includes(r.role)?null:a.jsx(a.Fragment,{children:t})}const Jf="/assets/pixelspot-logo-DUe5fkLr.png";function Xf(){const{user:t,signOut:e,isAdmin:r,isScreenOwner:n,isAdvertiser:s}=Ht(),[o,i]=ct(),{toast:c}=$r(),[l,d]=u.useState(!1),m=r?[{title:"Dashboard",url:"/admin",icon:ir},{title:"Manage Users",url:"/admin/users",icon:Dh},{title:"Manage Screens",url:"/admin/screens",icon:qn},{title:"Campaigns & Bookings",url:"/admin/bookings",icon:Wn},{title:"Payments & Payouts",url:"/admin/payments",icon:Hn},{title:"AI Conversations",url:"/admin/ai-conversations",icon:Ph},{title:"AI Security",url:"/admin/ai-security",icon:kh},{title:"Analytics",url:"/admin/analytics",icon:Oh},{title:"Settings",url:"/admin/settings",icon:Ah},{title:"Profile",url:"/admin/profile",icon:or}]:n?[{title:"Dashboard",url:"/owner",icon:ir},{title:"My Screens",url:"/owner/screens",icon:qn},{title:"Add Screen",url:"/owner/screens/new",icon:Bn},{title:"Booking Requests",url:"/owner/requests",icon:Eh},{title:"Earnings",url:"/owner/earnings",icon:Ih},{title:"Profile",url:"/owner/profile",icon:or}]:[{title:"Dashboard",url:"/advertiser",icon:ir},{title:"Find Screens",url:"/advertiser/discover",icon:Th},{title:"My Campaigns",url:"/advertiser/campaigns",icon:Wn},{title:"Create Campaign",url:"/advertiser/campaigns/new",icon:Bn},{title:"AI Campaign Advisor",url:"/advertiser/ai-advisor",icon:Nh},{title:"Payments",url:"/advertiser/payments",icon:Hn},{title:"Profile",url:"/advertiser/profile",icon:or}],y=async()=>{d(!0),await U.invalidateQueries(),setTimeout(()=>{d(!1),c({title:"Refreshed",description:"All data has been updated"})},500)};return a.jsxs(jf,{children:[a.jsxs(Ff,{className:"p-6 border-b border-sidebar-border",children:[a.jsxs("div",{className:"flex items-start gap-2 mb-2",children:[a.jsx("img",{src:Jf,alt:"PixelSpot",className:"w-40 h-auto"}),a.jsx(Te,{variant:"ghost",size:"icon",onClick:y,disabled:l,"data-testid":"button-refresh-sidebar",className:"h-8 w-8 -mt-1 ml-auto",children:a.jsx(Dt,{className:`h-4 w-4 ${l?"animate-spin":""}`})})]}),a.jsx("p",{className:"text-xs text-muted-foreground mt-1",children:r?"Admin Portal":n?"Screen Owner Portal":"Advertiser Portal"})]}),a.jsx(zf,{children:a.jsxs($f,{children:[a.jsx(Bf,{children:"Menu"}),a.jsx(Hf,{children:a.jsx(Wf,{children:m.map(b=>a.jsx(qf,{children:a.jsxs(Gf,{onClick:()=>i(b.url),isActive:o===b.url,"data-testid":`link-${b.title.toLowerCase().replace(/\s+/g,"-")}`,"data-tour":`sidebar-${b.title.toLowerCase().replace(/\s+/g,"-")}`,children:[a.jsx(b.icon,{className:"w-4 h-4"}),a.jsx("span",{children:b.title})]})},b.title))})})]})}),a.jsx(Vf,{className:"p-4 border-t border-sidebar-border",children:a.jsxs("div",{className:"space-y-3",children:[a.jsxs("div",{className:"px-3 py-2 bg-sidebar-accent rounded-lg",children:[a.jsx("p",{className:"text-xs font-medium text-sidebar-accent-foreground",children:t==null?void 0:t.name}),a.jsx("p",{className:"text-xs text-muted-foreground",children:t==null?void 0:t.email})]}),a.jsxs(Te,{variant:"ghost",className:"w-full justify-start",onClick:()=>e(),"data-testid":"button-signout",children:[a.jsx(Sh,{className:"w-4 h-4 mr-2"}),"Sign Out"]})]})})]})}const Qf="AIzaSyCfiSS-fokH072eYcZaaM8Z0exr8gH2RAY";function Zf({children:t}){return a.jsx(ha,{apiKey:Qf,children:t})}function ep(){var o;const t=u.useRef(null),e=u.useRef(),r=u.useRef(0),n=5,{user:s}=Ht();return u.useEffect(()=>{function i(){const d=`${window.location.protocol==="https:"?"wss:":"ws:"}//${window.location.host}/ws`;try{const f=new WebSocket(d);t.current=f,f.onopen=()=>{console.log("🔌 WebSocket connected"),r.current=0,s!=null&&s.id&&f.send(JSON.stringify({type:"auth",userId:s.id}))},f.onmessage=p=>{try{const h=JSON.parse(p.data);c(h)}catch(h){console.error("🔌 Failed to parse WebSocket message:",h)}},f.onerror=p=>{console.error("🔌 WebSocket error:",p)},f.onclose=()=>{if(console.log("🔌 WebSocket disconnected"),t.current=null,r.current<n){const p=Math.min(1e3*Math.pow(2,r.current),3e4);r.current++,console.log(`🔌 Reconnecting in ${p}ms (attempt ${r.current}/${n})...`),e.current=setTimeout(()=>{i()},p)}else console.error("🔌 Max reconnection attempts reached")}}catch(f){console.error("🔌 Failed to create WebSocket connection:",f)}}function c(l){var d,f,p,h;switch(console.log("📡 WebSocket message:",l),l.type){case"connected":console.log("✅ WebSocket connection confirmed");break;case"campaign:updated":(d=l.data)!=null&&d.campaignId&&(U.invalidateQueries({queryKey:["/api/advertiser/campaigns"]}),U.invalidateQueries({queryKey:["/api/advertiser/campaigns",l.data.campaignId]}),U.invalidateQueries({queryKey:["/api/admin/campaigns"]}));break;case"booking:updated":(f=l.data)!=null&&f.campaignId&&U.invalidateQueries({queryKey:["/api/advertiser/campaigns",l.data.campaignId]}),U.invalidateQueries({queryKey:["/api/advertiser/campaigns"]}),U.invalidateQueries({queryKey:["/api/admin/bookings"]}),U.invalidateQueries({queryKey:["/api/owner/booking-requests"]}),U.invalidateQueries({queryKey:["/api/owner/requests"]});break;case"screen:updated":(p=l.data)!=null&&p.screenId&&U.invalidateQueries({queryKey:["/api/screens",l.data.screenId]}),U.invalidateQueries({queryKey:["/api/screens"]}),U.invalidateQueries({queryKey:["/api/public/screens"]}),U.invalidateQueries({queryKey:["/api/admin/screens"]}),U.invalidateQueries({queryKey:["/api/owner/screens"]});break;case"notification:new":U.invalidateQueries({queryKey:["/api/notifications"]}),U.invalidateQueries({queryKey:["/api/notifications/unread-count"]});break;case"auth:ok":console.log("✅ WebSocket authenticated as user:",((h=l.data)==null?void 0:h.userId)||"");break;default:console.log("Unknown message type:",l.type)}}return i(),()=>{e.current&&clearTimeout(e.current),t.current&&(t.current.close(),t.current=null)}},[s==null?void 0:s.id]),{isConnected:((o=t.current)==null?void 0:o.readyState)===WebSocket.OPEN}}var Gr="Popover",[hi,Cm]=xr(Gr,[us]),gt=us(),[tp,Pe]=hi(Gr),fi=t=>{const{__scopePopover:e,children:r,open:n,defaultOpen:s,onOpenChange:o,modal:i=!1}=t,c=gt(e),l=u.useRef(null),[d,f]=u.useState(!1),[p=!1,h]=ns({prop:n,defaultProp:s,onChange:o});return a.jsx(sa,{...c,children:a.jsx(tp,{scope:e,contentId:oa(),triggerRef:l,open:p,onOpenChange:h,onOpenToggle:u.useCallback(()=>h(m=>!m),[h]),hasCustomAnchor:d,onCustomAnchorAdd:u.useCallback(()=>f(!0),[]),onCustomAnchorRemove:u.useCallback(()=>f(!1),[]),modal:i,children:r})})};fi.displayName=Gr;var pi="PopoverAnchor",rp=u.forwardRef((t,e)=>{const{__scopePopover:r,...n}=t,s=Pe(pi,r),o=gt(r),{onCustomAnchorAdd:i,onCustomAnchorRemove:c}=s;return u.useEffect(()=>(i(),()=>c()),[i,c]),a.jsx(hs,{...o,...n,ref:e})});rp.displayName=pi;var mi="PopoverTrigger",gi=u.forwardRef((t,e)=>{const{__scopePopover:r,...n}=t,s=Pe(mi,r),o=gt(r),i=se(e,s.triggerRef),c=a.jsx(H.button,{type:"button","aria-haspopup":"dialog","aria-expanded":s.open,"aria-controls":s.contentId,"data-state":_i(s.open),...n,ref:i,onClick:L(t.onClick,s.onOpenToggle)});return s.hasCustomAnchor?c:a.jsx(hs,{asChild:!0,...o,children:c})});gi.displayName=mi;var Yr="PopoverPortal",[np,sp]=hi(Yr,{forceMount:void 0}),bi=t=>{const{__scopePopover:e,forceMount:r,children:n,container:s}=t,o=Pe(Yr,e);return a.jsx(np,{scope:e,forceMount:r,children:a.jsx(Oe,{present:r||o.open,children:a.jsx(ss,{asChild:!0,container:s,children:n})})})};bi.displayName=Yr;var He="PopoverContent",yi=u.forwardRef((t,e)=>{const r=sp(He,t.__scopePopover),{forceMount:n=r.forceMount,...s}=t,o=Pe(He,t.__scopePopover);return a.jsx(Oe,{present:n||o.open,children:o.modal?a.jsx(ip,{...s,ref:e}):a.jsx(ap,{...s,ref:e})})});yi.displayName=He;var op=na("PopoverContent.RemoveScroll"),ip=u.forwardRef((t,e)=>{const r=Pe(He,t.__scopePopover),n=u.useRef(null),s=se(e,n),o=u.useRef(!1);return u.useEffect(()=>{const i=n.current;if(i)return Ji(i)},[]),a.jsx(Xi,{as:op,allowPinchZoom:!0,children:a.jsx(vi,{...t,ref:s,trapFocus:r.open,disableOutsidePointerEvents:!0,onCloseAutoFocus:L(t.onCloseAutoFocus,i=>{var c;i.preventDefault(),o.current||(c=r.triggerRef.current)==null||c.focus()}),onPointerDownOutside:L(t.onPointerDownOutside,i=>{const c=i.detail.originalEvent,l=c.button===0&&c.ctrlKey===!0,d=c.button===2||l;o.current=d},{checkForDefaultPrevented:!1}),onFocusOutside:L(t.onFocusOutside,i=>i.preventDefault(),{checkForDefaultPrevented:!1})})})}),ap=u.forwardRef((t,e)=>{const r=Pe(He,t.__scopePopover),n=u.useRef(!1),s=u.useRef(!1);return a.jsx(vi,{...t,ref:e,trapFocus:!1,disableOutsidePointerEvents:!1,onCloseAutoFocus:o=>{var i,c;(i=t.onCloseAutoFocus)==null||i.call(t,o),o.defaultPrevented||(n.current||(c=r.triggerRef.current)==null||c.focus(),o.preventDefault()),n.current=!1,s.current=!1},onInteractOutside:o=>{var l,d;(l=t.onInteractOutside)==null||l.call(t,o),o.defaultPrevented||(n.current=!0,o.detail.originalEvent.type==="pointerdown"&&(s.current=!0));const i=o.target;((d=r.triggerRef.current)==null?void 0:d.contains(i))&&o.preventDefault(),o.detail.originalEvent.type==="focusin"&&s.current&&o.preventDefault()}})}),vi=u.forwardRef((t,e)=>{const{__scopePopover:r,trapFocus:n,onOpenAutoFocus:s,onCloseAutoFocus:o,disableOutsidePointerEvents:i,onEscapeKeyDown:c,onPointerDownOutside:l,onFocusOutside:d,onInteractOutside:f,...p}=t,h=Pe(He,r),m=gt(r);return Qi(),a.jsx(Zi,{asChild:!0,loop:!0,trapped:n,onMountAutoFocus:s,onUnmountAutoFocus:o,children:a.jsx(ea,{asChild:!0,disableOutsidePointerEvents:i,onInteractOutside:f,onEscapeKeyDown:c,onPointerDownOutside:l,onFocusOutside:d,onDismiss:()=>h.onOpenChange(!1),children:a.jsx(ta,{"data-state":_i(h.open),role:"dialog",id:h.contentId,...m,...p,ref:e,style:{...p.style,"--radix-popover-content-transform-origin":"var(--radix-popper-transform-origin)","--radix-popover-content-available-width":"var(--radix-popper-available-width)","--radix-popover-content-available-height":"var(--radix-popper-available-height)","--radix-popover-trigger-width":"var(--radix-popper-anchor-width)","--radix-popover-trigger-height":"var(--radix-popper-anchor-height)"}})})})}),wi="PopoverClose",cp=u.forwardRef((t,e)=>{const{__scopePopover:r,...n}=t,s=Pe(wi,r);return a.jsx(H.button,{type:"button",...n,ref:e,onClick:L(t.onClick,()=>s.onOpenChange(!1))})});cp.displayName=wi;var lp="PopoverArrow",dp=u.forwardRef((t,e)=>{const{__scopePopover:r,...n}=t,s=gt(r);return a.jsx(ra,{...s,...n,ref:e})});dp.displayName=lp;function _i(t){return t?"open":"closed"}var up=fi,hp=gi,fp=bi,Ei=yi;const pp=up,mp=hp,xi=u.forwardRef(({className:t,align:e="center",sideOffset:r=4,...n},s)=>a.jsx(fp,{children:a.jsx(Ei,{ref:s,align:e,sideOffset:r,className:R("z-50 w-72 rounded-md border bg-popover p-4 text-popover-foreground shadow-md outline-none data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-[--radix-popover-content-transform-origin]",t),...n})}));xi.displayName=Ei.displayName;function gp(t,e){return u.useReducer((r,n)=>e[r][n]??r,t)}var Jr="ScrollArea",[Ii,Pm]=xr(Jr),[bp,J]=Ii(Jr),Si=u.forwardRef((t,e)=>{const{__scopeScrollArea:r,type:n="hover",dir:s,scrollHideDelay:o=600,...i}=t,[c,l]=u.useState(null),[d,f]=u.useState(null),[p,h]=u.useState(null),[m,y]=u.useState(null),[b,g]=u.useState(null),[v,w]=u.useState(0),[C,T]=u.useState(0),[k,j]=u.useState(!1),[z,W]=u.useState(!1),A=se(e,V=>l(V)),F=ia(s);return a.jsx(bp,{scope:r,type:n,dir:F,scrollHideDelay:o,scrollArea:c,viewport:d,onViewportChange:f,content:p,onContentChange:h,scrollbarX:m,onScrollbarXChange:y,scrollbarXEnabled:k,onScrollbarXEnabledChange:j,scrollbarY:b,onScrollbarYChange:g,scrollbarYEnabled:z,onScrollbarYEnabledChange:W,onCornerWidthChange:w,onCornerHeightChange:T,children:a.jsx(H.div,{dir:F,...i,ref:A,style:{position:"relative","--radix-scroll-area-corner-width":v+"px","--radix-scroll-area-corner-height":C+"px",...t.style}})})});Si.displayName=Jr;var Ti="ScrollAreaViewport",Ci=u.forwardRef((t,e)=>{const{__scopeScrollArea:r,children:n,nonce:s,...o}=t,i=J(Ti,r),c=u.useRef(null),l=se(e,c,i.onViewportChange);return a.jsxs(a.Fragment,{children:[a.jsx("style",{dangerouslySetInnerHTML:{__html:"[data-radix-scroll-area-viewport]{scrollbar-width:none;-ms-overflow-style:none;-webkit-overflow-scrolling:touch;}[data-radix-scroll-area-viewport]::-webkit-scrollbar{display:none}"},nonce:s}),a.jsx(H.div,{"data-radix-scroll-area-viewport":"",...o,ref:l,style:{overflowX:i.scrollbarXEnabled?"scroll":"hidden",overflowY:i.scrollbarYEnabled?"scroll":"hidden",...t.style},children:a.jsx("div",{ref:i.onContentChange,style:{minWidth:"100%",display:"table"},children:n})})]})});Ci.displayName=Ti;var ie="ScrollAreaScrollbar",Xr=u.forwardRef((t,e)=>{const{forceMount:r,...n}=t,s=J(ie,t.__scopeScrollArea),{onScrollbarXEnabledChange:o,onScrollbarYEnabledChange:i}=s,c=t.orientation==="horizontal";return u.useEffect(()=>(c?o(!0):i(!0),()=>{c?o(!1):i(!1)}),[c,o,i]),s.type==="hover"?a.jsx(yp,{...n,ref:e,forceMount:r}):s.type==="scroll"?a.jsx(vp,{...n,ref:e,forceMount:r}):s.type==="auto"?a.jsx(Pi,{...n,ref:e,forceMount:r}):s.type==="always"?a.jsx(Qr,{...n,ref:e}):null});Xr.displayName=ie;var yp=u.forwardRef((t,e)=>{const{forceMount:r,...n}=t,s=J(ie,t.__scopeScrollArea),[o,i]=u.useState(!1);return u.useEffect(()=>{const c=s.scrollArea;let l=0;if(c){const d=()=>{window.clearTimeout(l),i(!0)},f=()=>{l=window.setTimeout(()=>i(!1),s.scrollHideDelay)};return c.addEventListener("pointerenter",d),c.addEventListener("pointerleave",f),()=>{window.clearTimeout(l),c.removeEventListener("pointerenter",d),c.removeEventListener("pointerleave",f)}}},[s.scrollArea,s.scrollHideDelay]),a.jsx(Oe,{present:r||o,children:a.jsx(Pi,{"data-state":o?"visible":"hidden",...n,ref:e})})}),vp=u.forwardRef((t,e)=>{const{forceMount:r,...n}=t,s=J(ie,t.__scopeScrollArea),o=t.orientation==="horizontal",i=qt(()=>l("SCROLL_END"),100),[c,l]=gp("hidden",{hidden:{SCROLL:"scrolling"},scrolling:{SCROLL_END:"idle",POINTER_ENTER:"interacting"},interacting:{SCROLL:"interacting",POINTER_LEAVE:"idle"},idle:{HIDE:"hidden",SCROLL:"scrolling",POINTER_ENTER:"interacting"}});return u.useEffect(()=>{if(c==="idle"){const d=window.setTimeout(()=>l("HIDE"),s.scrollHideDelay);return()=>window.clearTimeout(d)}},[c,s.scrollHideDelay,l]),u.useEffect(()=>{const d=s.viewport,f=o?"scrollLeft":"scrollTop";if(d){let p=d[f];const h=()=>{const m=d[f];p!==m&&(l("SCROLL"),i()),p=m};return d.addEventListener("scroll",h),()=>d.removeEventListener("scroll",h)}},[s.viewport,o,l,i]),a.jsx(Oe,{present:r||c!=="hidden",children:a.jsx(Qr,{"data-state":c==="hidden"?"hidden":"visible",...n,ref:e,onPointerEnter:L(t.onPointerEnter,()=>l("POINTER_ENTER")),onPointerLeave:L(t.onPointerLeave,()=>l("POINTER_LEAVE"))})})}),Pi=u.forwardRef((t,e)=>{const r=J(ie,t.__scopeScrollArea),{forceMount:n,...s}=t,[o,i]=u.useState(!1),c=t.orientation==="horizontal",l=qt(()=>{if(r.viewport){const d=r.viewport.offsetWidth<r.viewport.scrollWidth,f=r.viewport.offsetHeight<r.viewport.scrollHeight;i(c?d:f)}},10);return We(r.viewport,l),We(r.content,l),a.jsx(Oe,{present:n||o,children:a.jsx(Qr,{"data-state":o?"visible":"hidden",...s,ref:e})})}),Qr=u.forwardRef((t,e)=>{const{orientation:r="vertical",...n}=t,s=J(ie,t.__scopeScrollArea),o=u.useRef(null),i=u.useRef(0),[c,l]=u.useState({content:0,viewport:0,scrollbar:{size:0,paddingStart:0,paddingEnd:0}}),d=Oi(c.viewport,c.content),f={...n,sizes:c,onSizesChange:l,hasThumb:d>0&&d<1,onThumbChange:h=>o.current=h,onThumbPointerUp:()=>i.current=0,onThumbPointerDown:h=>i.current=h};function p(h,m){return Sp(h,i.current,c,m)}return r==="horizontal"?a.jsx(wp,{...f,ref:e,onThumbPositionChange:()=>{if(s.viewport&&o.current){const h=s.viewport.scrollLeft,m=Jn(h,c,s.dir);o.current.style.transform=`translate3d(${m}px, 0, 0)`}},onWheelScroll:h=>{s.viewport&&(s.viewport.scrollLeft=h)},onDragScroll:h=>{s.viewport&&(s.viewport.scrollLeft=p(h,s.dir))}}):r==="vertical"?a.jsx(_p,{...f,ref:e,onThumbPositionChange:()=>{if(s.viewport&&o.current){const h=s.viewport.scrollTop,m=Jn(h,c);o.current.style.transform=`translate3d(0, ${m}px, 0)`}},onWheelScroll:h=>{s.viewport&&(s.viewport.scrollTop=h)},onDragScroll:h=>{s.viewport&&(s.viewport.scrollTop=p(h))}}):null}),wp=u.forwardRef((t,e)=>{const{sizes:r,onSizesChange:n,...s}=t,o=J(ie,t.__scopeScrollArea),[i,c]=u.useState(),l=u.useRef(null),d=se(e,l,o.onScrollbarXChange);return u.useEffect(()=>{l.current&&c(getComputedStyle(l.current))},[l]),a.jsx(Ai,{"data-orientation":"horizontal",...s,ref:d,sizes:r,style:{bottom:0,left:o.dir==="rtl"?"var(--radix-scroll-area-corner-width)":0,right:o.dir==="ltr"?"var(--radix-scroll-area-corner-width)":0,"--radix-scroll-area-thumb-width":Wt(r)+"px",...t.style},onThumbPointerDown:f=>t.onThumbPointerDown(f.x),onDragScroll:f=>t.onDragScroll(f.x),onWheelScroll:(f,p)=>{if(o.viewport){const h=o.viewport.scrollLeft+f.deltaX;t.onWheelScroll(h),Li(h,p)&&f.preventDefault()}},onResize:()=>{l.current&&o.viewport&&i&&n({content:o.viewport.scrollWidth,viewport:o.viewport.offsetWidth,scrollbar:{size:l.current.clientWidth,paddingStart:Mt(i.paddingLeft),paddingEnd:Mt(i.paddingRight)}})}})}),_p=u.forwardRef((t,e)=>{const{sizes:r,onSizesChange:n,...s}=t,o=J(ie,t.__scopeScrollArea),[i,c]=u.useState(),l=u.useRef(null),d=se(e,l,o.onScrollbarYChange);return u.useEffect(()=>{l.current&&c(getComputedStyle(l.current))},[l]),a.jsx(Ai,{"data-orientation":"vertical",...s,ref:d,sizes:r,style:{top:0,right:o.dir==="ltr"?0:void 0,left:o.dir==="rtl"?0:void 0,bottom:"var(--radix-scroll-area-corner-height)","--radix-scroll-area-thumb-height":Wt(r)+"px",...t.style},onThumbPointerDown:f=>t.onThumbPointerDown(f.y),onDragScroll:f=>t.onDragScroll(f.y),onWheelScroll:(f,p)=>{if(o.viewport){const h=o.viewport.scrollTop+f.deltaY;t.onWheelScroll(h),Li(h,p)&&f.preventDefault()}},onResize:()=>{l.current&&o.viewport&&i&&n({content:o.viewport.scrollHeight,viewport:o.viewport.offsetHeight,scrollbar:{size:l.current.clientHeight,paddingStart:Mt(i.paddingTop),paddingEnd:Mt(i.paddingBottom)}})}})}),[Ep,Ri]=Ii(ie),Ai=u.forwardRef((t,e)=>{const{__scopeScrollArea:r,sizes:n,hasThumb:s,onThumbChange:o,onThumbPointerUp:i,onThumbPointerDown:c,onThumbPositionChange:l,onDragScroll:d,onWheelScroll:f,onResize:p,...h}=t,m=J(ie,r),[y,b]=u.useState(null),g=se(e,A=>b(A)),v=u.useRef(null),w=u.useRef(""),C=m.viewport,T=n.content-n.viewport,k=Q(f),j=Q(l),z=qt(p,10);function W(A){if(v.current){const F=A.clientX-v.current.left,V=A.clientY-v.current.top;d({x:F,y:V})}}return u.useEffect(()=>{const A=F=>{const V=F.target;(y==null?void 0:y.contains(V))&&k(F,T)};return document.addEventListener("wheel",A,{passive:!1}),()=>document.removeEventListener("wheel",A,{passive:!1})},[C,y,T,k]),u.useEffect(j,[n,j]),We(y,z),We(m.content,z),a.jsx(Ep,{scope:r,scrollbar:y,hasThumb:s,onThumbChange:Q(o),onThumbPointerUp:Q(i),onThumbPositionChange:j,onThumbPointerDown:Q(c),children:a.jsx(H.div,{...h,ref:g,style:{position:"absolute",...h.style},onPointerDown:L(t.onPointerDown,A=>{A.button===0&&(A.target.setPointerCapture(A.pointerId),v.current=y.getBoundingClientRect(),w.current=document.body.style.webkitUserSelect,document.body.style.webkitUserSelect="none",m.viewport&&(m.viewport.style.scrollBehavior="auto"),W(A))}),onPointerMove:L(t.onPointerMove,W),onPointerUp:L(t.onPointerUp,A=>{const F=A.target;F.hasPointerCapture(A.pointerId)&&F.releasePointerCapture(A.pointerId),document.body.style.webkitUserSelect=w.current,m.viewport&&(m.viewport.style.scrollBehavior=""),v.current=null})})})}),Lt="ScrollAreaThumb",ki=u.forwardRef((t,e)=>{const{forceMount:r,...n}=t,s=Ri(Lt,t.__scopeScrollArea);return a.jsx(Oe,{present:r||s.hasThumb,children:a.jsx(xp,{ref:e,...n})})}),xp=u.forwardRef((t,e)=>{const{__scopeScrollArea:r,style:n,...s}=t,o=J(Lt,r),i=Ri(Lt,r),{onThumbPositionChange:c}=i,l=se(e,p=>i.onThumbChange(p)),d=u.useRef(void 0),f=qt(()=>{d.current&&(d.current(),d.current=void 0)},100);return u.useEffect(()=>{const p=o.viewport;if(p){const h=()=>{if(f(),!d.current){const m=Tp(p,c);d.current=m,c()}};return c(),p.addEventListener("scroll",h),()=>p.removeEventListener("scroll",h)}},[o.viewport,f,c]),a.jsx(H.div,{"data-state":i.hasThumb?"visible":"hidden",...s,ref:l,style:{width:"var(--radix-scroll-area-thumb-width)",height:"var(--radix-scroll-area-thumb-height)",...n},onPointerDownCapture:L(t.onPointerDownCapture,p=>{const m=p.target.getBoundingClientRect(),y=p.clientX-m.left,b=p.clientY-m.top;i.onThumbPointerDown({x:y,y:b})}),onPointerUp:L(t.onPointerUp,i.onThumbPointerUp)})});ki.displayName=Lt;var Zr="ScrollAreaCorner",Ni=u.forwardRef((t,e)=>{const r=J(Zr,t.__scopeScrollArea),n=!!(r.scrollbarX&&r.scrollbarY);return r.type!=="scroll"&&n?a.jsx(Ip,{...t,ref:e}):null});Ni.displayName=Zr;var Ip=u.forwardRef((t,e)=>{const{__scopeScrollArea:r,...n}=t,s=J(Zr,r),[o,i]=u.useState(0),[c,l]=u.useState(0),d=!!(o&&c);return We(s.scrollbarX,()=>{var p;const f=((p=s.scrollbarX)==null?void 0:p.offsetHeight)||0;s.onCornerHeightChange(f),l(f)}),We(s.scrollbarY,()=>{var p;const f=((p=s.scrollbarY)==null?void 0:p.offsetWidth)||0;s.onCornerWidthChange(f),i(f)}),d?a.jsx(H.div,{...n,ref:e,style:{width:o,height:c,position:"absolute",right:s.dir==="ltr"?0:void 0,left:s.dir==="rtl"?0:void 0,bottom:0,...t.style}}):null});function Mt(t){return t?parseInt(t,10):0}function Oi(t,e){const r=t/e;return isNaN(r)?0:r}function Wt(t){const e=Oi(t.viewport,t.content),r=t.scrollbar.paddingStart+t.scrollbar.paddingEnd,n=(t.scrollbar.size-r)*e;return Math.max(n,18)}function Sp(t,e,r,n="ltr"){const s=Wt(r),o=s/2,i=e||o,c=s-i,l=r.scrollbar.paddingStart+i,d=r.scrollbar.size-r.scrollbar.paddingEnd-c,f=r.content-r.viewport,p=n==="ltr"?[0,f]:[f*-1,0];return Di([l,d],p)(t)}function Jn(t,e,r="ltr"){const n=Wt(e),s=e.scrollbar.paddingStart+e.scrollbar.paddingEnd,o=e.scrollbar.size-s,i=e.content-e.viewport,c=o-n,l=r==="ltr"?[0,i]:[i*-1,0],d=aa(t,l);return Di([0,i],[0,c])(d)}function Di(t,e){return r=>{if(t[0]===t[1]||e[0]===e[1])return e[0];const n=(e[1]-e[0])/(t[1]-t[0]);return e[0]+n*(r-t[0])}}function Li(t,e){return t>0&&t<e}var Tp=(t,e=()=>{})=>{let r={left:t.scrollLeft,top:t.scrollTop},n=0;return function s(){const o={left:t.scrollLeft,top:t.scrollTop},i=r.left!==o.left,c=r.top!==o.top;(i||c)&&e(),r=o,n=window.requestAnimationFrame(s)}(),()=>window.cancelAnimationFrame(n)};function qt(t,e){const r=Q(t),n=u.useRef(0);return u.useEffect(()=>()=>window.clearTimeout(n.current),[]),u.useCallback(()=>{window.clearTimeout(n.current),n.current=window.setTimeout(r,e)},[r,e])}function We(t,e){const r=Q(e);os(()=>{let n=0;if(t){const s=new ResizeObserver(()=>{cancelAnimationFrame(n),n=window.requestAnimationFrame(r)});return s.observe(t),()=>{window.cancelAnimationFrame(n),s.unobserve(t)}}},[t,r])}var Mi=Si,Cp=Ci,Pp=Ni;const ji=u.forwardRef(({className:t,children:e,...r},n)=>a.jsxs(Mi,{ref:n,className:R("relative overflow-hidden",t),...r,children:[a.jsx(Cp,{className:"h-full w-full rounded-[inherit]",children:e}),a.jsx(Ui,{}),a.jsx(Pp,{})]}));ji.displayName=Mi.displayName;const Ui=u.forwardRef(({className:t,orientation:e="vertical",...r},n)=>a.jsx(Xr,{ref:n,orientation:e,className:R("flex touch-none select-none transition-colors",e==="vertical"&&"h-full w-2.5 border-l border-l-transparent p-[1px]",e==="horizontal"&&"h-2.5 flex-col border-t border-t-transparent p-[1px]",t),...r,children:a.jsx(ki,{className:"relative flex-1 rounded-full bg-border"})}));Ui.displayName=Xr.displayName;const Rp=mt("whitespace-nowrap inline-flex items-center rounded-md border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 hover-elevate ",{variants:{variant:{default:"border-transparent bg-primary text-primary-foreground shadow-xs",secondary:"border-transparent bg-secondary text-secondary-foreground",destructive:"border-transparent bg-destructive text-destructive-foreground shadow-xs",outline:" border [border-color:var(--badge-outline)] shadow-xs"}},defaultVariants:{variant:"default"}});function Ap({className:t,variant:e,...r}){return a.jsx("div",{className:R(Rp({variant:e}),t),...r})}function Xn(){const[t,e]=u.useState(!1),[,r]=ct(),{data:n}=ps({queryKey:["/api/notifications"],refetchInterval:3e4}),s=et({mutationFn:async p=>{await ke("PATCH",`/api/notifications/${p}/read`)},onSuccess:()=>{U.invalidateQueries({queryKey:["/api/notifications"]})}}),o=et({mutationFn:async()=>{await ke("PATCH","/api/notifications/read-all")},onSuccess:()=>{U.invalidateQueries({queryKey:["/api/notifications"]})}}),i=(n==null?void 0:n.notifications)||[],c=(n==null?void 0:n.unreadCount)||0,l=p=>{p.isRead||s.mutate(p.id),p.actionUrl&&(e(!1),r(p.actionUrl))},d=p=>{const h=Date.now()-new Date(p).getTime(),m=Math.floor(h/6e4);if(m<1)return"just now";if(m<60)return`${m}m ago`;const y=Math.floor(m/60);return y<24?`${y}h ago`:`${Math.floor(y/24)}d ago`},f=p=>{switch(p){case"payment_required":case"payment_received":return"💳";case"payout_incoming":case"payout_processed":return"💰";case"payout_expired":case"payout_accepted":return"⏰";case"creative_approved":return"✅";case"creative_rejected":return"❌";case"booking_approved":return"📋";case"booking_rejected":return"📋";case"campaign_live":return"🚀";case"campaign_completed":return"🏁";default:return"🔔"}};return a.jsxs(pp,{open:t,onOpenChange:e,children:[a.jsx(mp,{asChild:!0,children:a.jsxs(Te,{variant:"ghost",size:"icon",className:"relative",children:[a.jsx(_h,{className:"h-5 w-5"}),c>0&&a.jsx(Ap,{variant:"destructive",className:"absolute -top-1 -right-1 h-5 min-w-5 flex items-center justify-center p-0 text-[10px]",children:c>99?"99+":c})]})}),a.jsxs(xi,{className:"w-80 p-0",align:"end",children:[a.jsxs("div",{className:"flex items-center justify-between p-3 border-b",children:[a.jsx("h4",{className:"font-semibold text-sm",children:"Notifications"}),c>0&&a.jsxs(Te,{variant:"ghost",size:"sm",className:"h-7 text-xs",onClick:()=>o.mutate(),children:[a.jsx(xh,{className:"h-3 w-3 mr-1"}),"Mark all read"]})]}),a.jsx(ji,{className:"max-h-80",children:i.length===0?a.jsx("div",{className:"p-4 text-center text-sm text-muted-foreground",children:"No notifications yet"}):a.jsx("div",{className:"divide-y",children:i.slice(0,20).map(p=>a.jsx("button",{className:`w-full text-left p-3 hover:bg-muted/50 transition-colors ${p.isRead?"":"bg-blue-50 dark:bg-blue-950/20"}`,onClick:()=>l(p),children:a.jsxs("div",{className:"flex gap-2",children:[a.jsx("span",{className:"text-base mt-0.5 shrink-0",children:f(p.type)}),a.jsxs("div",{className:"flex-1 min-w-0",children:[a.jsx("p",{className:`text-sm ${p.isRead?"font-medium":"font-semibold"}`,children:p.title}),a.jsx("p",{className:"text-xs text-muted-foreground mt-0.5 line-clamp-2",children:p.message}),a.jsx("p",{className:"text-[10px] text-muted-foreground mt-1",children:d(p.createdAt)})]}),!p.isRead&&a.jsx("div",{className:"h-2 w-2 rounded-full bg-blue-500 mt-1.5 shrink-0"})]})},p.id))})})]})]})}const kp=u.lazy(()=>S(()=>import("./not-found-Cgl9k9Hs.js"),__vite__mapDeps([0,1,2,3,4,5,6,7]))),Qn=u.lazy(()=>S(()=>import("./Login-BQvHb_pA.js"),__vite__mapDeps([8,1,2,3,9,10,11,12,13,14,5,6,7]))),Np=u.lazy(()=>S(()=>import("./AdminDashboard-BABIFLtf.js"),__vite__mapDeps([15,1,2,5,3,16,17,6,18,7]))),Op=u.lazy(()=>S(()=>import("./ManageUsers-COF5fvSg.js"),__vite__mapDeps([19,1,2,5,3,20,21,22,12,6,7]))),Dp=u.lazy(()=>S(()=>import("./ManageScreens-Cs2AADy_.js"),__vite__mapDeps([23,1,2,5,3,20,21,11,24,25,26,27,28,9,22,29,30,6,7]))),Lp=u.lazy(()=>S(()=>import("./AddScreenForOwner-C9jYSHln.js"),__vite__mapDeps([31,1,2,5,20,21,3,32,33,9,34,35,36,37,6,7]))),Mp=u.lazy(()=>S(()=>import("./ManageBookings-5NLxQ-Lt.js"),__vite__mapDeps([38,1,2,5,3,10,24,9,11,39,12,40,41,42,29,21,4,43,6,7]))),jp=u.lazy(()=>S(()=>import("./Analytics-Buh-Cqu1.js"),__vite__mapDeps([44,1,2,5,3,16,18,6,45,42,7]))),Up=u.lazy(()=>S(()=>import("./AIConversations-CMyZ6BZJ.js"),__vite__mapDeps([46,1,2,5,3,11,16,47,48,49,50,29,6,7]))),Fp=u.lazy(()=>S(()=>import("./AISecurityDashboard-DIJYyZuu.js"),__vite__mapDeps([51,1,2,5,3,10,52,45,53,50,39,47,6,7]))),Vp=u.lazy(()=>S(()=>import("./Settings-CwWdsNXH.js"),__vite__mapDeps([54,1,2,3,9,5,6,7]))),zp=u.lazy(()=>S(()=>import("./OwnerDashboard-5ZBHvA1X.js"),__vite__mapDeps([55,1,2,5,3,16,17,6,7]))),$p=u.lazy(()=>S(()=>import("./ScreensList-UdjFN9Bl.js"),__vite__mapDeps([56,1,2,5,3,20,21,11,57,16,28,22,4,29,43,58,30,6,7]))),Bp=u.lazy(()=>S(()=>import("./AddScreen-BocnxIXx.js"),__vite__mapDeps([59,1,2,5,32,33,9,20,21,3,34,35,36,37,60,6,7]))),Hp=u.lazy(()=>S(()=>import("./EditScreen-Dcdlghel.js"),__vite__mapDeps([61,1,2,5,16,32,33,9,20,21,3,34,35,36,37,25,26,27,28,60,6,7]))),Wp=u.lazy(()=>S(()=>import("./BookingRequests-BmhW9xi5.js"),__vite__mapDeps([62,1,2,5,3,9,24,10,11,57,4,63,37,29,21,6,7]))),qp=u.lazy(()=>S(()=>import("./AdvertiserDashboard-CRA0M7Ht.js"),__vite__mapDeps([64,1,2,5,3,16,17,6,65,7]))),Kp=u.lazy(()=>S(()=>import("./DiscoverScreens-C760cOai.js"),__vite__mapDeps([66,1,2,5,7,3,20,21,36,57,11,67,58,52,28,6]))),Gp=u.lazy(()=>S(()=>import("./CampaignsList-i6bZVM_2.js"),__vite__mapDeps([68,1,2,5,3,16,57,28,4,29,69,53,50,6,7]))),Yp=u.lazy(()=>S(()=>import("./CampaignDetails-964eioxq.js"),__vite__mapDeps([70,1,2,5,3,57,11,24,4,60,42,21,71,63,72,52,45,53,50,6,7]))),Jp=u.lazy(()=>S(()=>import("./CreateCampaign-wb-ZZDYs.js"),__vite__mapDeps([73,1,2,33,9,5,20,21,3,36,11,74,57,34,7,35,75,76,60,45,29,52,77,48,6]))),Xp=u.lazy(()=>S(()=>import("./QuickCampaignFromCart-UXgnVyHd.js"),__vite__mapDeps([78,1,2,33,9,5,20,21,3,74,57,76,60,77,48,6,7]))),Qp=u.lazy(()=>S(()=>import("./BookingManagement-CntjCwng.js"),__vite__mapDeps([79,1,2,5,3,57,10,4,42,71,45,6,7]))),Zp=u.lazy(()=>S(()=>import("./AICampaignAdvisor-CPJ2O48K.js"),__vite__mapDeps([80,1,2,3,34,21,11,27,49,41,29,67,39,81,5,6,7])));u.lazy(()=>S(()=>import("./ComingSoon-UsUwgRfW.js"),__vite__mapDeps([82,1,2,3,5,6,7])));const em=u.lazy(()=>S(()=>import("./OwnerEarnings-DqN3lV4z.js"),__vite__mapDeps([83,1,2,5,3,10,60,45,42,4,6,7]))),tm=u.lazy(()=>S(()=>import("./AdvertiserPayments-Cn1h4-TB.js"),__vite__mapDeps([84,1,2,5,3,10,60,6,7]))),rm=u.lazy(()=>S(()=>import("./AdminPayments-B0Chvo8t.js"),__vite__mapDeps([85,1,2,5,3,10,9,24,11,81,63,72,52,42,6,7]))),nm=u.lazy(()=>S(()=>import("./ProfileCompletion-Cjn8dfp6.js"),__vite__mapDeps([86,1,2,33,9,3,20,21,76,5,40,14,6,7]))),sm=u.lazy(()=>S(()=>import("./EmailVerification-Ba0_Usx6.js"),__vite__mapDeps([87,1,2,3,9,5,12,77,6,7]))),lr=u.lazy(()=>S(()=>import("./Profile-BEN3VmUT.js"),__vite__mapDeps([88,1,2,5,3,9,20,21,11,69,65,71,6,7]))),om=u.lazy(()=>S(()=>import("./PublicHome-CvSCYJRd.js"),__vite__mapDeps([89,1,2,5,7,3,20,21,75,29,36,77,22,14,6]))),Zn=u.lazy(()=>S(()=>import("./PasswordReset-BW0GNazf.js"),__vite__mapDeps([90,1,2,3,9,26,71,42,5,6,7]))),im=u.lazy(()=>S(()=>import("./PrivacyPolicy-BRWxf3TT.js"),__vite__mapDeps([91,1,2,60,5,6,7]))),am=u.lazy(()=>S(()=>import("./TermsOfService-C-oh-4ke.js"),__vite__mapDeps([92,1,2,60,5,6,7]))),cm=u.lazy(()=>S(()=>import("./RefundPolicy-BKuzztUv.js"),__vite__mapDeps([93,1,2,60,5,6,7]))),lm=u.lazy(()=>S(()=>import("./ContactUs-NBUQJwy3.js"),__vite__mapDeps([94,1,2,3,60,12,40,45,5,6,7]))),dm=u.lazy(()=>S(()=>import("./AboutUs-8jrsgjmt.js"),__vite__mapDeps([95,1,2,3,60,13,5,6,7])));function es(){return a.jsx("div",{className:"flex items-center justify-center min-h-[50vh]",children:a.jsx(Dt,{className:"h-8 w-8 animate-spin text-primary"})})}function ts(){return a.jsxs(Ha,{children:[a.jsx(E,{path:"/",component:om}),a.jsx(E,{path:"/login",component:Qn}),a.jsx(E,{path:"/register",component:Qn}),a.jsx(E,{path:"/privacy",component:im}),a.jsx(E,{path:"/terms",component:am}),a.jsx(E,{path:"/refund",component:cm}),a.jsx(E,{path:"/contact",component:lm}),a.jsx(E,{path:"/about",component:dm}),a.jsx(E,{path:"/auth/action",component:Zn}),a.jsx(E,{path:"/reset-password",component:Zn}),a.jsx(E,{path:"/verify-email",component:sm}),a.jsx(E,{path:"/complete-profile",component:nm}),a.jsx(E,{path:"/admin",children:a.jsx(N,{allowedRoles:["admin"],children:a.jsx(Np,{})})}),a.jsx(E,{path:"/admin/users",children:a.jsx(N,{allowedRoles:["admin"],children:a.jsx(Op,{})})}),a.jsx(E,{path:"/admin/screens",children:a.jsx(N,{allowedRoles:["admin"],children:a.jsx(Dp,{})})}),a.jsx(E,{path:"/admin/screens/new",children:a.jsx(N,{allowedRoles:["admin"],children:a.jsx(Lp,{})})}),a.jsx(E,{path:"/admin/bookings",children:a.jsx(N,{allowedRoles:["admin"],children:a.jsx(Mp,{})})}),a.jsx(E,{path:"/admin/analytics",children:a.jsx(N,{allowedRoles:["admin"],children:a.jsx(jp,{})})}),a.jsx(E,{path:"/admin/ai-conversations",children:a.jsx(N,{allowedRoles:["admin"],children:a.jsx(Up,{})})}),a.jsx(E,{path:"/admin/ai-security",children:a.jsx(N,{allowedRoles:["admin"],children:a.jsx(Fp,{})})}),a.jsx(E,{path:"/admin/payments",children:a.jsx(N,{allowedRoles:["admin"],children:a.jsx(rm,{})})}),a.jsx(E,{path:"/admin/settings",children:a.jsx(N,{allowedRoles:["admin"],children:a.jsx(Vp,{})})}),a.jsx(E,{path:"/admin/profile",children:a.jsx(N,{allowedRoles:["admin"],children:a.jsx(lr,{})})}),a.jsx(E,{path:"/owner",children:a.jsx(N,{allowedRoles:["screen_owner"],children:a.jsx(zp,{})})}),a.jsx(E,{path:"/owner/screens",children:a.jsx(N,{allowedRoles:["screen_owner"],children:a.jsx($p,{})})}),a.jsx(E,{path:"/owner/screens/new",children:a.jsx(N,{allowedRoles:["screen_owner"],children:a.jsx(Bp,{})})}),a.jsx(E,{path:"/owner/screens/edit/:id",children:a.jsx(N,{allowedRoles:["screen_owner"],children:a.jsx(Hp,{})})}),a.jsx(E,{path:"/owner/requests",children:a.jsx(N,{allowedRoles:["screen_owner"],children:a.jsx(Wp,{})})}),a.jsx(E,{path:"/owner/earnings",children:a.jsx(N,{allowedRoles:["screen_owner"],children:a.jsx(em,{})})}),a.jsx(E,{path:"/owner/profile",children:a.jsx(N,{allowedRoles:["screen_owner"],children:a.jsx(lr,{})})}),a.jsx(E,{path:"/advertiser",children:a.jsx(N,{allowedRoles:["advertiser"],children:a.jsx(qp,{})})}),a.jsx(E,{path:"/advertiser/discover",children:a.jsx(N,{allowedRoles:["advertiser"],children:a.jsx(Kp,{})})}),a.jsx(E,{path:"/advertiser/quick-campaign",children:a.jsx(N,{allowedRoles:["advertiser"],children:a.jsx(Xp,{})})}),a.jsx(E,{path:"/advertiser/campaigns",children:a.jsx(N,{allowedRoles:["advertiser"],children:a.jsx(Gp,{})})}),a.jsx(E,{path:"/advertiser/campaigns/new",children:a.jsx(N,{allowedRoles:["advertiser"],children:a.jsx(Jp,{})})}),a.jsx(E,{path:"/advertiser/campaigns/:id",children:a.jsx(N,{allowedRoles:["advertiser"],children:a.jsx(Yp,{})})}),a.jsx(E,{path:"/advertiser/bookings",children:a.jsx(N,{allowedRoles:["advertiser"],children:a.jsx(Qp,{})})}),a.jsx(E,{path:"/advertiser/ai-advisor",children:a.jsx(N,{allowedRoles:["advertiser"],children:a.jsx(Zp,{})})}),a.jsx(E,{path:"/advertiser/payments",children:a.jsx(N,{allowedRoles:["advertiser"],children:a.jsx(tm,{})})}),a.jsx(E,{path:"/advertiser/profile",children:a.jsx(N,{allowedRoles:["advertiser"],children:a.jsx(lr,{})})}),a.jsx(E,{component:kp})]})}function um(){const{user:t}=Ht(),[e]=ct(),{toast:r}=$r(),[n,s]=u.useState(!1);ep();const o=t&&(e.startsWith("/admin")||e.startsWith("/owner")||e.startsWith("/advertiser")),i={"--sidebar-width":"20rem","--sidebar-width-icon":"4rem"},c=async()=>{s(!0),await U.invalidateQueries(),setTimeout(()=>{s(!1),r({title:"Refreshed",description:"All data has been updated"})},500)};return o?a.jsx(Mf,{style:i,children:a.jsxs("div",{className:"flex min-h-screen w-full",children:[a.jsx(Xf,{}),a.jsxs("div",{className:"flex flex-1 flex-col",children:[a.jsxs("header",{className:"sticky top-0 z-50 flex h-14 items-center gap-4 border-b bg-background px-4 md:hidden",children:[a.jsx(Uf,{"data-testid":"button-sidebar-toggle",children:a.jsx(Ch,{className:"h-6 w-6"})}),a.jsx("h1",{className:"flex-1 text-lg font-semibold",children:"Pixelspot"}),a.jsx(Xn,{}),a.jsx(Te,{variant:"ghost",size:"icon",onClick:c,disabled:n,"data-testid":"button-refresh",className:"h-9 w-9",children:a.jsx(Dt,{className:`h-5 w-5 ${n?"animate-spin":""}`})})]}),a.jsxs("header",{className:"hidden md:flex sticky top-0 z-50 h-12 items-center justify-end gap-2 border-b bg-background px-6",children:[a.jsx(Xn,{}),a.jsx(Te,{variant:"ghost",size:"icon",onClick:c,disabled:n,className:"h-8 w-8",children:a.jsx(Dt,{className:`h-4 w-4 ${n?"animate-spin":""}`})})]}),a.jsx("main",{className:"flex-1 bg-background",children:a.jsx(u.Suspense,{fallback:a.jsx(es,{}),children:a.jsx(ts,{})})})]})]})}):a.jsx(u.Suspense,{fallback:a.jsx(es,{}),children:a.jsx(ts,{})})}function hm(){return a.jsx(ua,{client:U,children:a.jsxs(ti,{children:[a.jsx(Zf,{children:a.jsx(Yf,{children:a.jsx(um,{})})}),a.jsx(bf,{})]})})}gs(document.getElementById("root")).render(a.jsx(hm,{}));export{Ee as $,Tm as A,Ap as B,Eh as C,Ih as D,ii as E,Wn as F,ai as G,ci as H,Ef as I,Nh as J,ir as K,vm as L,qn as M,Lr as N,Dr as O,at as P,Ge as Q,Dt as R,kh as S,Oh as T,Dh as U,we as V,_e as W,Ho as X,le as Y,Ne as Z,S as _,ct as a,Nd as a0,jd as a1,Uu as a2,po as a3,Pd as a4,fd as a5,Rd as a6,Wu as a7,Bl as a8,In as a9,Yd as aa,ud as ab,Od as ac,kd as ad,Al as ae,ql as af,Td as ag,_m as ah,Ad as ai,Dd as aj,Im as ak,$r as b,ke as c,Te as d,Th as e,M as f,ji as g,Ph as h,ym as i,Le as j,Hn as k,R as l,Tf as m,mt as n,Jf as o,Em as p,U as q,Ah as r,_h as s,yf as t,Ht as u,xm as v,vf as w,ri as x,_f as y,Cf as z};
